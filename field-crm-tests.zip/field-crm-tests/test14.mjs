import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

/* ---------- a Cache API stand-in, shared between the "service worker" and the page ---------- */
function makeCaches() {
  const store = new Map();          // cacheName -> Map(key -> {body, headers})
  return {
    store,
    api: {
      async open(name) {
        if (!store.has(name)) store.set(name, new Map());
        const c = store.get(name);
        return {
          async put(key, res) { c.set(String(key), res); },
          async match(key) { return c.get(String(key)) || undefined; },
          async delete(key) { return c.delete(String(key)); }
        };
      },
      async keys() { return [...store.keys()]; },
      async delete(name) { return store.delete(name); },
      async match() { return undefined; }
    }
  };
}

function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/' + (opts.search || ''),
      pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = opts.confirm || (() => true); w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  const stack = [null]; const h = {i:0};
  Object.defineProperty(w, 'history', { configurable:true, value:{
    get length(){ return h.i+1; }, get state(){ return stack[h.i]; },
    pushState(st){ stack.length = h.i+1; stack.push(st); h.i++; },
    replaceState(st){ stack[h.i] = st; },
    back(){ if(h.i===0) return; h.i--; const e = new w.Event('popstate'); e.state = stack[h.i]; w.dispatchEvent(e); }
  }});
  if (opts.caches) w.caches = opts.caches;
  const toasts = [];
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };
          (function(){ const real = toast; toast = function(m){ window.__toasts = window.__toasts || []; window.__toasts.push(m); return real(m); }; })();`);
  return w;
}
async function ready(w) {
  await wait(180);
  await w.eval('importCrm')(crmFile); await wait(120);
  await w.eval('renderHome()');
}
const lastToast = w => { const t = w.eval('window.__toasts') || []; return t[t.length-1] || ''; };

/* ================= manifest ================= */
const mf = JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));
const st = mf.share_target;
chk('the manifest declares a share target', !!st);
chk('it posts', st.method === 'POST', st.method);
chk('as multipart, which is what a file needs', st.enctype === 'multipart/form-data', st.enctype);
chk('the action is inside the app scope', st.action.startsWith('./'), st.action);
chk('the action is within the declared scope', st.action.replace('./','').indexOf('/') === -1);
chk('it takes files, not just text', Array.isArray(st.params.files) && st.params.files.length === 1);
chk('the field is called file', st.params.files[0].name === 'file');
const acc = st.params.files[0].accept;
for (const t of ['application/json','.json','.xlsx','.csv'])
  chk('it accepts ' + t, acc.includes(t));
chk('it accepts the xlsx mime type',
    acc.some(a => a.includes('spreadsheetml.sheet')), JSON.stringify(acc));
chk('the manifest is still valid JSON with icons intact', mf.icons.length === 3);

/* ================= service worker ================= */
const swSrc = fs.readFileSync('sw.js','utf8');
chk('sw handles POST to the share target', swSrc.includes("e.request.method === 'POST'"));
chk('sw matches the action path', swSrc.includes("endsWith('/share-target')"));
chk('sw redirects with 303, so a reload does not re-post', swSrc.includes(', 303)'));
chk('sw uses a separate cache for the hand-off', swSrc.includes("SHARE_CACHE = 'fieldcrm-share'"));
chk('activate does not delete the share cache', swSrc.includes('k !== SHARE_CACHE'));
chk('navigations ignore the query string so ?shared=1 still matches offline',
    swSrc.includes('ignoreSearch: true'));
chk('the cache version was bumped', /fieldcrm-v(?!1[0-5]\b)\d+/.test(swSrc), (swSrc.match(/fieldcrm-v\d+/)||[])[0]);

// run the worker's stash function for real against a fake request
const { store, api } = makeCaches();
{
  const sandbox = {
    caches: api, console,
    Response: class { constructor(body, init){ this.body = body; this._h = (init&&init.headers)||{}; }
      get headers(){ const h = this._h; return { get: k => h[k] }; }
      async blob(){ return { size: this.body.byteLength || 0, type: this._h['content-type'] }; }
      async arrayBuffer(){ return this.body; }
      static redirect(url, code){ return { redirected:true, url, status: code }; } },
    self: { addEventListener(){}, skipWaiting(){}, clients:{claim(){}} },
    URL, fetch: async () => { throw new Error('no network'); }
  };
  const fnSrc = swSrc.slice(swSrc.indexOf('async function stashShared'),
                            swSrc.indexOf('self.addEventListener(\'fetch\''));
  const run = new Function('caches','Response','console','SHARE_CACHE','SHARE_KEY',
    fnSrc + '; return stashShared;')(api, sandbox.Response, console, 'fieldcrm-share', './shared-file');
  const payload = Buffer.from('{"kind":"field-crm-plan","version":1,"appts":[]}');
  const fakeFile = { name:'plan (1).json', type:'application/json',
                     arrayBuffer: async () => payload };
  const req = { formData: async () => ({ get: k => k === 'file' ? fakeFile : null,
                                         values: function*(){ yield fakeFile; } }) };
  const res = await run(req);
  chk('the worker redirects after stashing', res.redirected === true && res.status === 303);
  chk('the redirect lands on the app', String(res.url).includes('index.html?shared=1'), String(res.url));
  const parked = store.get('fieldcrm-share');
  chk('the file was parked in the share cache', !!parked && parked.has('./shared-file'));
  chk('the filename survived, brackets and all',
      decodeURIComponent(parked.get('./shared-file').headers.get('x-filename')) === 'plan (1).json',
      parked.get('./shared-file').headers.get('x-filename'));
  // a sender that uses a different field name
  store.clear();
  const odd = { formData: async () => ({ get: () => null,
                                         values: function*(){ yield 'some text'; yield fakeFile; } }) };
  await run(odd);
  chk('a file posted under another field name is still found',
      !!store.get('fieldcrm-share') && store.get('fieldcrm-share').has('./shared-file'));
  // a share with no file at all must not throw
  store.clear();
  const empty = { formData: async () => ({ get: () => null, values: function*(){} }) };
  const r2 = await empty && await run(empty);
  chk('a share with no file redirects rather than failing', r2.status === 303);
  chk('and parks nothing', !store.get('fieldcrm-share') || !store.get('fieldcrm-share').size);
}

/* ================= the router ================= */
const w = boot({phone:true});
await ready(w);
const ACC = w.eval('ACCOUNTS');
const fileOf = (name, text, type) => ({ name, type: type||'application/json',
  text: async () => text, arrayBuffer: async () => Buffer.from(text) });

// a plan file
await w.eval('openDialog')(null, {acct: ACC[0].a, date: w.eval('iso(weekDays()[0])')});
w.document.getElementById('dSave').click(); await wait(60);
const plan = JSON.stringify(await w.eval('buildPlanFile')(false));
const calls = JSON.stringify(await w.eval('buildCallFile')(false));
const backup = JSON.stringify(await w.eval('buildBackup')(false));
const overrides = fs.readFileSync('zone-overrides.json','utf8');

const w2 = boot({phone:true}); await wait(180);
let msg = await w2.eval('routeIncomingFile')(fileOf('plan.json', plan));
chk('a plan file is recognised by content', /Plan merged/.test(msg), msg);
chk('and it actually merged', w2.eval('APPTS').length === 1);

msg = await w2.eval('routeIncomingFile')(fileOf('anything.json', calls));
chk('a call file is recognised', /Calls merged/.test(msg), msg);

msg = await w2.eval('routeIncomingFile')(fileOf('zone-overrides.json', overrides));
chk('the zone overrides are recognised', /zone overrides loaded/.test(msg), msg);
chk('and loaded', Object.keys(w2.eval('OVERRIDES').acctZone).length === 46);

const w3 = boot({phone:true}); await wait(180);
msg = await w3.eval('routeIncomingFile')(fileOf('field_crm_backup.json', backup));
chk('a backup is recognised', /Backup restored/.test(msg), msg);
chk('and it restored', w3.eval('ACCOUNTS').length === ACC.length);

const w4 = boot({phone:true, confirm: () => false}); await wait(180);
msg = await w4.eval('routeIncomingFile')(fileOf('field_crm_backup.json', backup));
chk('declining the backup prompt cancels it', /cancelled/.test(msg), msg);
chk('and nothing was restored', w4.eval('ACCOUNTS').length === 0);

// a CRM export, shared straight out of OneDrive
const w5 = boot({phone:true}); await wait(180);
msg = await w5.eval('routeIncomingFile')(crmFile);
chk('an xlsx export is recognised by extension', /Imported/.test(msg), msg);
chk('and the accounts landed', w5.eval('ACCOUNTS').length > 0, String(w5.eval('ACCOUNTS').length));

// rubbish
const w6 = boot({phone:true}); await wait(180);
for (const [what, f] of [
  ['a text file', fileOf('notes.txt', 'hello there')],
  ['unrelated JSON', fileOf('x.json', '{"hello":1}')],
  ['an empty file', fileOf('x.json', '')]
]) {
  let threw = null;
  try { await w6.eval('routeIncomingFile')(f); } catch(e){ threw = e.message; }
  chk('rubbish is refused with a message: ' + what, !!threw, String(threw));
  chk('and the message says what is expected: ' + what,
      /plan|call file|backup|zone overrides|CRM export/.test(threw || ''), String(threw));
}
chk('nothing rubbish changed the database', w6.eval('ACCOUNTS').length === 0);

/* ================= the boot hand-off ================= */
{
  const { store: s2, api: c2 } = makeCaches();
  const cache = await c2.open('fieldcrm-share');
  await cache.put('./shared-file', {
    headers: { get: k => k === 'x-filename' ? encodeURIComponent('field-crm-plan-2026-09-07.json')
                       : 'application/json' },
    async blob(){ return { size: plan.length, type:'application/json' }; },
    async arrayBuffer(){ return Buffer.from(plan); },
    async text(){ return plan; }
  });
  const w7 = boot({phone:true, caches:c2, search:'?shared=1'});
  // File is constructed from the blob, so give the window a workable one
  w7.File = class { constructor(parts, name, o){ this.name = name; this.type = (o||{}).type;
    this._t = plan; } async text(){ return this._t; }
    async arrayBuffer(){ return Buffer.from(this._t); } };
  w7.Blob = w7.Blob || class {};
  await wait(220);
  chk('the shared file was collected on boot', w7.eval('APPTS').length === 1,
      String(w7.eval('APPTS').length));
  chk('the user was told what happened', /Plan merged/.test(lastToast(w7)), lastToast(w7));
  chk('the share cache was emptied, so it cannot re-import next launch',
      !(s2.get('fieldcrm-share') || new Map()).has('./shared-file'));
  chk('?shared=1 was stripped from the history entry',
      !(w7.history.state && String(w7.history.state.url || '').includes('shared')));
}
// nothing shared: boot must be untouched
{
  const { api: c3 } = makeCaches();
  const w8 = boot({phone:true, caches:c3});
  await wait(200);
  chk('a normal boot with an empty share cache is unaffected',
      w8.document.getElementById('s-home').classList.contains('on'));
  chk('and says nothing about sharing',
      !/shared|Reading/.test((w8.eval('window.__toasts')||[]).join(' ')),
      (w8.eval('window.__toasts')||[]).join(' '));
}
// no Cache API at all
{
  const w9 = boot({phone:true});
  await wait(200);
  chk('a browser with no Cache API still boots',
      w9.document.getElementById('s-home').classList.contains('on'));
}

/* ================= the on-screen button uses the same door ================= */
const w10 = boot({phone:true}); await wait(180);
chk('the file input accepts spreadsheets too',
    fs.readFileSync('index.html','utf8').includes('id="exFile" accept=".json,.xlsx,.csv"'));
chk('the Receive button routes rather than assuming an exchange file',
    fs.readFileSync('app.js','utf8').includes("routeIncomingFile(f)"));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
