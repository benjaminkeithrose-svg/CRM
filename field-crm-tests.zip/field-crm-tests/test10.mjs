import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const DAY = 86400000;
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches:false, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
}
const visit = (acct, agoDays, extra) => Object.assign({
  id:'v'+acct.slice(0,5).replace(/\W/g,'')+agoDays, customer:acct, date:'01/01/2026',
  type:'Site call', mgr:'m', contacts:[], entries:[], loose:[], status:'done', closed:true,
  when: Date.now() - agoDays*DAY, updated: Date.now() - agoDays*DAY
}, extra||{});
async function appt(w, acct, dateISO, extra) {
  const ap = Object.assign({id:'ap'+acct.slice(0,5).replace(/\W/g,'')+dateISO, acct,
    type:'Intralox site visit', date:dateISO, start:'09:00', dur:60, agenda:'', contacts:[]},
    extra||{});
  w.eval('APPTS').push(ap);
  await w.eval('apptsPut')(ap);
  return ap;
}

const w = boot();
const $ = id => w.document.getElementById(id);
await ready(w);
const ACC = w.eval('ACCOUNTS');
const mgr = $('cMgr').value;
const iso = n => w.eval(`iso(addDays(new Date(), ${n}))`);

/* ---------- the four states ---------- */
const monthly = ACC.filter(a => a.cad === 'P1 Monthly');
const A = monthly[0] || ACC[0];
const B = monthly[1] || ACC[1];
const C = monthly[2] || ACC[2];
const D = monthly[3] || ACC[3];
w.eval('indexCalls')([visit(A.a, 3), visit(B.a, 200), visit(C.a, 200)]);
await appt(w, C.a, iso(4));                 // past cadence but booked
// D has no visit at all

chk('a recent visit reads as covered', w.eval('dueState')(A).state === 'covered',
    JSON.stringify(w.eval('dueState')(A)));
chk('an old visit with nothing booked reads as due', w.eval('dueState')(B).state === 'due',
    JSON.stringify(w.eval('dueState')(B)));
chk('an old visit with something booked reads as booked',
    w.eval('dueState')(C).state === 'booked', JSON.stringify(w.eval('dueState')(C)));
chk('booked is still past cadence, it is just not outstanding',
    w.eval('dueState')(C).over === true);
chk('the booked date is carried', w.eval('dueState')(C).booked === iso(4),
    String(w.eval('dueState')(C).booked));
chk('an account with no visit and no CRM date reads as never',
    D.idle == null ? w.eval('dueState')(D).state === 'never'
                   : ['due','covered','booked'].includes(w.eval('dueState')(D).state),
    JSON.stringify({idle: D.idle, state: w.eval('dueState')(D).state}));

/* ---------- what counts as a booking ---------- */
await appt(w, B.a, iso(-3));                // in the past
chk('a visit in the past does not count as booked', w.eval('dueState')(B).state === 'due');
const cancelled = await appt(w, B.a, iso(6), {status:'cancelled'});
chk('a cancelled visit does not count as booked', w.eval('dueState')(B).state === 'due');
cancelled.status = 'missed';
chk('a missed visit does not count as booked', w.eval('dueState')(B).state === 'due');
cancelled.status = 'done';
chk('a visit already done does not count as still booked', w.eval('dueState')(B).state === 'due');
cancelled.status = 'planned';
chk('a planned visit does count', w.eval('dueState')(B).state === 'booked');
cancelled.status = 'in progress';
chk('one in progress counts too', w.eval('dueState')(B).state === 'booked');
cancelled.status = 'cancelled';

// the earliest future booking is the one reported
await appt(w, C.a, iso(9));
chk('the earliest booking is the one shown', w.eval('dueState')(C).booked === iso(4),
    String(w.eval('dueState')(C).booked));

/* ---------- the label says which clock and what is booked ---------- */
chk('a booked label leads with the date',
    w.eval('dueLabel')(w.eval('dueState')(C)).startsWith('booked '),
    w.eval('dueLabel')(w.eval('dueState')(C)));
chk('a booked label still says how long it has been',
    w.eval('dueLabel')(w.eval('dueState')(C)).includes('since your last call'));
chk('a due label names the cadence it is past',
    w.eval('dueLabel')(w.eval('dueState')(B)).includes('past 30'),
    w.eval('dueLabel')(w.eval('dueState')(B)));
chk('a covered label does not shout',
    !w.eval('dueLabel')(w.eval('dueState')(A)).includes('past'),
    w.eval('dueLabel')(w.eval('dueState')(A)));

/* ---------- the outstanding list excludes what is booked ---------- */
const due = w.eval('overdueAccounts')(null).map(x => x.a.a);
chk('the due list holds the unbooked one', due.includes(B.a));
chk('the due list leaves out the booked one', !due.includes(C.a));
chk('the due list leaves out the covered one', !due.includes(A.a));
const withBooked = w.eval('overdueAccounts')(null, {includeBooked:true}).map(x => x.a.a);
chk('booked accounts can still be asked for', withBooked.includes(C.a));
chk('asking for them is the only way to see them', withBooked.length > due.length);
const foci = w.eval('overdueAccounts')(null).map(x => x.a.foc);
const rank = {'High':0,'Medium':1,'Low':2,'No Focus':3};
chk('the due list is still ordered by focus',
    foci.every((f,i) => i===0 || rank[foci[i-1]] <= rank[f]));

/* ---------- coverage adds up ---------- */
const cv = w.eval('coverage')(null);
chk('coverage counts every account once',
    cv.covered + cv.booked + cv.due + cv.never === cv.total, JSON.stringify(cv));
chk('coverage total is the whole book', cv.total === ACC.length, JSON.stringify(cv));
chk('the covered account is counted covered', cv.covered >= 1);
chk('the booked account is counted booked', cv.booked >= 1, JSON.stringify(cv));
const cvMine = w.eval('coverage')(mgr);
chk('coverage can be scoped to a manager', cvMine.total <= cv.total && cvMine.total > 0,
    JSON.stringify(cvMine));
chk('scoped coverage uses the reassigned manager, not the CRM one',
    w.eval('coverage').toString().includes('effMgr(a) !== mgr'));

/* ---------- the home tile talks about booking, not nagging ---------- */
w.eval('renderHomeCounts()');
const tile = $('dueInfo').textContent;
chk('the tile says how many need booking', /to book|nothing due|booked/.test(tile), tile);
chk('the tile separates booked from outstanding',
    cvMine.booked ? tile.includes('already in') : true, tile);
chk('the tile never just says "past cadence"', !tile.includes('past cadence'), tile);

/* ---------- the browse screen shows the state and the coverage ---------- */
w.eval("go('accounts')"); await wait(50);
w.eval("browseScope='all'"); w.eval('renderBrowse()'); await wait(30);
chk('the coverage line appears', $('abHint').textContent.includes('covered'), $('abHint').textContent);
chk('the coverage line names all three buckets',
    /covered/.test($('abHint').textContent) && /booked/.test($('abHint').textContent) &&
    /to book/.test($('abHint').textContent), $('abHint').textContent);
const rows = $('abRes').innerHTML;
chk('a booked account is badged booked', rows.includes('>booked<'));
chk('a due account is badged due', rows.includes('>due<'));
chk('a covered account carries no badge at all',
    !rows.includes('>covered<'));
chk('booked and due are visually different',
    w.eval('DUE_CLS').booked !== w.eval('DUE_CLS').due,
    JSON.stringify(w.eval('DUE_CLS')));

/* ---------- the account view leads with the booking ---------- */
w.eval('openAccount')(C.a); await wait(40);
chk('the account view badges it booked', $('avHead').innerHTML.includes('>booked<'));
chk('and gives the date', $('avHead').textContent.includes('Next visit booked'),
    $('avHead').textContent.slice(0,220));
w.eval('openAccount')(A.a); await wait(40);
chk('a covered account shows no next visit row',
    !$('avHead').textContent.includes('Next visit booked'));

/* ---------- planning: filter to what needs booking ---------- */
w.eval("go('plan')"); await wait(60);
chk('the needs-booking toggle renders', $('pDueOnly').innerHTML.includes('Needs booking'));
w.eval("plan.zone = " + JSON.stringify(B.z) + "; plan.mgr = ''");
w.eval('renderPlan()'); await wait(30);
const all = $('pList').querySelectorAll('[data-acct]').length;
$('pDueOnly').click(); await wait(40);
const only = [...$('pList').querySelectorAll('[data-acct]')].map(e => e.dataset.acct);
chk('the toggle narrows the rail', only.length <= all, `${only.length} of ${all}`);
chk('everything left needs booking',
    only.every(n => { const d = w.eval('dueState')(w.eval('ACC_BY_NAME').get(n)); return d.over && !d.booked; }));
chk('an account already booked is filtered out', !only.includes(C.a));
chk('a covered account is filtered out', !only.includes(A.a));
chk('the toggle reads as pressed', $('pDueOnly').getAttribute('aria-pressed') === 'true');
$('pDueOnly').click(); await wait(40);
chk('turning it off puts the rail back',
    $('pList').querySelectorAll('[data-acct]').length === all);

/* ---------- booking one removes it from the list ---------- */
w.eval("plan.zone = " + JSON.stringify(B.z));
w.eval('renderPlan()'); await wait(30);
const beforeCount = w.eval('overdueAccounts')(null).length;
await w.eval('openDialog')(null, {acct: B.a, date: iso(7)});
$('dDate').value = iso(7);
$('dSave').click(); await wait(80);
chk('booking a visit takes it off the outstanding list',
    w.eval('overdueAccounts')(null).length === beforeCount - 1,
    `${w.eval('overdueAccounts')(null).length} vs ${beforeCount}`);
chk('and it now reads as booked', w.eval('dueState')(B).state === 'booked');
chk('coverage moved it from due to booked',
    w.eval('coverage')(null).booked === cv.booked + 1,
    JSON.stringify(w.eval('coverage')(null)));

/* ---------- doing the visit resets the clock; cancelling does not ---------- */
const w2 = boot(); await ready(w2);
const A2 = w2.eval('ACCOUNTS');
const E = A2.find(a => a.cad === 'P1 Monthly') || A2[0];
w2.eval('indexCalls')([visit(E.a, 400)]);
chk('starting point is due', w2.eval('dueState')(E).state === 'due');
// a closed-out visit with no report still counts - you were there
w2.eval('indexCalls')([visit(E.a, 400), visit(E.a, 0, {id:'today', noReport:true, entries:[]})]);
chk('a closed-out visit with no report resets the clock',
    w2.eval('dueState')(E).state === 'covered' && w2.eval('dueState')(E).days === 0,
    JSON.stringify(w2.eval('dueState')(E)));
// a cancelled or missed call does not
w2.eval('indexCalls')([visit(E.a, 400), visit(E.a, 0, {id:'x', status:'cancelled'})]);
chk('a cancelled call does not reset it', w2.eval('dueState')(E).state === 'due',
    JSON.stringify(w2.eval('dueState')(E)));
w2.eval('indexCalls')([visit(E.a, 400), visit(E.a, 0, {id:'y', status:'missed'})]);
chk('a missed call does not reset it', w2.eval('dueState')(E).state === 'due');

/* ---------- the intervals ---------- */
const cad = w2.eval('CAD_DAYS');
chk('P1 is monthly', cad['P1 Monthly'] === 30);
chk('P2 is quarterly', cad['P2 Quarterly'] === 91);
chk('P3 is half-yearly', cad['P3 Half-yearly'] === 182);
chk('P4 is yearly', cad['P4 Validate & rate'] === 365);
const F = A2.find(a => a.cad === 'P4 Validate & rate');
if (F) {
  w2.eval('indexCalls')([visit(F.a, 200)]);
  chk('200 days is fine on a yearly cadence', w2.eval('dueState')(F).state === 'covered');
  w2.eval('indexCalls')([visit(F.a, 400)]);
  chk('400 days is not', w2.eval('dueState')(F).state === 'due');
} else { ok.push('(no P4 account)'); ok.push('(no P4 account)'); }

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
chk('index.html has #pDueOnly', idx.includes('id="pDueOnly"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
