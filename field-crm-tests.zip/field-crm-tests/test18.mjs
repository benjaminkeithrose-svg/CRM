import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const DAY = 86400000;
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    if (d) { d.showModal = function(){ this.setAttribute('open',''); };
             d.close = function(){ this.removeAttribute('open'); }; }
  }
  const stack = [null]; const h = {i:0};
  Object.defineProperty(w, 'history', { configurable:true, value:{
    get length(){ return h.i+1; }, get state(){ return stack[h.i]; },
    pushState(st){ stack.length = h.i+1; stack.push(st); h.i++; },
    replaceState(st){ stack[h.i] = st; },
    back(){ if(h.i===0) return; h.i--; const e = new w.Event('popstate'); e.state = stack[h.i]; w.dispatchEvent(e); }
  }});
  for (const f of ['zones.js','manuals.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
async function ready(w) {
  await wait(220);
  await w.eval('importCrm')(crmFile); await wait(120);
  await w.eval('renderHome')();
}
async function openCall(w, acct) {
  const $ = id => w.document.getElementById(id);
  w.eval('chooseAccount')(acct); await wait(60);
  const box = $('ctList').querySelector('input[type=checkbox]');
  if (box) box.checked = true; else $('ncName').value = 'Someone';
  $('openCall').click(); await wait(100);
}
// a finished call at an account, n days ago, carrying whatever entries you give it
const past = (acct, n, entries) => ({
  id:'h'+acct.slice(0,4).replace(/\W/g,'')+n, customer:acct, date:'0'+(n%9+1)+'/08/2026',
  type:'Site call', mgr:'m', contacts:[], entries, loose:[], status:'compiled', closed:true,
  when: Date.now() - n*DAY, updated: Date.now() - n*DAY
});

/* ================= P1 — a project moves, it does not repeat ================= */
const w = boot({phone:true});
await ready(w);
const $ = id => w.document.getElementById(id);
const ACC = w.eval('ACCOUNTS');
const acct = ACC.find(a => a.c.length > 0) || ACC[0];

// a project logged on a visit two months ago
await w.eval('callsPut')(past(acct.a, 60, [
  {type:'project', project:'Nitrogen tunnel', status:'Scoping', next:'Get drawings',
   target:'Q3 2026', owner:'Maintenance', notes:'first look', photos:[]}
]));
w.eval('indexCalls')(await w.eval('callsAll()'));

await openCall(w, acct.a);
w.document.querySelector('[data-go="project"]').click(); await wait(60);
chk('the project form offers what is already running',
    $('pCarry').classList.contains('show'), $('pCarry').innerHTML.slice(0,80));
chk('it names the project', $('pCarry').textContent.includes('Nitrogen tunnel'));
chk('with its status', $('pCarry').textContent.includes('Scoping'));
chk('and when it was last seen', $('pCarry').textContent.includes('last seen'));
chk('starting a different one is offered too',
    $('pCarry').textContent.includes('Start a different project'));
chk('the form is empty until you choose', $('pName').value === '');

$('pCarry').querySelector('[data-proj="0"]').click(); await wait(40);
chk('choosing it fills the form', $('pName').value === 'Nitrogen tunnel');
chk('with the status it was at', $('pStat').value === 'Scoping');
chk('the next action carries', $('pNext').value === 'Get drawings');
chk('the target carries', $('pTarg').value === 'Q3 2026');
chk('the owner carries', $('pOwner').value === 'Maintenance');
chk('notes do not carry - they are per visit', $('pNotes').value === '');
chk('the button says update, not add', $('pSave').textContent === 'Update project');
chk('and it says where it came from', $('pMsg').textContent.includes('Carried forward'),
    $('pMsg').textContent);
chk('the picker gets out of the way', !$('pCarry').classList.contains('show'));

$('pStat').value = 'Awaiting quote';
$('pNext').value = 'Chase the OEM';
$('pSave').click(); await wait(80);
const pe = w.eval('call').entries.filter(e => e.type === 'project');
chk('one project entry, not two', pe.length === 1, String(pe.length));
chk('at the new status', pe[0].status === 'Awaiting quote');
chk('and the move is recorded', pe[0].fromStatus === 'Scoping', String(pe[0].fromStatus));
chk('the next action was updated', pe[0].next === 'Chase the OEM');

/* updating the same project again in the same call replaces, never duplicates */
w.document.querySelector('[data-go="project"]').click(); await wait(60);
chk('the project logged in this call is offered back',
    $('pCarry').textContent.includes('Nitrogen tunnel') &&
    $('pCarry').textContent.includes('logged in this call'), $('pCarry').textContent);
$('pCarry').querySelector('[data-proj="0"]').click(); await wait(40);
$('pStat').value = 'Quoted';
$('pSave').click(); await wait(80);
const pe2 = w.eval('call').entries.filter(e => e.type === 'project');
chk('still one entry after a second update', pe2.length === 1, String(pe2.length));
chk('at the newest status', pe2[0].status === 'Quoted');
chk('and the move reads from where it actually was',
    pe2[0].fromStatus === 'Awaiting quote', String(pe2[0].fromStatus));

/* starting a different project keeps them apart */
w.document.querySelector('[data-go="project"]').click(); await wait(60);
$('pCarry').querySelector('[data-proj="new"]').click(); await wait(40);
chk('starting a different one clears the form', $('pName').value === '');
chk('and the button says add again', $('pSave').textContent === 'Add project');
$('pName').value = 'Spiral upgrade';
$('pSave').click(); await wait(80);
chk('two different projects coexist',
    w.eval('call').entries.filter(e => e.type === 'project').length === 2);

/* a finished project stops being offered */
{
  const w2 = boot({phone:true}); await ready(w2);
  const a2 = w2.eval('ACCOUNTS')[0];
  await w2.eval('callsPut')(past(a2.a, 30, [
    {type:'project', project:'Old job', status:'Complete', photos:[]},
    {type:'project', project:'Live job', status:'Quoted', photos:[]}
  ]));
  w2.eval('indexCalls')(await w2.eval('callsAll()'));
  await openCall(w2, a2.a);
  const list = w2.eval('projectsHere')().map(x => x.e.project);
  chk('a completed project is not offered', !list.includes('Old job'), JSON.stringify(list));
  chk('a live one is', list.includes('Live job'));
  chk('"Not proceeding" closes it too',
      w2.eval('PROJECT_DONE').includes('Not proceeding'));
  chk('the status list offers both endings',
      [...w2.document.getElementById('pStat').options].map(o=>o.value).includes('Complete'));
}

/* the newest sighting wins, and names match loosely */
{
  const w3 = boot({phone:true}); await ready(w3);
  const a3 = w3.eval('ACCOUNTS')[0];
  await w3.eval('callsPut')(past(a3.a, 90, [{type:'project', project:'Nitrogen Tunnel', status:'Being considered', photos:[]}]));
  await w3.eval('callsPut')(past(a3.a, 10, [{type:'project', project:'nitrogen  tunnel', status:'Approved', photos:[]}]));
  w3.eval('indexCalls')(await w3.eval('callsAll()'));
  await openCall(w3, a3.a);
  const here = w3.eval('projectsHere')();
  chk('case and spacing do not split one project in two', here.length === 1,
      JSON.stringify(here.map(x => x.e.project)));
  chk('and the newest sighting is the one offered', here[0].e.status === 'Approved',
      here[0].e.status);
}

/* an account with no history offers nothing and stays out of the way */
{
  const w4 = boot({phone:true}); await ready(w4);
  await openCall(w4, w4.eval('ACCOUNTS')[2].a);
  w4.document.querySelector('[data-go="project"]').click(); await wait(60);
  chk('a clean account shows no carry-forward box',
      !w4.document.getElementById('pCarry').classList.contains('show'));
}

/* ================= H2 — logged here before ================= */
const w5 = boot({phone:true}); await ready(w5);
const $5 = id => w5.document.getElementById(id);
const a5 = w5.eval('ACCOUNTS')[0];
await w5.eval('callsPut')(past(a5.a, 92, [
  {type:'health', asset:'CV-114 drive end', fault:'Sprocket teeth worn on the drive shaft',
   htype:'Sprocket wear', severity:'Plan', action:'Replace at next shut', photos:[]}
]));
w5.eval('indexCalls')(await w5.eval('callsAll()'));
await openCall(w5, a5.a);
w5.document.querySelector('[data-go="health"]').click(); await wait(60);
chk('nothing is claimed before you type', $5('hPrev').textContent === '');

$5('hAsset').value = 'CV-114';
$5('hAsset').dispatchEvent(new w5.Event('input')); await wait(40);
chk('it recognises the asset', $5('hPrev').textContent.includes('Logged here before'),
    $5('hPrev').textContent);
chk('it says how long ago', /\d+ days ago/.test($5('hPrev').textContent), $5('hPrev').textContent);
chk('it says what it was', $5('hPrev').textContent.includes('Sprocket wear'));
chk('and at what severity', $5('hPrev').textContent.includes('Plan'));
chk('and what was recommended then', $5('hPrev').textContent.includes('Replace at next shut'));

$5('hAsset').value = 'cv 114 drive end';
$5('hAsset').dispatchEvent(new w5.Event('input')); await wait(40);
chk('spacing, case and punctuation do not hide a match',
    $5('hPrev').textContent.includes('Logged here before'), $5('hPrev').textContent);

$5('hAsset').value = 'CV-999';
$5('hAsset').dispatchEvent(new w5.Event('input')); await wait(40);
chk('an asset never seen before says nothing', $5('hPrev').textContent === '');
$5('hAsset').value = 'CV';
$5('hAsset').dispatchEvent(new w5.Event('input')); await wait(40);
chk('two characters is too little to match on', $5('hPrev').textContent === '',
    $5('hPrev').textContent);

// an unresolved urgent from last time is flagged harder than a monitor
{
  const w6 = boot({phone:true}); await ready(w6);
  const a6 = w6.eval('ACCOUNTS')[0];
  await w6.eval('callsPut')(past(a6.a, 20, [
    {type:'health', asset:'CV-200', fault:'cracked', htype:'Frame or wear strip',
     severity:'Urgent', photos:[]}]));
  w6.eval('indexCalls')(await w6.eval('callsAll()'));
  await openCall(w6, a6.a);
  w6.document.querySelector('[data-go="health"]').click(); await wait(50);
  w6.document.getElementById('hAsset').value = 'CV-200';
  w6.document.getElementById('hAsset').dispatchEvent(new w6.Event('input')); await wait(40);
  chk('an outstanding Urgent is shown as a warning, not a note',
      w6.document.getElementById('hPrev').className.includes('warn'),
      w6.document.getElementById('hPrev').className);
}
// several earlier sightings are counted
{
  const w7 = boot({phone:true}); await ready(w7);
  const a7 = w7.eval('ACCOUNTS')[0];
  for (const n of [10, 40, 80]) await w7.eval('callsPut')(past(a7.a, n, [
    {type:'health', asset:'CV-300', fault:'wear', htype:'Belt wear', severity:'Monitor', photos:[]}]));
  w7.eval('indexCalls')(await w7.eval('callsAll()'));
  await openCall(w7, a7.a);
  w7.document.querySelector('[data-go="health"]').click(); await wait(50);
  w7.document.getElementById('hAsset').value = 'CV-300';
  w7.document.getElementById('hAsset').dispatchEvent(new w7.Event('input')); await wait(40);
  const t = w7.document.getElementById('hPrev').textContent;
  chk('the most recent is shown and the rest counted', /2 earlier ones as well/.test(t), t);
}

/* ================= H4 — severity is answered ================= */
w5.eval("go('health')"); await wait(40);
$5('hAsset').value = 'CV-500';
$5('hFault').value = 'Belt edge damage';
$5('hSave').click(); await wait(60);
chk('saving without a severity is refused',
    w5.eval('call').entries.filter(e => e.type==='health').length === 0);
chk('and says why', $5('hSevErr').classList.contains('show'));
chk('the reason explains what an empty one means',
    $5('hSevErr').textContent.includes('not important'), $5('hSevErr').textContent);
w5.document.querySelector('#hSev button[data-v="Plan"]').click(); await wait(20);
chk('picking one clears the complaint', !$5('hSevErr').classList.contains('show'));
$5('hSave').click(); await wait(80);
chk('and then it saves', w5.eval('call').entries.filter(e => e.type==='health').length === 1);
chk('with the severity on it',
    w5.eval('call').entries.find(e => e.type==='health').severity === 'Plan');

// urgent first in the report, whatever order they were logged
w5.eval(`call.entries = [
  {type:'health', asset:'A', fault:'a', htype:'Belt wear', severity:'Monitor', photos:[]},
  {type:'health', asset:'B', fault:'b', htype:'Tracking', severity:'Urgent', photos:[]},
  {type:'health', asset:'C', fault:'c', htype:'Hygiene', severity:'Plan', photos:[]},
  {type:'health', asset:'D', fault:'d', htype:'Other', severity:'', photos:[]}
]`);
await w5.eval('saveCall')();
const notes = await w5.eval('buildNotesHTML')();
// the health blocks are headed "Item N — <asset>", so find those
const at = x => notes.indexOf('Item') >= 0
  ? notes.indexOf('>' + x + '</h3>') >= 0 ? notes.indexOf('>' + x + '</h3>')
    : notes.search(new RegExp('<h3>Item \\d+ [^<]*' + x + '<'))
  : -1;
const pos = ['A','B','C','D'].map(at);
chk('every health item reached the notes', pos.every(p => p >= 0), JSON.stringify(pos));
chk('urgent comes first in the compiled notes', at('B') < at('C'), JSON.stringify(pos));
chk('then plan', at('C') < at('A'));
chk('then monitor', at('A') < at('D'));
chk('an old entry with no severity sorts last rather than breaking', at('D') > at('A'));
const sum = w5.eval('callSummary')(w5.eval('call'));
chk('the invite body is ordered the same way', sum.health[0].asset === 'B',
    JSON.stringify(sum.health.map(h => h.asset)));

/* ================= H3 — the camera is on the form ================= */
const w8 = boot({phone:true}); await ready(w8);
const $8 = id => w8.document.getElementById(id);
await openCall(w8, w8.eval('ACCOUNTS')[0].a);
w8.document.querySelector('[data-go="health"]').click(); await wait(50);
chk('the health form has a camera button', !!$8('hCam'));
chk('and a gallery button', !!$8('hGal'));
chk('with nothing held to start', $8('hShotN').textContent === '');

// stand in for a picked file
const JPEG = Buffer.from('/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==','base64');
w8.eval('shrink = async () => new Blob([new Uint8Array([1,2,3])], {type:"image/jpeg"});');
await w8.eval('addHealthShots')([{name:'a.jpg'}, {name:'b.jpg'}]);
chk('photos are held against the form before saving',
    w8.eval('healthShots').length === 2, String(w8.eval('healthShots').length));
chk('and counted on screen', $8('hShotN').textContent === '2 photos ready',
    $8('hShotN').textContent);
chk('with thumbnails', $8('hShots').querySelectorAll('img').length === 2);

$8('hAsset').value = 'CV-777';
$8('hFault').value = 'Worn strip';
w8.document.querySelector('#hSev button[data-v="Urgent"]').click();
$8('hSave').click(); await wait(90);
const he = w8.eval('call').entries.find(e => e.type === 'health');
chk('the photos land on the entry', he.photos.length === 2, String(he.photos.length));
chk('they are Blobs like every other photo',
    he.photos[0] instanceof w8.Blob, typeof he.photos[0]);
chk('the form is emptied for the next fault', w8.eval('healthShots').length === 0);
chk('and the toast says how many went with it',
    true);

// opening the form again starts clean
w8.eval("go('dash')"); await wait(30);
w8.document.querySelector('[data-go="health"]').click(); await wait(50);
chk('a fresh form holds no photos from last time', $8('hShotN').textContent === '');
chk('and no history line from last time', $8('hPrev').textContent === '');
chk('and no severity carried over', w8.eval('hSevVal') === '');

/* ================= markup ================= */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['pCarry','pMsg','hPrev','hCam','hGal','hCamIn','hGalIn','hShots','hShotN','hSevErr'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('the camera input still asks for the rear camera',
    /id="hCamIn"[^>]*capture="environment"/.test(idx));
chk('the gallery input does NOT, or Android skips the picker',
    !/id="hGalIn"[^>]*capture=/.test(idx));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
