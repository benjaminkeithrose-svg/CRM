import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const SRC = '/mnt/project/ANZ_Active_template.xlsx';
const buf = fs.readFileSync(SRC);
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

function boot(db) {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = db || new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  // jsdom has no <dialog> behaviour
  const d = w.document.getElementById('dlg');
  d.showModal = function(){ this.setAttribute('open',''); };
  d.close = function(){ this.removeAttribute('open'); };
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
// a DataTransfer stand-in, so drop handlers can be driven directly
const dt = payload => ({ data:'', setData(t,v){ this.data=v; }, getData(){ return JSON.stringify(payload); },
                         effectAllowed:'' });
function fireDrop(w, el, payload) {
  const e = new w.Event('drop', {bubbles:true});
  e.dataTransfer = dt(payload);
  e.preventDefault = () => {};
  el.dispatchEvent(e);
}

const store = new FDBFactory();
const w = boot(store);
const $ = id => w.document.getElementById(id);
await wait(150);

/* ---------- date helpers, ported verbatim ---------- */
chk('startOfWeek lands on Monday',
    w.eval("iso(startOfWeek(new Date('2026-09-06T12:00:00')))") === '2026-08-31',
    w.eval("iso(startOfWeek(new Date('2026-09-06T12:00:00')))"));
chk('a Monday is its own week start',
    w.eval("iso(startOfWeek(parseIso('2026-08-31')))") === '2026-08-31');
chk('iso and parseIso round trip', w.eval("iso(parseIso('2026-03-01'))") === '2026-03-01');
chk('addDays crosses a month boundary', w.eval("iso(addDays(parseIso('2026-01-31'),1))") === '2026-02-01');
chk('Saturday is not a weekday', w.eval("isWeekday(parseIso('2026-09-05'))") === false);
chk('Wednesday is', w.eval("isWeekday(parseIso('2026-09-02'))") === true);

/* ---------- plan needs accounts ---------- */
w.document.querySelector('[data-go="plan"]').click(); await wait(40);
chk('plan is refused with no accounts', !$('s-plan').classList.contains('on'));

await w.eval('importCrm')(crmFile); await wait(100);
await w.eval('renderHome()');
w.document.querySelector('[data-go="plan"]').click(); await wait(60);
chk('plan opens once accounts are loaded', $('s-plan').classList.contains('on'));
chk('body breaks out of the phone column', w.document.body.classList.contains('planning'));

const ACC = w.eval('ACCOUNTS');

/* ---------- rail ---------- */
chk('zone select lists only zones that hold an account',
    [...$('pZone').options].length === new Set(ACC.map(a => a.z)).size,
    String([...$('pZone').options].length));
chk('rail shows a zone heading', $('zTitle').textContent.startsWith('Z'), $('zTitle').textContent);
chk('scope banner hidden when not searching', $('pScope').hidden === true);
const zone0 = w.eval('plan.zone'), mgr0 = w.eval('plan.mgr');
const inZone = ACC.filter(a => a.z === zone0 && (!mgr0 || a.mgr === mgr0));
chk('rail lists the accounts in the zone, scoped to the manager',
    $('pList').querySelectorAll('[data-acct]').length === inZone.length,
    `${$('pList').querySelectorAll('[data-acct]').length} vs ${inZone.length}`);
// and clearing the manager widens it back to the zone
const zoneAll = ACC.filter(a => a.z === zone0);
$('pMgr').value = ''; $('pMgr').dispatchEvent(new w.Event('change')); await wait(30);
chk('clearing the manager widens the rail to the whole zone',
    $('pList').querySelectorAll('[data-acct]').length === zoneAll.length,
    `${$('pList').querySelectorAll('[data-acct]').length} vs ${zoneAll.length}`);
$('pMgr').value = mgr0; $('pMgr').dispatchEvent(new w.Event('change')); await wait(30);

// focus chips
const chips = $('pChips').querySelectorAll('[data-lvl]');
chk('a focus chip per level', chips.length === 4);
const highChip = [...chips].find(c => c.dataset.lvl === 'High');
highChip.click(); await wait(20);
chk('unticking a focus level narrows the rail',
    $('pList').querySelectorAll('[data-acct]').length ===
      inZone.filter(a => a.foc !== 'High').length);
highChip.click(); await wait(20);

// whole-book search
const other = ACC.find(a => a.z !== zone0);
$('pQ').value = other.a.slice(0, 12);
$('pQ').dispatchEvent(new w.Event('input')); await wait(30);
chk('search reaches outside the current zone',
    [...$('pList').querySelectorAll('[data-acct]')].some(e => e.dataset.acct === other.a));
chk('out-of-zone hits carry a zone tag', $('pList').innerHTML.includes('class="zt"'));
chk('scope banner appears and counts them',
    $('pScope').hidden === false && /outside/.test($('pScope').textContent), $('pScope').textContent);
$('pScope').querySelector('button').click(); await wait(30);
chk('Clear puts the rail back', $('pQ').value === '' && $('pScope').hidden === true);

// two words narrow rather than widen
const two = ACC.find(a => a.a.trim().split(/\s+/).length > 2);
if (two) {
  const [t1, t2] = two.a.split(/\s+/);
  $('pQ').value = t1 + ' ' + t2;
  $('pQ').dispatchEvent(new w.Event('input')); await wait(30);
  const hits = [...$('pList').querySelectorAll('[data-acct]')].map(e => e.dataset.acct);
  chk('every token has to land, so two words narrow', hits.every(h => {
    const l = h.toLowerCase();
    return l.includes(t1.toLowerCase()) && l.includes(t2.toLowerCase());
  }), JSON.stringify(hits.slice(0,3)));
  $('pQ').value = ''; $('pQ').dispatchEvent(new w.Event('input')); await wait(30);
} else ok.push('no multi-word account name to test token narrowing');

/* ---------- calendar ---------- */
chk('week view renders five days', $('calBody').querySelectorAll('.day').length === 5);
chk('each day offers an add button', $('calBody').querySelectorAll('.add').length === 5);
chk('calendar hint invites a drag when empty',
    $('calHint').textContent.includes('drag it onto a day'), $('calHint').textContent);
const titleWeek = $('calTitle').textContent;
$('calNext').click(); await wait(20);
chk('next moves the week on', $('calTitle').textContent !== titleWeek);
$('calToday').click(); await wait(20);
chk('today comes back', $('calTitle').textContent === titleWeek);
[...$('pView').querySelectorAll('button')].find(b => b.dataset.v === 'month').click(); await wait(20);
chk('month view renders cells', $('calBody').querySelectorAll('.mcell').length >= 20,
    String($('calBody').querySelectorAll('.mcell').length));
chk('month title is a month and year', /^[A-Z][a-z]+ \d{4}$/.test($('calTitle').textContent),
    $('calTitle').textContent);
[...$('pView').querySelectorAll('button')].find(b => b.dataset.v === 'week').click(); await wait(20);

/* ---------- drag an account onto a day ---------- */
const target = inZone[0];
const days = $('calBody').querySelectorAll('.day');
fireDrop(w, days[2], {kind:'acct', acct:target.a});
await wait(40);
chk('dropping an account opens the dialog', $('dlg').hasAttribute('open'));
chk('dialog is seeded with that account', $('dTitle').textContent.includes(target.a));
chk('dialog is seeded with the day dropped on',
    $('dDate').value === w.eval('iso(weekDays()[2])'), $('dDate').value);
chk('dialog subtitle carries the account context',
    $('dSub').textContent.includes(target.foc) && $('dSub').textContent.includes(target.cad),
    $('dSub').textContent);
chk('every contact is ticked by default',
    [...$('dCts').querySelectorAll('input')].every(i => i.checked));
chk('phone coverage is stated',
    $('dCover').textContent.includes('have a phone number on file'), $('dCover').textContent);
chk('coverage warns when nobody has a number',
    (target.c.some(c => c.p)) !== $('dCover').className.includes('warn'));
chk('no sync note on a new appointment', $('dSync').hidden === true);
chk('no delete button on a new appointment', $('dDel').hidden === true);

$('dAgenda').value = 'Walk the boning room';
$('dTime').value = '10:30';
$('dSave').click(); await wait(60);
chk('appointment saved', w.eval('APPTS').length === 1);
const ap = w.eval('APPTS')[0];
chk('appointment carries the full record',
    ['id','acct','type','date','start','dur','agenda','contacts'].every(k => k in ap),
    JSON.stringify(Object.keys(ap)));
chk('appointment landed on the right day', ap.date === w.eval('iso(weekDays()[2])'));
chk('appointment kept the time', ap.start === '10:30');
chk('appointment shows on the grid', $('calBody').querySelectorAll('.appt').length === 1);
chk('appointment reads as not in Outlook', $('calBody').querySelector('.appt').className.includes('s-new'));
chk('home tile counts it', $('planInfo').textContent.includes('1 planned'), $('planInfo').textContent);

/* ---------- title uses a colon, because account names contain hyphens ---------- */
chk('invite title joins with a colon', w.eval('apptTitle')(ap) === ap.type + ': ' + ap.acct,
    w.eval('apptTitle')(ap));

/* ---------- sync state machine ---------- */
chk('a never-downloaded appointment is new', w.eval('apState')(ap) === 'new');
ap.exp = w.eval('apRev')(ap); ap.expAt = Date.now();
chk('once downloaded it is synced', w.eval('apState')(ap) === 'synced');
const before = ap.date;
ap.date = w.eval('iso(weekDays()[4])');
chk('moving it to another day makes it changed', w.eval('apState')(ap) === 'changed');
ap.date = before;
chk('moving it back makes it synced again', w.eval('apState')(ap) === 'synced');
ap.agenda = 'different';
chk('editing the agenda makes it changed', w.eval('apState')(ap) === 'changed');
ap.agenda = 'Walk the boning room';
ap.contacts = [];
chk('changing who is listed makes it changed', w.eval('apState')(ap) === 'changed');
ap.contacts = [...Array(target.c.length).keys()];
chk('the revision string covers exactly the invite fields',
    w.eval('apState')(ap) === 'synced');
ap.icsSeq = 3;
chk('fields outside the invite do not flip it', w.eval('apState')(ap) === 'synced');
chk('pending counts only what Outlook has not got',
    w.eval('pendingAppts')([ap]).length === 0);

/* ---------- drag the appointment to another day ---------- */
await w.eval('saveAppt')(ap);
w.eval('renderPlan()'); await wait(30);
const days2 = $('calBody').querySelectorAll('.day');
fireDrop(w, days2[4], {kind:'appt', id:ap.id});
await wait(60);
chk('dragging moves the appointment', w.eval('APPTS')[0].date === w.eval('iso(weekDays()[4])'));
chk('moving flips it to changed', w.eval('apState')(w.eval('APPTS')[0]) === 'changed');
chk('the card shows changed', $('calBody').querySelector('.appt').className.includes('s-changed'));
chk('home tile flags what is not in Outlook',
    $('planInfo').textContent.includes('not in Outlook'), $('planInfo').textContent);

/* ---------- weekend dates move to a weekday ---------- */
w.eval('openDialog')(ap.id); await wait(30);
chk('editing shows the sync note', $('dSync').hidden === false);
chk('sync note says to download again', $('dSync').textContent.includes('Download again'),
    $('dSync').textContent);
chk('delete is offered on an existing appointment', $('dDel').hidden === false);
$('dDate').value = '2026-09-05';   // a Saturday
$('dSave').click(); await wait(60);
chk('a Saturday is pushed to the Monday', w.eval('APPTS')[0].date === '2026-09-07',
    w.eval('APPTS')[0].date);

/* ---------- persistence across a restart ---------- */
const w2 = boot(store); await wait(180);
chk('appointments survive a restart', w2.eval('APPTS').length === 1, String(w2.eval('APPTS').length));
chk('the restarted appointment kept its agenda',
    w2.eval('APPTS')[0].agenda === 'Walk the boning room');
chk('the restarted appointment kept its sync state',
    w2.eval('apState')(w2.eval('APPTS')[0]) === 'changed');

/* ---------- delete ---------- */
w.eval('openDialog')(ap.id); await wait(30);
$('dDel').click(); await wait(60);
chk('delete removes it from memory', w.eval('APPTS').length === 0);
chk('delete removes it from the store', (await w.eval('apptsAll()')).length === 0);

/* ---------- backup carries the schedule ---------- */
await w.eval('openDialog')(null, {acct: target.a, date: w.eval('iso(weekDays()[1])')});
$('dSave').click(); await wait(60);
const bk = await w.eval('buildBackup')(false);
chk('backup carries appointments', Array.isArray(bk.appts) && bk.appts.length === 1);

const w3 = boot(); await wait(150);
await w3.eval('doRestore')({name:'b.json', text: async () => JSON.stringify(bk)});
await wait(120);
chk('restore brings the schedule back', w3.eval('APPTS').length === 1);
chk('restored appointment kept its account', w3.eval('APPTS')[0].acct === target.a);
// merging, not wiping
await w3.eval('openDialog')(null, {acct: target.a, date: w3.eval('iso(weekDays()[3])')});
w3.document.getElementById('dSave').click(); await wait(60);
await w3.eval('doRestore')({name:'b.json', text: async () => JSON.stringify(bk)});
await wait(100);
chk('restore does not delete an appointment planned only on this device',
    w3.eval('APPTS').length === 2, String(w3.eval('APPTS').length));

/* ---------- re-import drops orphaned appointments ---------- */
const w4 = boot(); await wait(150);
await w4.eval('importCrm')(crmFile); await wait(100);
const acc4 = w4.eval('ACCOUNTS')[0];
await w4.eval('openDialog')(null, {acct: acc4.a, date: w4.eval('iso(weekDays()[0])')});
w4.document.getElementById('dSave').click(); await wait(60);
w4.eval("APPTS.push({id:'ghost', acct:'AN ACCOUNT THAT IS GONE', type:'Intralox site visit', date:'2026-09-07', start:'09:00', dur:60, agenda:'', contacts:[]});");
await w4.eval('apptsPut')(w4.eval('APPTS').find(a => a.id === 'ghost'));
await w4.eval('importCrm')(crmFile); await wait(120);
chk('an appointment against a vanished account is dropped',
    !w4.eval('APPTS').some(a => a.id === 'ghost'));
chk('the real appointment survives the re-import',
    w4.eval('APPTS').some(a => a.acct === acc4.a), String(w4.eval('APPTS').length));
chk('the import report says how many were dropped',
    w4.eval('META').orphanedAppts === 1, String(w4.eval('META').orphanedAppts));
chk('the report line is rendered',
    w4.document.getElementById('impReport').textContent.includes('were dropped'));

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['s-plan','pQ','pMgr','pZone','pChips','pList','calBody','calTitle','pView','dlg',
                  'dType','dDate','dTime','dDur','dAgenda','dCts','dCover','dSync','dDel','dSave','planInfo'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
