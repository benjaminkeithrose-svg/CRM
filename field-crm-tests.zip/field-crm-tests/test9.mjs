import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
const fileOf = (name, text) => ({ name, text: async () => text });

function boot(store) {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = store || new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches:false, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };`);
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
  w.document.querySelector('[data-go="plan"]').click(); await wait(60);
}
const unfold = s => s.replace(/\r\n[ \t]/g, '');
const lines = s => unfold(s).split('\r\n').filter(Boolean);
const val = (s, k) => { const l = lines(s).find(x => x.startsWith(k)); return l ? l.slice(l.indexOf(':')+1) : null; };

const store = new FDBFactory();
const w = boot(store);
const $ = id => w.document.getElementById(id);
await ready(w);
const ACC = w.eval('ACCOUNTS');
const MON = w.eval('iso(startOfWeek(new Date()))');

/* ================= territory weeks ================= */
chk('the territory bar renders', $('terr').innerHTML.length > 0);
chk('it labels the week in week view', $('terr').textContent.includes('Territory this week'),
    $('terr').textContent.slice(0,60));
chk('it offers no marker by default', $('terr').querySelector('select').value === '');
chk('every real zone is offered',
    $('terr').querySelectorAll('select option').length === Object.keys(w.eval('ZONES')).length + 1,
    String($('terr').querySelectorAll('select option').length));
chk('the download button is disabled with nothing set',
    $('terr').querySelector('button').disabled === true);

// suggestion comes from where the calls actually are
const zoneA = ACC.find(a => a.z !== 'Z12');
await w.eval('openDialog')(null, {acct: zoneA.a, date: w.eval('iso(weekDays()[1])')});
$('dSave').click(); await wait(60);
const sug = w.eval('suggestZone')(MON);
chk('a zone is suggested from the booked calls', sug && sug.zone === zoneA.z, JSON.stringify(sug));
chk('the suggestion says how many calls', sug.n === 1);
w.eval('renderTerritory()');
chk('the suggestion shows in the dropdown',
    $('terr').innerHTML.includes('1 call booked'), $('terr').textContent.slice(0,200));

// set the marker
const sel = $('terr').querySelector('select');
sel.value = zoneA.z;
sel.onchange(); await wait(60);
chk('the marker is set', w.eval('WEEKS')[MON].zone === zoneA.z);
chk('it persisted to the store', (await w.eval("kvGet('weeks')"))[MON].zone === zoneA.z);
chk('it reads as not downloaded', w.eval('wkState')(w.eval('WEEKS')[MON]) === 'new');
chk('the bar summarises the state', $('terr').textContent.includes('not downloaded'),
    $('terr').textContent);

/* ---------- the marker ICS ---------- */
w.eval('window.__dl = []');
await w.eval('exportWeeks')('pending'); await wait(60);
const dl = w.eval('window.__dl')[0];
chk('a marker file was written', !!dl && dl.name.startsWith('territory-weeks-'), dl && dl.name);
chk('it is a calendar file', dl.mime.startsWith('text/calendar'));
const ics = dl.text;
chk('it names itself in the calendar list',
    val(ics,'X-WR-CALNAME').includes('territory weeks'), val(ics,'X-WR-CALNAME'));
chk('the marker is an all-day date, not a datetime',
    /^DTSTART;VALUE=DATE:\d{8}$/.test(lines(ics).find(x => x.startsWith('DTSTART'))),
    lines(ics).find(x => x.startsWith('DTSTART')));
chk('there is no VTIMEZONE at all - an all-day date is floating',
    !ics.includes('VTIMEZONE'));
const ds = val(ics,'DTSTART;VALUE=DATE'), de = val(ics,'DTEND;VALUE=DATE');
chk('it starts on the Monday', ds === MON.replace(/-/g,''), ds);
chk('DTEND is the Saturday, because an all-day end is exclusive',
    de === w.eval(`iso(addDays(parseIso('${MON}'),5))`).replace(/-/g,''), de);
chk('it never eats availability', val(ics,'TRANSP') === 'TRANSPARENT');
chk('Outlook is told free, not busy',
    val(ics,'X-MICROSOFT-CDO-BUSYSTATUS') === 'FREE' &&
    val(ics,'X-MICROSOFT-CDO-INTENDEDSTATUS') === 'FREE');
chk('and that it is all day', val(ics,'X-MICROSOFT-CDO-ALLDAYEVENT') === 'TRUE');
chk('the UID is keyed on the Monday, so re-downloading updates it',
    val(ics,'UID:') === 'wk-'+MON+'@field-crm.intralox', val(ics,'UID:'));
chk('the description lists the calls booked that week',
    val(ics,'DESCRIPTION:').includes(w.eval('icsEsc')(zoneA.a)));
chk('the description says it is only a marker',
    val(ics,'DESCRIPTION:').includes('will not block bookings'));
chk('no line exceeds 75 octets',
    ics.split('\r\n').every(l => Buffer.byteLength(l,'utf8') <= 75),
    String(Math.max(...ics.split('\r\n').map(l => Buffer.byteLength(l,'utf8')))));

chk('downloading marks it synced', w.eval('wkState')(w.eval('WEEKS')[MON]) === 'synced');
w.eval('window.__dl = []');
await w.eval('exportWeeks')('pending'); await wait(40);
chk('nothing pending downloads nothing', w.eval('window.__dl').length === 0);
// change the zone and it goes stale
const zoneB = ACC.find(a => a.z !== zoneA.z && a.z !== 'Z12');
if (zoneB) {
  w.eval('WEEKS')[MON].zone = zoneB.z;
  chk('changing the zone makes it changed', w.eval('wkState')(w.eval('WEEKS')[MON]) === 'changed');
  w.eval('window.__dl = []');
  await w.eval('exportWeeks')('pending'); await wait(60);
  chk('SEQUENCE rises on re-download', val(w.eval('window.__dl')[0].text,'SEQUENCE:') === '1',
      val(w.eval('window.__dl')[0].text,'SEQUENCE:'));
} else { ok.push('(only one zone in this file)'); ok.push('(only one zone in this file)'); }

// markers survive a restart
const w2 = boot(store); await wait(200);
chk('markers survive a restart', !!w2.eval('WEEKS')[MON] && !!w2.eval('WEEKS')[MON].zone);
chk('and keep their sync state', w2.eval('wkState')(w2.eval('WEEKS')[MON]) === 'synced');

/* ================= reassignment ================= */
const w3 = boot(); await ready(w3);
const A3 = w3.eval('ACCOUNTS');
const $3 = id => w3.document.getElementById(id);
const acct = A3[0];
const origMgr = acct.mgr;

chk('with nothing moved, effMgr is the CRM manager', w3.eval('effMgr')(acct) === origMgr);
chk('and nothing reads as moved', w3.eval('ACCOUNTS').filter(a => w3.eval('isMoved')(a)).length === 0);

// the rail carries the way in
chk('the rail shows a manager button', $3('pList').innerHTML.includes('class="mgrb'));
chk('the plan bar offers reassignment', !!$3('pReassign'));

w3.eval('openReassign')({account: acct.a}); await wait(40);
chk('the dialog opens', $3('rdlg').hasAttribute('open'));
const scopes = $3('rScope').querySelectorAll('label');
chk('this account only is offered first', scopes[0].textContent.includes('This account only'));
chk('a whole zone is offered', [...scopes].some(l => l.textContent.includes('Every account in')));
chk('the current filtered list is offered',
    [...scopes].some(l => l.textContent.includes('currently listed')));
chk('unassigned is a target', [...$3('rTo').options].some(o => o.value === '__none__'));
chk('a new manager can be added', [...$3('rTo').options].some(o => o.value === '__new__'));
chk('the preview says what will move', $3('rPreview').textContent.includes('Moving'),
    $3('rPreview').textContent);

$3('rTo').value = '__new__'; $3('rTo').onchange();
chk('choosing a new manager reveals the name field', $3('rNewWrap').hidden === false);
$3('rNew').value = 'A New Person'; $3('rNew').oninput();
chk('the preview names the new manager',
    $3('rPreview').textContent.includes('A New Person'), $3('rPreview').textContent);
$3('rApply').click(); await wait(60);
chk('the account moved', w3.eval('effMgr')(acct) === 'A New Person', w3.eval('effMgr')(acct));
chk('it reads as moved', w3.eval('isMoved')(acct) === true);
chk('the CRM value is untouched', w3.eval('ACC_BY_NAME').get(acct.a).mgr === origMgr);
chk('the move persisted', (await w3.eval("kvGet('mgrOf')"))[acct.a] === 'A New Person');
chk('the new manager appears in the manager list',
    w3.eval('allManagers')().includes('A New Person'));
w3.eval('renderPlan()'); await wait(30);
chk('the rail marks it as moved',
    $3('pList').innerHTML.includes('mgrb moved') ||
    !$3('pList').innerHTML.includes('data-acct="'+acct.a+'"'),
    'account visible in rail: ' + $3('pList').innerHTML.includes('data-acct'));

// scoping now follows the override
w3.eval("plan.mgr = 'A New Person'; plan.q = ''");
w3.eval('renderPlan()'); await wait(30);
chk('scoping to the new manager finds the moved account',
    w3.eval('ACCOUNTS').filter(a => w3.eval('inPlanScope')(a)).some(a => a.a === acct.a));
chk('the old manager no longer owns it',
    !w3.eval('ACCOUNTS').filter(a => w3.eval('effMgr')(a) === origMgr).some(a => a.a === acct.a));
// and search finds it by the new name
w3.eval("ACCOUNTS.forEach(a => delete a._hay); plan.q = 'a new person'");
chk('search finds an account by who it was moved to',
    w3.eval('searchAll')().some(a => a.a === acct.a));
w3.eval("plan.q = ''; plan.mgr = ''");

// revert
w3.eval('openReassign')({account: acct.a}); await wait(40);
$3('rRevert').click(); await wait(60);
chk('putting it back restores the CRM manager', w3.eval('effMgr')(acct) === origMgr);
chk('and it no longer reads as moved', w3.eval('isMoved')(acct) === false);

/* ---------- the high-focus cap is projected, not just reported ---------- */
const w4 = boot(); await ready(w4);
const $4 = id => w4.document.getElementById(id);
const A4 = w4.eval('ACCOUNTS');
// force six High-focus accounts into one zone under one manager
const z = A4[0].z;
const six = A4.slice(0, 6);
w4.eval(`ACCOUNTS.forEach(a => { a._hay = undefined; });`);
six.forEach(a => { a.foc = 'High'; a.z = z; });
w4.eval("plan.zone = " + JSON.stringify(z));
w4.eval('openReassign')({}); await wait(40);
$4('rTo').value = '__new__'; $4('rTo').onchange();
$4('rNew').value = 'Overloaded'; $4('rNew').oninput(); await wait(20);
chk('the cap table appears', $4('rCap').innerHTML.includes('caprow'));
chk('a breach is flagged', $4('rCap').innerHTML.includes('over'), $4('rCap').textContent);
chk('the warning explains the remedy',
    $4('rPreview').textContent.includes('split the zone'), $4('rPreview').textContent);
chk('the preview is styled as a warning', $4('rPreview').className.includes('warn'));
chk('the count is projected after the move, not before',
    $4('rCap').textContent.includes('/ 5') && /[6-9] \/ 5/.test($4('rCap').textContent),
    $4('rCap').textContent);
chk('the cap is 5', w4.eval('HIGH_CAP') === 5);
$4('rCancel').click();
chk('cancelling changes nothing', Object.keys(w4.eval('MGR_OF')).length === 0);

/* ---------- the CSV handover ---------- */
w4.eval('openReassign')({}); await wait(30);
$4('rTo').value = '__new__'; $4('rTo').onchange();
$4('rNew').value = 'Handover Person'; $4('rNew').oninput();
$4('rApply').click(); await wait(60);
const csv = w4.eval('reassignCsv')();
const rows = csv.trim().split('\r\n');
chk('the CSV has a header', rows[0].includes('Account Name') && rows[0].includes('Reassigned To'));
chk('the CSV lists only moved accounts',
    rows.length - 1 === w4.eval('ACCOUNTS').filter(a => w4.eval('isMoved')(a)).length,
    `${rows.length-1}`);
chk('the CSV keeps the CRM manager alongside the new one',
    rows[1].split('","').length === 6, rows[1]);
chk('the CSV quotes every field', rows.every(r => r.startsWith('"') && r.endsWith('"')));
chk('a name containing a quote would not break the file',
    w4.eval('reassignCsv').toString().includes('replace(/"/g'));
w4.eval('window.__dl = []');
w4.eval('exportReassignments()');
chk('the CSV downloads under a name someone can act on',
    w4.eval('window.__dl')[0].name === 'manager-reassignments.csv');
chk('the export button appears once something has moved',
    (w4.eval('renderExchange()'), $4('exReassignCsv').hidden === false));

/* ---------- the invite reports the effective manager ---------- */
const moved = w4.eval('ACCOUNTS').find(a => w4.eval('isMoved')(a));
await w4.eval('openDialog')(null, {acct: moved.a, date: w4.eval('iso(weekDays()[0])')});
$4('dSave').click(); await wait(60);
const inv = w4.eval('inviteParts')(w4.eval('APPTS')[0]);
chk('the invite names the manager it was moved to',
    inv.txt.includes('Handover Person'), inv.txt.split('\n')[3]);
chk('and says it was reassigned here rather than in the CRM',
    inv.txt.includes('reassigned here from'), inv.txt.split('\n')[3]);

/* ---------- both ride the exchange, desktop to phone ---------- */
const planFile = await w4.eval('buildPlanFile')(true);
chk('the plan file carries the territory weeks', 'weeks' in planFile);
chk('the plan file carries the reassignments',
    planFile.mgrOf && planFile.mgrOf[moved.a] === 'Handover Person');
const w5 = boot(); await wait(150);
await w5.eval('receiveExchange')(fileOf('p.json', JSON.stringify(planFile)));
await wait(60);
chk('the phone takes the reassignments',
    w5.eval('MGR_OF')[moved.a] === 'Handover Person');
chk('the phone takes the territory weeks',
    JSON.stringify(w5.eval('WEEKS')) === JSON.stringify(planFile.weeks));
chk('and they persisted there', (await w5.eval("kvGet('mgrOf')"))[moved.a] === 'Handover Person');

// backup carries them too
const bk = await w4.eval('buildBackup')(false);
chk('backup carries the weeks and the reassignments',
    'weeks' in bk && bk.mgrOf[moved.a] === 'Handover Person');

/* ---------- a re-import cleans up what no longer exists ---------- */
const w6 = boot(); await ready(w6);
w6.eval("MGR_OF['AN ACCOUNT THAT IS GONE'] = 'Someone'");
w6.eval("WEEKS['2026-01-05'] = {zone:'Z999'}");
await w6.eval("saveMgrOf()"); await w6.eval("saveWeeks()");
await w6.eval('importCrm')(crmFile); await wait(120);
chk('a reassignment against a vanished account is dropped',
    !('AN ACCOUNT THAT IS GONE' in w6.eval('MGR_OF')));
chk('the import report says how many', w6.eval('META').orphanedMoves === 1,
    String(w6.eval('META').orphanedMoves));
chk('a week marker pointing at a zone that does not exist is dropped',
    !('2026-01-05' in w6.eval('WEEKS')));

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['terr','pReassign','rdlg','rScope','rTo','rNew','rNewWrap','rPreview','rCap',
                  'rApply','rRevert','rCancel','exReassignCsv'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
