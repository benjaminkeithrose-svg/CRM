# Test harnesses

Not part of the app. Nothing here is uploaded to the repository.

```
npm install jsdom fake-indexeddb xlsx
node qa.mjs
node test.mjs      # ... through test18.mjs
```

They expect the app files (`index.html`, `app.js`, `zones.js`, `manuals.js`,
`sw.js`, `manifest.webmanifest`) in the same folder, and read two files from
the project library by absolute path:

- `ANZ_Active_template.xlsx`
- `Plant_Audit_Template_1.xlsm`
- `Zone_Call_Planner_v9.html` (the customer-data sweep in `qa.mjs`)
- `zone-overrides.json` (test16 and test17)

| File | Covers |
|---|---|
| `qa.mjs` | Wiring, element ids, duplicate ids, assets, a full walkthrough, bad input, customer-data sweep |
| `test.mjs` | The fork: storage names, boot, a whole call, compile |
| `test2.mjs` | The CRM importer, zones, role ranking, phones, backup and restore |
| `test3.mjs` | Blob photos, async compile, detach after share |
| `test4.mjs` | Account view, visit history, cadence basis, call status |
| `test5.mjs` | The ported planner: rail, calendar, drag and drop, dialog, persistence |
| `test6.mjs` | ICS export: RFC structure, folding, timezones, UID and SEQUENCE |
| `test7.mjs` | Today and This Week, close out, move, missed |
| `test8.mjs` | The device exchange: merge, deletion in range, conflicts, transport |
| `test9.mjs` | Territory weeks and manager reassignment |
| `test10.mjs` | Cadence: booked state, coverage, needs-booking filter |
| `test11.mjs` | Dual-body notes into the invite, `call-notes.csv` |
| `test12.mjs` | History navigation and dialog entries |
| `test13.mjs` | Account history in the compiled notes |
| `test14.mjs` | The Android share target and the file router |
| `test15.mjs` | Unplanned calls booking themselves |
| `test16.mjs` | Booking ahead, same-week reuse, load log, the two folders |
| `test17.mjs` | GitHub appointment sync |
| `test18.mjs` | Project carry-forward, health history, required severity, camera on the form |

Roughly 1,370 assertions. What they cannot reach is listed in
`PROJECT_INSTRUCTIONS.md` section 6.
