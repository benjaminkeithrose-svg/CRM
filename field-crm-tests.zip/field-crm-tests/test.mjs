import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';

const fail = [];
const ok = [];
const chk = (name, cond, extra='') => (cond ? ok : fail).push(name + (extra ? ' :: ' + extra : ''));

const html = fs.readFileSync('index.html', 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://example.github.io/field-crm/', pretendToBeVisual: true });
const w = dom.window;

w.indexedDB = new FDBFactory();
w.IDBKeyRange = FDBKeyRange;
w.navigator.storage = { persist: async () => true };
w.scrollTo = () => {};
w.XLSX = null;
w.confirm = () => true;
w.URL.createObjectURL = () => 'blob:x';
w.URL.revokeObjectURL = () => {};

const appjs = fs.readFileSync('app.js', 'utf8');
const el = w.document.createElement('script');
el.textContent = appjs;
w.document.body.appendChild(el);
const $ = id => w.document.getElementById(id);
const wait = ms => new Promise(r => setTimeout(r, ms));
await wait(120);

/* ---- 1. storage names ---- */
chk('DB opened is fieldcrm', w.eval('DB_NAME') === 'fieldcrm', w.eval('DB_NAME'));
const dbs = await w.indexedDB.databases();
chk('no beltcall database created', !dbs.some(d => d.name === 'beltcall'), JSON.stringify(dbs));
chk('fieldcrm database created', dbs.some(d => d.name === 'fieldcrm'), JSON.stringify(dbs));
const appNoComments = appjs.replace(/\/\*[\s\S]*?\*\//g,'').replace(/^\s*\/\/.*$/gm,'');
chk('no beltcall name in app.js code', !appNoComments.includes('beltcall'));
chk('no beltmanuals name in app.js code', !appNoComments.includes('beltmanuals'));
chk('no beltcall string anywhere in index.html', !html.includes('beltcall'));

/* ---- 2. boot did not throw, home rendered ---- */
chk('home screen is showing', $('s-home').classList.contains('on'));
chk('title is Field CRM', $('title').textContent === 'Field CRM', $('title').textContent);
chk('date defaulted', /^\d{4}-\d{2}-\d{2}$/.test($('cDate').value), $('cDate').value);
// v8's five flight rows are gone; v13 drives the whole form off the reference data
chk('the belt form has its skip toggles',
    w.document.querySelectorAll('#s-belt input[type=checkbox]').length === 4,
    String(w.document.querySelectorAll('#s-belt input[type=checkbox]').length));
chk('and the series picker is there', !!w.document.getElementById('bSeries'));

/* ---- 3. localStorage prefix ---- */
$('cMgr').value = $('cMgr').options[0].value;
$('cMgr').dispatchEvent(new w.Event('change'));
chk('localStorage key is fcrm.mgr', w.localStorage.getItem('fcrm.mgr') !== null,
     JSON.stringify(Object.keys(w.localStorage)));
chk('bare mgr key not used', w.localStorage.getItem('mgr') === null);

/* ---- 4. drive a whole call: manual account -> contacts -> entries ---- */
$('accManual').value = 'Woodward Foods Australia — Pty Ltd';
$('accManualGo').click();
await wait(60);
chk('contacts screen after manual account', $('s-contacts').classList.contains('on'));

$('ncName').value = 'Adam Buckley';
$('ncRole').value = 'Maintenance Manager';
$('ncEmail').value = 'adam@example.com';
$('cSite').value = 'Boning room';
$('openCall').click();
await wait(80);
chk('dashboard opened', $('s-dash').classList.contains('on'));
chk('photo bar visible in call', $('bar').style.display === 'flex', $('bar').style.display);

// belt
w.eval("go('belt')");
$('bAsset').value = '61-156 boning line 2';
$('bDesc').value = 'S800OHFT';
$('bWidth').value = '606';
$('bCvLen').value = '9';
$('bSprDesc').value = 'S40 8T';
w.document.querySelector('#bRetro button[data-v="N"]').click();
$('bSave').click();
await wait(80);
chk('belt logged, back on dash', $('s-dash').classList.contains('on'));
chk('belt count shows 1', $('cntBelt').textContent.startsWith('1'), $('cntBelt').textContent);

// health
w.eval("go('health')");
$('hAsset').value = 'CV-114 drive end';
$('hFault').value = 'Sprocket teeth worn, belt tracking right';
w.document.querySelector('#hSev button[data-v="Plan"]').click();
$('hSave').click();
await wait(80);
chk('health count shows 1', $('cntHealth').textContent.startsWith('1'), $('cntHealth').textContent);

// note + project
w.eval("go('note')");
$('nText').value = 'Kill rate up to 180k/week';
$('nSave').click();
await wait(60);
w.eval("go('project')");
$('pName').value = 'Nitrogen tunnel';
$('pTarg').value = 'Q3 2026';
$('pSave').click();
await wait(80);
chk('note count shows 1', $('cntNote').textContent.startsWith('1'), $('cntNote').textContent);
chk('project count shows 1', $('cntProj').textContent.startsWith('1'), $('cntProj').textContent);

/* ---- 5. persistence: read the record straight back out of IndexedDB ---- */
const saved = await w.eval('callsAll()');
chk('one call persisted', saved.length === 1, String(saved.length));
chk('four entries persisted', saved[0] && saved[0].entries.length === 4,
     saved[0] ? String(saved[0].entries.length) : 'none');
chk('manual account flagged', saved[0] && saved[0].manualAccount === true);

/* ---- 6. compile ---- */
w.eval("go('compile')");
await wait(60);
const out = await w.eval('buildNotesHTML()');
chk('notes contain the belt', out.includes('61-156 boning line 2'));
chk('notes contain the health item', out.includes('CV-114 drive end'));
chk('notes contain the project', out.includes('Nitrogen tunnel'));
chk('notes carry the red box masthead', out.includes('class="mast"') && out.includes('data:image/png;base64,iVBOR'));
chk('notes use Roboto first', out.includes('font-family:Roboto,Arial'));
chk('no leftover jpeg logo', !out.includes('data:image/jpeg'));
chk('em dash for unpopulated cells', out.includes('\u2014'));
chk('page-break rule intact', out.includes('page-break-inside:avoid'));
chk('mast div is closed by pg wrapper', (out.match(/<div class="pg">/g)||[]).length === 1);
// escaping: the account name carries an em dash and the notes must not break
chk('account name escaped into notes', out.includes('Woodward Foods Australia'));
const fn = w.eval('fileName()');
chk('filename collapses punctuation', /^Woodward_Foods_Australia_.*_call_notes_\d{2}-\d{2}-\d{4}\.html$/.test(fn), fn);

/* ---- 7. tag balance in the generated HTML ---- */
const opens = (out.match(/<div\b/g)||[]).length, closes = (out.match(/<\/div>/g)||[]).length;
chk('div tags balanced in notes', opens === closes, opens + ' open / ' + closes + ' close');
const topens = (out.match(/<table\b/g)||[]).length, tcloses = (out.match(/<\/table>/g)||[]).length;
chk('table tags balanced in notes', topens === tcloses, topens + ' / ' + tcloses);

/* ---- 8. sw.js and manifest agree ---- */
const sw = fs.readFileSync('sw.js','utf8');
const mf = JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));
chk('cache uses the fieldcrm- prefix', /const CACHE = 'fieldcrm-v\d+'/.test(sw));
chk('sw does not cache logo.png', !sw.includes('logo.png'));
for (const ic of mf.icons) chk('sw caches ' + ic.src, sw.includes('./' + ic.src));
chk('index.html does not reference logo.png', !html.includes('logo.png'));
chk('index.html references manifest', html.includes('manifest.webmanifest'));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
