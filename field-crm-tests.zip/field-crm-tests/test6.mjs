import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

let downloads = [];
function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  const d = w.document.getElementById('dlg');
  d.showModal = function(){ this.setAttribute('open',''); };
  d.close = function(){ this.removeAttribute('open'); };
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  // capture what downloadFile hands over instead of writing it
  w.eval(`downloadFile = function(name, text, mime){ window.__dl = window.__dl || []; window.__dl.push({name, text, mime}); };`);
  return w;
}
// unfold a folded ICS body back into logical lines, the way a client would
const unfold = s => s.replace(/\r\n[ \t]/g, '');
const lines = s => unfold(s).split('\r\n').filter(Boolean);
const val = (s, key) => {
  const l = lines(s).find(x => x.startsWith(key));
  return l ? l.slice(l.indexOf(':') + 1) : null;
};

const w = boot();
const $ = id => w.document.getElementById(id);
await wait(150);
await w.eval('importCrm')(crmFile); await wait(100);
await w.eval('renderHome()');
w.document.querySelector('[data-go="plan"]').click(); await wait(60);
const ACC = w.eval('ACCOUNTS');

/* ---------- escaping and folding ---------- */
const ie = s => w.eval('icsEsc')(s);
chk('semicolons escaped', ie('a;b') === 'a\\;b', ie('a;b'));
chk('commas escaped', ie('a,b') === 'a\\,b', ie('a,b'));
chk('backslashes escaped first', ie('a\\b') === 'a\\\\b', ie('a\\b'));
chk('newlines become \\n', ie('a\nb') === 'a\\nb', ie('a\nb'));
chk('ICS escaping is not HTML escaping', ie('<b>&</b>') === '<b>&</b>', ie('<b>&</b>'));
chk('HTML escaping still works separately', w.eval('esc')('<b>') === '&lt;b&gt;');

const bl = s => Buffer.byteLength(s, 'utf8');
const long = 'DESCRIPTION:' + 'x'.repeat(400);
const folded = w.eval('fold')(long);
chk('long lines are folded', folded.includes('\r\n '));
chk('no folded line exceeds 75 octets',
    folded.split('\r\n').every(l => bl(l) <= 75),
    String(Math.max(...folded.split('\r\n').map(bl))));
chk('folding packs to the limit rather than wasting space',
    folded.split('\r\n').slice(0,-1).every(l => bl(l) >= 74),
    JSON.stringify(folded.split('\r\n').map(bl)));
chk('unfolding restores the original', unfold(folded) === long);
chk('a short line is left alone', w.eval('fold')('SUMMARY:short') === 'SUMMARY:short');
// the reason this had to change: multi-byte separators in the invite body
const wide = 'DESCRIPTION:' + '\u2014'.repeat(200);   // em dash, 3 octets each
const wf = w.eval('fold')(wide);
chk('multi-byte content still folds inside 75 octets',
    wf.split('\r\n').every(l => bl(l) <= 75),
    String(Math.max(...wf.split('\r\n').map(bl))));
chk('folding never splits a character', unfold(wf) === wide && !wf.includes('\ufffd'));
chk('a line that is short in characters but long in octets is still folded',
    w.eval('fold')('X:' + '\u2014'.repeat(30)).includes('\r\n '));

/* ---------- local time arithmetic ---------- */
chk('start time renders as local', w.eval("dtLocal('2026-09-07','09:30',0)") === '20260907T093000',
    w.eval("dtLocal('2026-09-07','09:30',0)"));
chk('duration is added in minutes', w.eval("dtLocal('2026-09-07','09:30',60)") === '20260907T103000');
chk('a duration rolling past midnight carries the date',
    w.eval("dtLocal('2026-09-07','23:30',60)") === '20260908T003000',
    w.eval("dtLocal('2026-09-07','23:30',60)"));

/* ---------- VTIMEZONE ---------- */
const syd = w.eval("vtimezone('Australia/Sydney')").join('|');
chk('Sydney gets both standard and daylight blocks',
    syd.includes('BEGIN:STANDARD') && syd.includes('BEGIN:DAYLIGHT'));
chk('Sydney daylight rule is the first Sunday in October',
    syd.includes('FREQ=YEARLY;BYMONTH=10;BYDAY=1SU'));
const bne = w.eval("vtimezone('Australia/Brisbane')").join('|');
chk('Brisbane has no daylight block', !bne.includes('BEGIN:DAYLIGHT'));
chk('Brisbane still declares standard time', bne.includes('TZNAME:AEST'));
const akl = w.eval("vtimezone('Pacific/Auckland')").join('|');
chk('Auckland daylight ends on the last Sunday in April',
    akl.includes('BYMONTH=4;BYDAY=1SU') || akl.includes('BYMONTH=4'));
chk('Auckland is offset 12/13', akl.includes('+1300') && akl.includes('+1200'));
chk('an unknown timezone yields nothing rather than a broken block',
    w.eval("vtimezone('Mars/Olympus')").length === 0);
chk('every zone in the map has a timezone the table knows',
    Object.values(w.eval('ZONES')).every(z => !z.tz || w.eval('TZDB')[z.tz]),
    JSON.stringify([...new Set(Object.values(w.eval('ZONES')).map(z => z.tz))]));

/* ---------- build an appointment and export it ---------- */
const target = ACC.find(a => a.c.length > 0) || ACC[0];
w.eval('openDialog')(null, {acct: target.a, date: w.eval('iso(weekDays()[2])')});
$('dAgenda').value = 'Walk the boning room; check line 2, 3';
$('dTime').value = '09:30';
$('dDur').value = '90';
$('dSave').click(); await wait(60);
const ap = w.eval('APPTS')[0];

chk('export is offered', !!$('pExport') && !!$('pExportAll'));
$('pExport').click(); await wait(80);
const dl = w.eval('window.__dl');
chk('a file was handed over', dl && dl.length === 1);
chk('it is a calendar file', dl[0].mime.startsWith('text/calendar'), dl[0].mime);
chk('filename carries the week', /^field-calls-\d{4}-\d{2}-\d{2}\.ics$/.test(dl[0].name), dl[0].name);
const ics = dl[0].text;

/* ---------- RFC structure ---------- */
const L = lines(ics);
chk('starts with VCALENDAR', L[0] === 'BEGIN:VCALENDAR');
chk('ends with VCALENDAR', L[L.length-1] === 'END:VCALENDAR');
chk('declares version 2.0', L.includes('VERSION:2.0'));
chk('PRODID names Field CRM', val(ics,'PRODID').includes('Field CRM'), val(ics,'PRODID'));
chk('every BEGIN has an END',
    L.filter(x => x.startsWith('BEGIN:')).length === L.filter(x => x.startsWith('END:')).length);
chk('one VEVENT', L.filter(x => x === 'BEGIN:VEVENT').length === 1);
chk('lines are CRLF terminated', ics.endsWith('\r\n') && !/[^\r]\n/.test(ics));
chk('no line exceeds 75 octets',
    ics.split('\r\n').every(l => Buffer.byteLength(l,'utf8') <= 75),
    String(Math.max(...ics.split('\r\n').map(l => Buffer.byteLength(l,'utf8')))));

/* ---------- the three things that carry it ---------- */
// look inside the VEVENT: VTIMEZONE blocks carry their own DTSTART
const ev = unfold(ics).split('BEGIN:VEVENT')[1].split('END:VEVENT')[0].split('\r\n').filter(Boolean);
const evVal = key => { const l = ev.find(x => x.startsWith(key)); return l ? l.slice(l.indexOf(':')+1) : null; };
const uid = val(ics,'UID:');
chk('UID is present', !!uid);
chk('UID contains no date', !/\d{4}-?\d{2}-?\d{2}/.test(uid), uid);
chk('UID is derived from the appointment id', uid.startsWith(ap.id + '@'), uid);
chk('SEQUENCE starts at zero', val(ics,'SEQUENCE:') === '0', val(ics,'SEQUENCE:'));
const dtsLine = ev.find(x => x.startsWith('DTSTART'));
chk('DTSTART carries a TZID', /^DTSTART;TZID=/.test(dtsLine), dtsLine);
chk('DTSTART matches the appointment time', dtsLine.endsWith('T093000'), dtsLine);
chk('DTEND is 90 minutes later', ev.find(x => x.startsWith('DTEND')).endsWith('T110000'),
    ev.find(x => x.startsWith('DTEND')));
const tzidMatch = dtsLine.match(/TZID=([^:;]+)/);
chk('the VTIMEZONE for that TZID is included',
    !!tzidMatch && ics.includes('TZID:' + tzidMatch[1]), dtsLine);
chk('a site visit is marked out of office', val(ics,'X-MICROSOFT-CDO-BUSYSTATUS') === 'OOF',
    val(ics,'X-MICROSOFT-CDO-BUSYSTATUS'));
chk('SUMMARY is type colon account', val(ics,'SUMMARY:') === w.eval('icsEsc')(ap.type + ': ' + ap.acct),
    val(ics,'SUMMARY:'));
chk('LOCATION carries suburb and account', val(ics,'LOCATION:').includes(w.eval('icsEsc')(target.a)));
chk('CATEGORIES carry zone and focus',
    val(ics,'CATEGORIES:').includes(target.z) && val(ics,'CATEGORIES:').includes(w.eval('icsEsc')(target.foc)),
    val(ics,'CATEGORIES:'));

/* ---------- the invite body ---------- */
const desc = val(ics,'DESCRIPTION:');
chk('agenda semicolon and comma survived escaping',
    desc.includes('Walk the boning room\\; check line 2\\, 3'), desc.slice(0,120));
chk('description lists the contacts section', desc.includes('CONTACTS'));
chk('description names the zone', desc.includes('Zone: '));
chk('description states phone coverage', desc.includes('have a number on file'));
const alt = val(ics,'X-ALT-DESC;FMTTYPE=text/html');
chk('an HTML alternative is included', !!alt && alt.includes('<html>'));
chk('HTML body uses Arial, not a webfont', alt.includes('font-family:Arial') && !alt.includes('Roboto'));
chk('HTML body carries the Intralox red rule', alt.includes('#ED1C24'));
chk('HTML body is styled inline only', !alt.includes('<style'));
if (target.c.some(c => !c.p))
  chk('missing numbers are called out in red', alt.includes('no number on file'));
else ok.push('every contact on this account has a number (missing-number path not exercised)');

/* ---------- the handshake ---------- */
chk('exporting marked it synced', w.eval('apState')(w.eval('APPTS')[0]) === 'synced');
chk('exporting recorded when', typeof w.eval('APPTS')[0].expAt === 'number');
const stored = (await w.eval('apptsAll()'))[0];
chk('the sync state was written to the store, not just held in memory',
    stored.exp === w.eval('apRev')(stored), JSON.stringify({exp: !!stored.exp}));

// nothing pending now
w.eval('window.__dl = []');
$('pExport').click(); await wait(60);
chk('a second pending export does nothing', w.eval('window.__dl').length === 0);

// edit it, and SEQUENCE must rise
w.eval('openDialog')(ap.id); await wait(30);
$('dTime').value = '11:00';
$('dSave').click(); await wait(60);
chk('editing flips it back to changed', w.eval('apState')(w.eval('APPTS')[0]) === 'changed');
w.eval('window.__dl = []');
$('pExport').click(); await wait(80);
const ics2 = w.eval('window.__dl')[0].text;
chk('SEQUENCE rose on re-export', val(ics2,'SEQUENCE:') === '1', val(ics2,'SEQUENCE:'));
chk('UID did not change, so Outlook updates in place', val(ics2,'UID:') === uid);
chk('the new time is in the file', ics2.includes('T110000'));

// re-download everything: SEQUENCE must not rise for an unchanged event
w.eval('window.__dl = []');
$('pExportAll').click(); await wait(80);
const ics3 = w.eval('window.__dl')[0].text;
chk('re-downloading an unchanged appointment does not bump SEQUENCE',
    val(ics3,'SEQUENCE:') === '1', val(ics3,'SEQUENCE:'));
chk('re-download all is named differently', w.eval('window.__dl')[0].name.endsWith('-all.ics'));

/* ---------- scope: only what is on screen ---------- */
w.eval('openDialog')(null, {acct: target.a, date: '2027-03-15'});
w.document.getElementById('dSave').click(); await wait(60);
chk('two appointments now exist', w.eval('APPTS').length === 2);
w.eval('window.__dl = []');
$('pExportAll').click(); await wait(80);
chk('export covers only the week on screen',
    lines(w.eval('window.__dl')[0].text).filter(x => x === 'BEGIN:VEVENT').length === 1,
    String(lines(w.eval('window.__dl')[0].text).filter(x => x === 'BEGIN:VEVENT').length));
// switch to month view and the scope widens
[...$('pView').querySelectorAll('button')].find(b => b.dataset.v === 'month').click(); await wait(30);
chk('inRange follows the month when the view does',
    w.eval('inRange')({date: w.eval('iso(weekDays()[0])')}) === true);
chk('a date in another year is out of range', w.eval('inRange')({date:'2027-03-15'}) === false);

/* ---------- multiple timezones in one file ---------- */
const w2 = boot(); await wait(150);
await w2.eval('importCrm')(crmFile); await wait(100);
const A2 = w2.eval('ACCOUNTS');
const tzOf = a => w2.eval('zoneTz')(a.z);
const seen = new Map();
A2.forEach(a => { if (!seen.has(tzOf(a))) seen.set(tzOf(a), a); });
const picks = [...seen.values()].slice(0, 3);
for (const [i, a] of picks.entries()) {
  await w2.eval('openDialog')(null, {acct: a.a, date: w2.eval(`iso(weekDays()[${i}])`)});
  w2.document.getElementById('dSave').click(); await wait(40);
}
const multi = w2.eval('buildIcs')(w2.eval('APPTS'));
const tzids = [...new Set(picks.map(tzOf))];
for (const t of tzids) chk('VTIMEZONE emitted for ' + t, multi.includes('TZID:' + t));
chk('one VTIMEZONE block per distinct timezone, no duplicates',
    lines(multi).filter(x => x === 'BEGIN:VTIMEZONE').length === tzids.length,
    `${lines(multi).filter(x => x === 'BEGIN:VTIMEZONE').length} vs ${tzids.length}`);
chk('every event references a declared TZID',
    lines(multi).filter(x => x.startsWith('DTSTART;TZID='))
      .every(l => multi.includes('TZID:' + l.match(/TZID=([^:]+)/)[1])));

/* ---------- unverified timezone is flagged, not silently guessed ---------- */
chk('Z12 is marked as an assumed timezone', w2.eval("zoneTzAssumed('Z12')") === true);
chk('a real zone is not', w2.eval("zoneTzAssumed('Z1')") === false);
chk('an unknown zone falls back and is flagged',
    w2.eval("zoneTz('Z99')") === 'Australia/Sydney' && w2.eval("zoneTzAssumed('Z99')") === true);
// declining the warning cancels the export
const w3 = boot(); await wait(150);
await w3.eval('importCrm')(crmFile); await wait(100);
const z12 = w3.eval('ACCOUNTS').find(a => a.z === 'Z12');
if (z12) {
  await w3.eval('openDialog')(null, {acct: z12.a, date: w3.eval('iso(weekDays()[1])')});
  w3.document.getElementById('dSave').click(); await wait(40);
  w3.confirm = () => false;
  w3.eval('window.__dl = []');
  w3.document.getElementById('pExport').click(); await wait(60);
  chk('declining the timezone warning cancels the download', w3.eval('window.__dl').length === 0);
  chk('and the appointment stays pending',
      w3.eval('apState')(w3.eval('APPTS')[0]) === 'new');
} else ok.push('no Z12 account in this file (timezone warning not exercised)');

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['pExport','pExportAll']) chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
