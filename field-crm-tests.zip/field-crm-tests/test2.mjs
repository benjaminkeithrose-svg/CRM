import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const XLSX = require('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));

const SRC = '/mnt/project/ANZ_Active_template.xlsx';

function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://example.github.io/field-crm/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory();
  w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {};
  w.XLSX = XLSX;
  w.confirm = () => true;
  w.URL.createObjectURL = () => 'blob:x';
  w.URL.revokeObjectURL = () => {};
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
const wait = ms => new Promise(r => setTimeout(r, ms));

// A File-alike the app's readRows() can consume.
function fileOf(path, name) {
  const buf = fs.readFileSync(path);
  return {
    name,
    arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength),
    text: async () => buf.toString('utf8')
  };
}

/* ================= expectations derived from the source workbook ================= */
const wb = XLSX.readFile(SRC);
const sheet = wb.SheetNames[0];
const raw = XLSX.utils.sheet_to_json(wb.Sheets[sheet], { defval:'', raw:false });
const hdr = Object.keys(raw[0]);
const expAccts = new Set(raw.map(r => String(r['Account Name']||'').trim()).filter(Boolean));
const expRows = raw.length;
console.log(`source: ${expRows} rows, ${expAccts.size} accounts, ${hdr.length} columns`);

chk('workbook has the leading-space Full Name column', hdr.includes(' Full Name'));
chk('workbook has a hiddenSheet', wb.SheetNames.some(n => n.toLowerCase()==='hiddensheet'));

const w = boot();
const $ = id => w.document.getElementById(id);
await wait(120);

/* ---------- zones ship and are geography only ---------- */
const zonesJs = fs.readFileSync('zones.js','utf8');
chk('zones.js loaded 31 zones', Object.keys(w.eval('ZONES')).length === 31,
    String(Object.keys(w.eval('ZONES')).length));
const acctNames = [...expAccts];
chk('zones.js contains no account names from the export',
    !acctNames.some(n => zonesJs.toUpperCase().includes(n.toUpperCase())));
chk('zones.js has no email addresses', !/@/.test(zonesJs));
chk('overrides start empty', Object.keys(w.eval('OVERRIDES.acctZone')).length === 0);

/* ---------- role ranking covers the whole picklist ---------- */
const hs = XLSX.utils.sheet_to_json(wb.Sheets['hiddenSheet'], { header:1, defval:'' });
const picklist = hs[2].filter(Boolean);
chk('picklist read from hiddenSheet has 17 roles', picklist.length === 17, String(picklist.length));
const ranks = picklist.map(r => [r, w.eval(`roleRank(${JSON.stringify(r)})`)]);
const unranked = ranks.filter(([, n]) => n === 99);
chk('every picklist role is ranked', unranked.length === 0, JSON.stringify(unranked));
chk('ranks are unique across the picklist',
    new Set(ranks.map(r => r[1])).size === picklist.length,
    JSON.stringify(ranks.map(r => r[1])));
chk('Engineer - Packaging does not fall through to Engineer',
    w.eval("roleRank('Engineer - Packaging')") !== w.eval("roleRank('Engineer')"));
chk('Hygienic / Sanitation ranks above a blank role',
    w.eval("roleRank('Hygienic / Sanitation')") < w.eval("roleRank('')"));
chk('Maintenance still ranks first', w.eval("roleRank('Maintenance')") === 1);

/* ---------- phone normalising ---------- */
const ph = e => w.eval(`JSON.stringify(normPhone(${JSON.stringify(e)}))`);
chk('AU mobile formats', JSON.parse(ph('+61412345678'))[1] === 'mobile', ph('+61412345678'));
chk('AU landline formats', JSON.parse(ph('0298765432'))[1] === 'landline', ph('0298765432'));
chk('NZ mobile with +64 now normalises', JSON.parse(ph('+6421123456'))[1] === 'mobile', ph('+6421123456'));
chk('NZ landline with +64 now normalises', JSON.parse(ph('+6493456789'))[1] === 'landline', ph('+6493456789'));
chk('bare 021 stays Australian, not guessed as NZ',
    JSON.parse(ph('0212345678'))[1] === 'landline', ph('0212345678'));
chk('junk still returns check', JSON.parse(ph('ask reception'))[1] === 'check', ph('ask reception'));
chk('empty returns none', JSON.parse(ph(''))[1] === 'none');

/* ---------- suburb and zone lookup ---------- */
chk('suburbOf splits on the spaced hyphen',
    w.eval("suburbOf('BAIADA POULTRY - HANWOOD')") === 'HANWOOD',
    w.eval("suburbOf('BAIADA POULTRY - HANWOOD')"));
chk('suburbOf returns null with no suburb', w.eval("suburbOf('WOODWARD FOODS') === null"));
chk('unresolvable suburb falls to Z12', w.eval("zoneOf('X - NOWHERETOWN','NOWHERETOWN')") === 'Z12');

/* ---------- import the real export ---------- */
await w.eval('importCrm')(fileOf(SRC, 'ANZ_Active_template.xlsx'));
await wait(80);
const meta = w.eval('META');
chk('every account in the file was imported', meta.counts.accounts === expAccts.size,
    `${meta.counts.accounts} vs ${expAccts.size}`);
chk('row count recorded matches the sheet', meta.rows === expRows, `${meta.rows} vs ${expRows}`);
chk('hiddenSheet preserved for write-back', Array.isArray(meta.hiddenSheet) && meta.hiddenSheet.length > 0);
const schemaBlob = JSON.stringify(meta.hiddenSheet);
for (const f of ['new_accountfocus','new_accountmanager','parentcustomerid','checksumLogicalName'])
  chk('hiddenSheet carries ' + f, schemaBlob.includes(f));

const accounts = w.eval('ACCOUNTS');
chk('accounts are in IndexedDB', (await w.eval('accAll()')).length === expAccts.size);
chk('every account has a zone', accounts.every(a => a.z && /^Z\d+$/.test(a.z)));
chk('every account has a cadence', accounts.every(a => a.cad));

// dedupe: contact count must be <= raw rows, and no duplicate names inside an account
const totalContacts = accounts.reduce((n,a) => n + a.c.length, 0);
chk('contacts do not exceed source rows', totalContacts <= expRows, `${totalContacts} vs ${expRows}`);
chk('no duplicate contact names within an account',
    accounts.every(a => new Set(a.c.map(c => c.n.toLowerCase())).size === a.c.length));

// dedupe check against a hand-computed expectation from the source
const byAcct = {};
for (const r of raw) {
  const a = String(r['Account Name']||'').trim(); if (!a) continue;
  let n = String(r[' Full Name']||'').trim();
  if (!n || n === '.' || n === '. .') n = (String(r['First Name']||'').trim()+' '+String(r['Last Name']||'').trim()).trim();
  if (!n || n === '.') continue;
  (byAcct[a] = byAcct[a] || new Set()).add(n.toLowerCase());
}
const expContacts = Object.values(byAcct).reduce((n,s) => n + s.size, 0);
chk('deduped contact count matches independent count', totalContacts === expContacts,
    `${totalContacts} vs ${expContacts}`);

// planner ordering: role rank then name
chk('contacts are role-ranked within each account',
    accounts.every(a => a.c.every((c,i) => i===0 ||
      w.eval(`roleRank(${JSON.stringify(a.c[i-1].r)})`) <= w.eval(`roleRank(${JSON.stringify(c.r)})`))));

// multiple emails kept, phone flag kept, write-back ids kept
const anyC = accounts.flatMap(a => a.c);
chk('emails are kept as an array', anyC.every(c => Array.isArray(c.e)));
chk('phone quality flag on every contact', anyC.every(c => ['mobile','landline','check','none'].includes(c.pk)));
chk('contact GUID kept for write-back', anyC.some(c => c.id));
chk('row checksum kept for write-back', anyC.some(c => c.chk));
chk('Contact Type read', anyC.some(c => c.ct));
chk('Last Appointment read', accounts.some(a => a.lastAppt) || raw.every(r => !String(r['Last Appointment (Account Name) (Account)']||'').trim()));
chk('Industry Team read', accounts.some(a => a.team));

/* ---------- csv path lands in the same place ---------- */
const csvPath = '/tmp/export.csv';
fs.writeFileSync(csvPath, XLSX.utils.sheet_to_csv(wb.Sheets[sheet]));
const w2 = boot();
await wait(120);
await w2.eval('importCrm')(fileOf(csvPath, 'export.csv'));
await wait(80);
const a2 = w2.eval('ACCOUNTS');
chk('csv import yields the same account count', a2.length === accounts.length, `${a2.length} vs ${accounts.length}`);
chk('csv import yields the same contact count',
    a2.reduce((n,a)=>n+a.c.length,0) === totalContacts);
chk('csv import has no hiddenSheet and says so', w2.eval('META').hiddenSheet === null);

/* ---------- overrides change the answer ---------- */
const target = accounts.find(a => a.z === 'Z12') || accounts[0];
const ovFile = { name:'zone-overrides.json',
  text: async () => JSON.stringify({ acctZone: { [target.a]: 'Z31' }, spelling: {} }) };
await w.eval('importOverrides')(ovFile);
chk('override is stored', w.eval('OVERRIDES.acctZone')[target.a] === 'Z31');
chk('override wins outright in zoneOf',
     w.eval(`zoneOf(${JSON.stringify(target.a)}, suburbOf(${JSON.stringify(target.a)}))`) === 'Z31');

/* ---------- log a call, then back up and restore into a fresh database ---------- */
$('accManual').value = 'Test Site - Somewhere';
$('accManualGo').click();
await wait(60);
$('ncName').value = 'A Person';
$('openCall').click();
await wait(80);
w.eval("go('belt')");
$('bAsset').value = 'CV-99 line 1';
$('bWidth').value = '606';
$('bSave').click();
await wait(80);
// a photo, so the strip-photos path is exercised
w.eval("call.entries[0].photos = ['data:image/jpeg;base64,AAAA']; call.loose = ['data:image/jpeg;base64,BBBB'];");
await w.eval('saveCall()');

const bk = await w.eval('buildBackup')(false);
chk('backup is tagged', bk.format === 'fieldcrm-backup' && bk.version === 1);
chk('backup carries every account', bk.accounts.length === accounts.length);
chk('backup carries the call', bk.calls.length === 1);
chk('structured backup strips image data',
    JSON.stringify(bk.calls).indexOf('data:image') === -1);
chk('structured backup records how many photos there were',
    bk.calls[0].entries[0].photoCount === 1 && bk.calls[0].looseCount === 1,
    JSON.stringify({p:bk.calls[0].entries[0].photoCount, l:bk.calls[0].looseCount}));
chk('backup carries the overrides', bk.overrides.acctZone[target.a] === 'Z31');
chk('backup carries the import meta', !!bk.meta && bk.meta.counts.accounts === accounts.length);

const full = await w.eval('buildBackup')(true);
chk('full backup keeps image data', JSON.stringify(full.calls).includes('data:image'));

// restore into a completely fresh install
const w3 = boot();
await wait(120);
chk('fresh install starts empty', w3.eval('ACCOUNTS').length === 0 && w3.eval('META') === null);
const bkFile = { name:'backup.json', text: async () => JSON.stringify(bk) };
await w3.eval('doRestore')(bkFile);
await wait(120);
chk('restore brought the accounts back', w3.eval('ACCOUNTS').length === accounts.length,
    String(w3.eval('ACCOUNTS').length));
chk('restore brought the call back', (await w3.eval('callsAll()')).length === 1);
const rc = (await w3.eval('callsAll()'))[0];
chk('restored call keeps its entries', rc.entries.length === 1 && rc.entries[0].asset === 'CV-99 line 1');
chk('restore brought the overrides back', w3.eval('OVERRIDES.acctZone')[target.a] === 'Z31');
chk('restore brought the import meta back', w3.eval('META').counts.accounts === accounts.length);
chk('restored account search works',
    w3.eval(`ACC_BY_NAME.get(${JSON.stringify(accounts[0].a)}) !== undefined`));

// restore is a merge, not a wipe: run it twice, nothing duplicates or disappears
await w3.eval('doRestore')({ name:'backup.json', text: async () => JSON.stringify(bk) });
await wait(80);
chk('second restore does not duplicate calls', (await w3.eval('callsAll()')).length === 1);
chk('second restore does not duplicate accounts', (await w3.eval('accAll()')).length === accounts.length);

// a device-local call not in the backup must survive a restore
w3.eval("call = {id:'local1', date:'01/01/2026', type:'Site call', mgr:'x', customer:'Local Only', contacts:[], entries:[], loose:[], closed:false, updated:Date.now()};");
await w3.eval('saveCall()');
await w3.eval('doRestore')({ name:'backup.json', text: async () => JSON.stringify(bk) });
await wait(80);
const after = await w3.eval('callsAll()');
chk('restore does not delete calls that are only on this device',
    after.length === 2 && after.some(c => c.id === 'local1'), String(after.length));

/* ---------- files agree ---------- */
const idx = fs.readFileSync('index.html','utf8'), sw = fs.readFileSync('sw.js','utf8');
chk('index.html loads zones.js before app.js',
    idx.indexOf('zones.js') > 0 && idx.indexOf('zones.js') < idx.indexOf('src="app.js"'));
chk('sw caches zones.js', sw.includes("'./zones.js'"));
chk("sw uses the fieldcrm- cache prefix", /fieldcrm-v\d+/.test(sw));
for (const id of ['impReport','ovFile','ovBtn','bkStat','bkBtn','bkPhBtn','rsFile','rsBtn','ctSub'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
