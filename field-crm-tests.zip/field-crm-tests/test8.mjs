import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
const fileOf = (name, text) => ({ name, text: async () => text });

function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.XLSX = XLSX;
  w.confirm = opts.confirm || (() => true);
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };`);
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
}
async function plant(w, acct, dateISO, time, opts) {
  const ap = Object.assign({
    id:'ap-'+acct.slice(0,6).replace(/\W/g,'')+'-'+dateISO, acct, type:'Intralox site visit',
    date:dateISO, start:time||'09:00', dur:60, agenda:'', contacts:[0], touchedAt: Date.now()
  }, opts||{});
  w.eval('APPTS').push(ap);
  await w.eval('apptsPut')(ap);
  return ap;
}
const isoIn = (w, n) => w.eval(`iso(addDays(startOfWeek(new Date()), ${n}))`);

/* ================= the desktop plans ================= */
const pc = boot({phone:false});
await ready(pc);
const ACC = pc.eval('ACCOUNTS');
const a1 = ACC[0], a2 = ACC[1], a3 = ACC[2];
await plant(pc, a1.a, isoIn(pc,0), '09:00');
await plant(pc, a2.a, isoIn(pc,1), '11:00');
await plant(pc, a3.a, isoIn(pc,2), '14:00');

const planData = await pc.eval('buildPlanFile')(false);
chk('plan file is tagged', planData.kind === 'field-crm-plan' && planData.version === 1);
chk('plan file says which device made it', planData.device === 'desktop', planData.device);
chk('plan file declares the range it covers', !!planData.range.from && !!planData.range.to,
    JSON.stringify(planData.range));
chk('plan file carries the appointments', planData.appts.length === 3);
chk('plan file leaves accounts out by default', planData.accounts === null);
chk('plan file carries no calls', !('calls' in planData));

const planWithAcc = await pc.eval('buildPlanFile')(true);
chk('plan file can carry the account book when asked',
    planWithAcc.accounts.length === ACC.length && !!planWithAcc.meta);

/* ================= the phone receives it ================= */
const ph = boot({phone:true});
await wait(150);
chk('the phone starts with nothing', ph.eval('APPTS').length === 0 && ph.eval('ACCOUNTS').length === 0);

// a plan without accounts is no use to a phone that has none - but it must not fail
let msg = await ph.eval('receiveExchange')(fileOf('p.json', JSON.stringify(planData)));
chk('a plan merges even with no account book present', ph.eval('APPTS').length === 3, msg);
chk('the merge reports what it did', /3 added/.test(msg), msg);

msg = await ph.eval('receiveExchange')(fileOf('p.json', JSON.stringify(planWithAcc)));
chk('a plan carrying accounts loads them', ph.eval('ACCOUNTS').length === ACC.length, msg);
chk('the account count is reported', /accounts/.test(msg), msg);
chk('re-merging the same plan adds nothing', ph.eval('APPTS').length === 3);

/* ================= the phone does the work ================= */
ph.eval("go('today')"); await wait(50);
const apToday = ph.eval('APPTS').find(a => a.date === ph.eval('todayISOdate()')) || ph.eval('APPTS')[0];
// start one and write something up
await ph.eval('startVisit')(apToday.id); await wait(80);
ph.eval("go('belt')");
ph.document.getElementById('bAsset').value = 'CV-7 line 3';
ph.document.getElementById('bSave').click(); await wait(80);
ph.document.getElementById('closeCall').click(); await wait(80);
chk('the phone recorded the visit as done',
    ph.eval('APPTS').find(a => a.id === apToday.id).status === 'done');

// close another out with nothing to report
const apOther = ph.eval('APPTS').find(a => a.id !== apToday.id);
await ph.eval('closeOutVisit')(apOther.id); await wait(80);
chk('and closed one out with no report',
    ph.eval('APPTS').find(a => a.id === apOther.id).status === 'done');

// move the third
const apThird = ph.eval('APPTS').find(a => !a.status);
ph.eval('openMoveDialog')(apThird.id); await wait(30);
const newDay = isoIn(ph, 4);
await ph.eval('moveTo')(newDay); await wait(60);
chk('and moved one', ph.eval('APPTS').find(a => a.id === apThird.id).date === newDay);
chk('the move is stamped as a phone edit',
    ph.eval('APPTS').find(a => a.id === apThird.id).movedOn === 'phone');

const callData = await ph.eval('buildCallFile')(false);
chk('call file is tagged', callData.kind === 'field-crm-calls' && callData.version === 1);
chk('call file says it came from the phone', callData.device === 'phone');
chk('call file carries both calls', callData.calls.length === 2, String(callData.calls.length));
chk('call file carries no appointments wholesale', !('appts' in callData));
chk('call file carries the visit outcomes', callData.apptUpdates.length === 3,
    String(callData.apptUpdates.length));
chk('an outcome carries the outcome and the notes, not the invite fields',
    Object.keys(callData.apptUpdates[0]).every(k =>
      ['id','status','date','callId','movedOn','touchedAt','callSummary'].includes(k)),
    JSON.stringify(Object.keys(callData.apptUpdates[0])));
chk('the structured call file has no image data', !JSON.stringify(callData).includes('data:image'));

/* ================= the desktop receives the calls ================= */
msg = await pc.eval('receiveExchange')(fileOf('c.json', JSON.stringify(callData)));
chk('the desktop took the calls', (await pc.eval('callsAll()')).length === 2, msg);
chk('the desktop learned the visits were done',
    pc.eval('APPTS').filter(a => a.status === 'done').length === 2,
    JSON.stringify(pc.eval('APPTS').map(a => a.status)));
chk('the desktop took the move', pc.eval('APPTS').find(a => a.id === apThird.id).date === newDay);
chk('the merge reports the outcomes', /visit outcomes/.test(msg), msg);
chk('the belt entry came across',
    (await pc.eval('callsAll()')).some(c => (c.entries||[]).some(e => e.asset === 'CV-7 line 3')));
chk('the no-report call came across as such',
    (await pc.eval('callsAll()')).some(c => c.noReport === true));
chk('the account history on the desktop now shows the visit',
    pc.eval('callsFor')(apToday.acct).length === 1);

// merging the same call file twice changes nothing
const n1 = (await pc.eval('callsAll()')).length;
await pc.eval('receiveExchange')(fileOf('c.json', JSON.stringify(callData)));
chk('merging the same call file twice does not duplicate',
    (await pc.eval('callsAll()')).length === n1);

/* ================= deletion within the range ================= */
const gone = pc.eval('APPTS').find(a => a.id === apThird.id);
await pc.eval('apptsDel')(gone.id);
pc.eval(`APPTS = APPTS.filter(a => a.id !== ${JSON.stringify(gone.id)})`);
const plan2 = await pc.eval('buildPlanFile')(false);
chk('the new plan has one fewer', plan2.appts.length === 2);
msg = await ph.eval('receiveExchange')(fileOf('p.json', JSON.stringify(plan2)));
chk('an appointment deleted on the desktop is removed from the phone',
    !ph.eval('APPTS').some(a => a.id === gone.id), msg);
chk('the removal is reported', /removed/.test(msg), msg);
chk('the others survive', ph.eval('APPTS').length === 2, String(ph.eval('APPTS').length));

// something outside the declared range is never touched
const ph2 = boot({phone:true}); await wait(150);
await ph2.eval('receiveExchange')(fileOf('p.json', JSON.stringify(planWithAcc)));
const old = await plant(ph2, ACC[0].a, '2020-06-01', '09:00');
const future = await plant(ph2, ACC[0].a, '2099-06-01', '09:00');
const narrow = JSON.parse(JSON.stringify(planWithAcc));
narrow.appts = []; narrow.range = {from: isoIn(ph2,0), to: isoIn(ph2,4)};
narrow.made = Date.now() + 60000;
msg = await ph2.eval('receiveExchange')(fileOf('p.json', JSON.stringify(narrow)));
chk('an appointment before the range is left alone',
    ph2.eval('APPTS').some(a => a.id === old.id), msg);
chk('an appointment after the range is left alone',
    ph2.eval('APPTS').some(a => a.id === future.id));
chk('appointments inside the range are cleared when the file has none',
    ph2.eval('APPTS').length === 2, String(ph2.eval('APPTS').length));

/* ================= the real conflict: edited on both sides ================= */
const ph3 = boot({phone:true}); await wait(150);
await ph3.eval('receiveExchange')(fileOf('p.json', JSON.stringify(planWithAcc)));
const target = ph3.eval('APPTS')[0];
// the phone moves it, later than the file
target.date = isoIn(ph3, 3);
target.touchedAt = Date.now() + 100000;
await ph3.eval('apptsPut')(target);
const stale = JSON.parse(JSON.stringify(planWithAcc));
stale.appts = stale.appts.map(a => a.id === target.id
  ? Object.assign({}, a, {date: isoIn(ph3,1), touchedAt: Date.now() - 100000}) : a);
msg = await ph3.eval('receiveExchange')(fileOf('p.json', JSON.stringify(stale)));
chk('a newer local edit is kept over an older one in the file',
    ph3.eval('APPTS').find(a => a.id === target.id).date === isoIn(ph3,3),
    ph3.eval('APPTS').find(a => a.id === target.id).date);
chk('the conflict is reported rather than resolved silently',
    /edited here since/.test(msg), msg);

// and the other way: a newer file wins
const target2 = ph3.eval('APPTS').find(a => a.id !== target.id);
const fresh = JSON.parse(JSON.stringify(planWithAcc));
fresh.made = Date.now() + 200000;
fresh.appts = fresh.appts.map(a => a.id === target2.id
  ? Object.assign({}, a, {start:'16:45', touchedAt: Date.now() + 200000}) : a);
await ph3.eval('receiveExchange')(fileOf('p.json', JSON.stringify(fresh)));
chk('a newer edit in the file wins',
    ph3.eval('APPTS').find(a => a.id === target2.id).start === '16:45');
// the phone's outcome is not lost when the desktop's copy overwrites the rest
const withOutcome = ph3.eval('APPTS').find(a => a.id === target2.id);
withOutcome.status = 'done'; withOutcome.callId = 'c-local';
withOutcome.touchedAt = 1;
await ph3.eval('apptsPut')(withOutcome);
const fresher = JSON.parse(JSON.stringify(fresh));
fresher.made = Date.now() + 300000;
// the desktop's copy knows nothing of the outcome - that is the whole point
fresher.appts = fresher.appts.map(a => a.id === target2.id
  ? Object.assign({}, a, {agenda:'new agenda', touchedAt: Date.now() + 300000,
                          status:null, callId:null}) : a);
await ph3.eval('receiveExchange')(fileOf('p.json', JSON.stringify(fresher)));
const after = ph3.eval('APPTS').find(a => a.id === target2.id);
chk('the desktop edit is applied', after.agenda === 'new agenda');
chk('but the phone does not lose that the visit was done', after.status === 'done', after.status);
chk('nor which call it became', after.callId === 'c-local', String(after.callId));

// a file is a snapshot, not a live view of the database
const snapBefore = await pc.eval('buildPlanFile')(false);
const firstId = snapBefore.appts[0] && snapBefore.appts[0].id;
if (firstId) {
  pc.eval('APPTS').find(a => a.id === firstId).agenda = 'changed after the file was built';
  chk('building a file snapshots it rather than handing out live records',
      snapBefore.appts[0].agenda !== 'changed after the file was built',
      String(snapBefore.appts[0].agenda));
} else ok.push('(no appointment left to snapshot)');

/* ================= a call newer here is not clobbered ================= */
const pc2 = boot({phone:false}); await ready(pc2);
const localCall = {id:'shared1', customer: ACC[0].a, date:'01/09/2026', type:'Site call',
  mgr:'x', contacts:[], entries:[{type:'note', text:'written on the PC'}], loose:[],
  status:'done', closed:true, updated: Date.now() + 50000};
await pc2.eval('callsPut')(localCall);
const olderFile = {kind:'field-crm-calls', version:1, made:Date.now(), device:'phone',
  withPhotos:false, apptUpdates:[],
  calls:[Object.assign({}, localCall, {entries:[], updated: Date.now() - 50000})]};
msg = await pc2.eval('receiveExchange')(fileOf('c.json', JSON.stringify(olderFile)));
chk('an older copy of a call does not overwrite a newer one here',
    (await pc2.eval('callsAll()'))[0].entries.length === 1, msg);
chk('and that is reported', /already newer here/.test(msg), msg);

/* ================= wrong files are refused clearly ================= */
const bk = await pc2.eval('buildBackup')(false);
let err = '';
try { await pc2.eval('receiveExchange')(fileOf('b.json', JSON.stringify(bk))); }
catch(e){ err = e.message; }
chk('a backup file is refused and points at Restore', /Restore from backup/.test(err), err);
err = '';
try { await pc2.eval('receiveExchange')(fileOf('x.json', '{"kind":"something-else"}')); }
catch(e){ err = e.message; }
chk('an unknown exchange file is refused by name', /unrecognised/.test(err), err);
err = '';
try { await pc2.eval('receiveExchange')(fileOf('x.json', '{"hello":1}')); }
catch(e){ err = e.message; }
chk('a random json file is refused', /not a Field CRM exchange file/.test(err), err);

/* ================= photos across the exchange ================= */
const JPEG = Buffer.from('/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==', 'base64');
const ph4 = boot({phone:true}); await wait(150);
ph4.eval("call = {id:'p1', customer:'X', date:'01/09/2026', type:'Site call', mgr:'m', contacts:[], entries:[{type:'belt', asset:'A', photos:[]}], loose:[], closed:true, status:'done', updated:Date.now()};");
ph4.eval('call').entries[0].photos = [new ph4.Blob([JPEG], {type:'image/jpeg'})];
await ph4.eval('saveCall()');
ph4.__c = [ph4.eval('call')];
ph4.eval('callsAll = async () => window.__c;');
const light = await ph4.eval('buildCallFile')(false);
const heavy = await ph4.eval('buildCallFile')(true);
chk('a routine call file leaves the photos out', !JSON.stringify(light).includes('data:image'));
chk('and records that there was one', light.calls[0].entries[0].photoCount === 1);
chk('a call file with photos carries them', JSON.stringify(heavy).includes('data:image/jpeg'));

const pc3 = boot({phone:false}); await ready(pc3);
const written = [];
pc3.__w = written;
pc3.eval('callsPut = async c => { window.__w.push(c); };');
await pc3.eval('mergeCallFile')(heavy);
chk('photos arrive as Blobs, not strings',
    written[0].entries[0].photos[0] instanceof pc3.Blob,
    typeof written[0].entries[0].photos[0]);

/* ================= transport ================= */
const ph5 = boot({phone:true}); await ready(ph5);
await plant(ph5, ph5.eval('ACCOUNTS')[0].a, isoIn(ph5,0), '09:00');
chk('a phone is not offered the PC -> Phone folder button',
    ph5.document.getElementById('exPickOut').hidden === true);
chk('a phone is not offered the Phone -> PC folder button',
    ph5.document.getElementById('exPickIn').hidden === true);
chk('a phone is not offered a folder pull', ph5.document.getElementById('exPull').hidden === true);
chk('the phone is told which way each folder runs',
    ph5.document.getElementById('exOutStat').textContent.includes('read from this folder') &&
    ph5.document.getElementById('exInStat').textContent.includes('write to this folder'),
    ph5.document.getElementById('exOutStat').textContent);
ph5.eval('window.__dl = []');
// no share support in jsdom, so it must fall through to a download
await ph5.eval('sendPlan()'); await wait(60);
chk('with no share sheet the plan still lands as a file', ph5.eval('window.__dl').length === 1);
chk('the plan filename names what it is',
    /^field-crm-plan-\d{4}-\d{2}-\d{2}\.json$/.test(ph5.eval('window.__dl')[0].name),
    ph5.eval('window.__dl')[0].name);
chk('it is json', ph5.eval('window.__dl')[0].mime === 'application/json');
const roundTrip = JSON.parse(ph5.eval('window.__dl')[0].text);
chk('the written plan is a valid plan file', roundTrip.kind === 'field-crm-plan');

// the share sheet is preferred when there is one
let shared = null;
ph5.navigator.canShare = () => true;
ph5.navigator.share = async o => { shared = o; };
ph5.eval('window.__dl = []');
await ph5.eval('sendPlan()'); await wait(60);
chk('the share sheet is used when available', !!shared && shared.files.length === 1);
chk('and the download is not', ph5.eval('window.__dl').length === 0);

// a stubbed directory handle takes priority over both
const pc4 = boot({phone:false}); await ready(pc4);
await plant(pc4, pc4.eval('ACCOUNTS')[0].a, isoIn(pc4,0), '09:00');
const folder = {};
const dirFiles = {};
const handle = {
  name:'OneDrive/FieldCRM',
  queryPermission: async () => 'granted',
  requestPermission: async () => 'granted',
  getFileHandle: async (n, o) => {
    if(!(n in dirFiles) && !(o && o.create)) throw new Error('not found');
    return {
      createWritable: async () => ({ write: async t => { dirFiles[n] = t; }, close: async () => {} }),
      getFile: async () => fileOf(n, dirFiles[n])
    };
  },
  entries: function*(){ for(const k of Object.keys(dirFiles)) yield [k, null]; }
};
// DIR is a script-scope binding, so it has to be assigned from inside
pc4.__h = handle;
pc4.eval('DIR_OUT = window.__h');
pc4.eval('window.__dl = []');
await pc4.eval('sendPlan()'); await wait(60);
chk('with the outbound folder set, the plan is written there', Object.keys(dirFiles).length === 1,
    JSON.stringify(Object.keys(dirFiles)));
chk('and not downloaded', pc4.eval('window.__dl').length === 0);
chk('what was written is a plan file',
    JSON.parse(Object.values(dirFiles)[0]).kind === 'field-crm-plan');

// and reading back out of the folder works
const ph6 = boot({phone:true}); await wait(150);
ph6.__h = handle;
// a plan lives in the PC -> Phone folder, which is where the phone reads from
ph6.eval('DIR_OUT = window.__h');
await ph6.eval('receiveFromFolder()'); await wait(80);
chk('pulling from the folder merges the plan', ph6.eval('APPTS').length === 1,
    String(ph6.eval('APPTS').length));

/* ================= markup ================= */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['exStat','exPickOut','exPickIn','exOutStat','exInStat','exSendPlan','exSendCalls','exPull','exFile','exBtn','loadLog'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
