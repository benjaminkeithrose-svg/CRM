import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

/* jsdom has no real session history, so a stand-in is installed that behaves the
   way a browser does: a stack, an index, back() firing popstate with the entry's
   state. That is exactly the contract the app depends on. */
function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  const stack = [null], hist = { i: 0, exited: false };
  if (!opts.noHistory) {
    Object.defineProperty(w, 'history', { configurable: true, value: {
      get length(){ return hist.i + 1; },
      get state(){ return stack[hist.i]; },
      pushState(st){ stack.length = hist.i + 1; stack.push(st); hist.i++; },
      replaceState(st){ stack[hist.i] = st; },
      back(){
        if (hist.i === 0) { hist.exited = true; return; }   // leaving the app
        hist.i--;
        const e = new w.Event('popstate');
        e.state = stack[hist.i];
        w.dispatchEvent(e);
      },
      forward(){
        if (hist.i >= stack.length - 1) return;
        hist.i++;
        const e = new w.Event('popstate');
        e.state = stack[hist.i];
        w.dispatchEvent(e);
      }
    }});
  } else {
    Object.defineProperty(w, 'history', { configurable: true, value: {
      length: 1, state: null,
      pushState(){ throw new Error('history unavailable'); },
      replaceState(){ throw new Error('history unavailable'); },
      back(){}, forward(){}
    }});
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.__hist = hist; w.__stack = stack;
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
}

const w = boot({phone:true});
const $ = id => w.document.getElementById(id);
const back = () => { w.history.back(); };
const depth = () => w.__hist.i;
await ready(w);
const ACC = w.eval('ACCOUNTS');

/* ---------- boot seeds one entry ---------- */
chk('boot leaves a state object behind', !!w.history.state, JSON.stringify(w.history.state));
chk('and it is home', w.history.state.screen === 'home');
chk('at the bottom of the stack', depth() === 0, String(depth()));
chk('the back button is hidden on home', $('back').style.display === 'none');

/* ---------- each move pushes one entry ---------- */
w.eval("go('accounts')"); await wait(40);
chk('a move pushes an entry', depth() === 1, String(depth()));
chk('the entry names the screen', w.history.state.screen === 'accounts');
chk('the back button appears', $('back').style.display === 'block');
w.eval('openAccount')(ACC[0].a); await wait(40);
chk('a second move pushes another', depth() === 2, String(depth()));
chk('we are on the account view', $('s-acct').classList.contains('on'));

/* ---------- the gesture walks back the way you came ---------- */
back(); await wait(40);
chk('back returns to the browse screen', $('s-accounts').classList.contains('on'));
chk('and pops the entry', depth() === 1, String(depth()));
back(); await wait(40);
chk('back again reaches home', $('s-home').classList.contains('on'));
chk('the back button hides again', $('back').style.display === 'none');
chk('the stack is back at the bottom', depth() === 0);
chk('the app has not exited', w.__hist.exited === false);
back(); await wait(40);
chk('one more back from home leaves the app', w.__hist.exited === true);

/* ---------- redrawing the same screen does not stack entries ---------- */
const w2 = boot({phone:true}); const $2 = id => w2.document.getElementById(id);
await ready(w2);
w2.eval("go('accounts')"); await wait(30);
const d0 = w2.__hist.i;
w2.eval("go('accounts')"); w2.eval("go('accounts')"); await wait(30);
chk('re-showing the same screen adds no entries', w2.__hist.i === d0,
    `${w2.__hist.i} vs ${d0}`);
chk('so one back press still leaves it', (w2.history.back(), $2('s-home').classList.contains('on')));

/* ---------- the header button and the gesture agree ---------- */
const w3 = boot({phone:true}); const $3 = id => w3.document.getElementById(id);
await ready(w3);
w3.eval("go('accounts')"); await wait(30);
w3.eval('openAccount')(w3.eval('ACCOUNTS')[0].a); await wait(30);
$3('back').click(); await wait(40);
chk('the header button goes back a screen', $3('s-accounts').classList.contains('on'));
chk('and consumes the entry, not just hides the screen', w3.__hist.i === 1, String(w3.__hist.i));
$3('back').click(); await wait(40);
chk('again reaches home', $3('s-home').classList.contains('on'));
$3('back').click(); await wait(40);
chk('the header button never exits the app from home', w3.__hist.exited === false);

/* ---------- through a whole call and back out ---------- */
const w4 = boot({phone:true}); const $4 = id => w4.document.getElementById(id);
await ready(w4);
w4.document.querySelector('[data-go="newcall"]').click(); await wait(50);
chk('new call reaches the account screen', $4('s-account').classList.contains('on'));
$4('accManual').value = 'Test Site - Somewhere';
$4('accManualGo').click(); await wait(50);
chk('and then contacts', $4('s-contacts').classList.contains('on'));
$4('ncName').value = 'A Person';
$4('openCall').click(); await wait(80);
chk('and then the dashboard', $4('s-dash').classList.contains('on'));
w4.eval("go('belt')"); await wait(30);
chk('and into a belt entry', $4('s-belt').classList.contains('on'));
const deep = w4.__hist.i;
chk('four moves deep', deep === 4, String(deep));
back.call(null); w4.history.back(); await wait(40);
chk('back from the belt form returns to the dashboard', $4('s-dash').classList.contains('on'));
chk('not out of the app', w4.__hist.exited === false);
w4.history.back(); await wait(40);
chk('back from the dashboard returns to contacts', $4('s-contacts').classList.contains('on'));
chk('the photo bar is gone once out of the call',
    $4('bar').style.display === 'none', $4('bar').style.display);

/* ---------- dialogs get their own entry ---------- */
const w5 = boot(); const $5 = id => w5.document.getElementById(id);
await ready(w5);
w5.document.querySelector('[data-go="plan"]').click(); await wait(60);
const planDepth = w5.__hist.i;
const a5 = w5.eval('ACCOUNTS')[0];
await w5.eval('openDialog')(null, {acct: a5.a, date: w5.eval('iso(weekDays()[0])')});
await wait(30);
chk('the appointment dialog opens', $5('dlg').hasAttribute('open'));
chk('opening it pushes an entry', w5.__hist.i === planDepth + 1, String(w5.__hist.i));
chk('the entry records which dialog', w5.history.state.dialog === 'dlg');
w5.history.back(); await wait(40);
chk('back closes the dialog', !$5('dlg').hasAttribute('open'));
chk('and leaves the screen behind it alone', $5('s-plan').classList.contains('on'));
chk('and the entry is consumed', w5.__hist.i === planDepth, String(w5.__hist.i));
chk('the dialog state is cleared', w5.eval('dlgAppt') === null);

// cancelling with the button consumes the entry the same way
await w5.eval('openDialog')(null, {acct: a5.a, date: w5.eval('iso(weekDays()[0])')});
await wait(30);
$5('dCancel').click(); await wait(40);
chk('the Cancel button also closes it', !$5('dlg').hasAttribute('open'));
chk('and does not leave a stranded entry', w5.__hist.i === planDepth,
    String(w5.__hist.i));
chk('so the next back leaves the plan screen', (w5.history.back(), $5('s-home').classList.contains('on')));

// saving from the dialog does the same
w5.eval("go('plan')"); await wait(40);
const pd2 = w5.__hist.i;
await w5.eval('openDialog')(null, {acct: a5.a, date: w5.eval('iso(weekDays()[1])')});
await wait(30);
$5('dSave').click(); await wait(80);
chk('saving closes the dialog', !$5('dlg').hasAttribute('open'));
chk('saving leaves no stranded entry either', w5.__hist.i === pd2, String(w5.__hist.i));
chk('and the appointment was actually saved', w5.eval('APPTS').length === 1);

// the reassign dialog behaves the same
w5.eval('openReassign')({}); await wait(30);
chk('the reassign dialog opens', $5('rdlg').hasAttribute('open'));
w5.history.back(); await wait(40);
chk('back closes the reassign dialog', !$5('rdlg').hasAttribute('open'));
chk('and stays on the plan screen', $5('s-plan').classList.contains('on'));

// the move dialog on the phone
const w6 = boot({phone:true}); const $6 = id => w6.document.getElementById(id);
await ready(w6);
const a6 = w6.eval('ACCOUNTS')[0];
const ap6 = {id:'ap1', acct:a6.a, type:'Intralox site visit',
  date: w6.eval('todayISOdate()'), start:'09:00', dur:60, agenda:'', contacts:[]};
w6.eval('APPTS').push(ap6); await w6.eval('apptsPut')(ap6);
w6.eval("go('today')"); await wait(50);
const td = w6.__hist.i;
w6.eval('openMoveDialog')('ap1'); await wait(30);
chk('the move dialog opens', $6('mvdlg').hasAttribute('open'));
w6.history.back(); await wait(40);
chk('back closes it', !$6('mvdlg').hasAttribute('open'));
chk('and stays on Today', $6('s-today').classList.contains('on'), String(w6.__hist.i));
chk('with no stranded entry', w6.__hist.i === td, String(w6.__hist.i));
// and moving from it closes cleanly too
w6.eval('openMoveDialog')('ap1'); await wait(30);
const day = [...$6('mvDays').querySelectorAll('[data-day]')].find(b => !b.disabled).dataset.day;
await w6.eval('moveTo')(day); await wait(60);
chk('moving closes the dialog', !$6('mvdlg').hasAttribute('open'));
chk('and leaves no stranded entry', w6.__hist.i === td, String(w6.__hist.i));
chk('and the move happened', w6.eval('APPTS')[0].date === day);

/* ---------- a dialog on top of a screen, then back twice ---------- */
const w7 = boot(); const $7 = id => w7.document.getElementById(id);
await ready(w7);
w7.document.querySelector('[data-go="plan"]').click(); await wait(60);
await w7.eval('openDialog')(null, {acct: w7.eval('ACCOUNTS')[0].a, date: w7.eval('iso(weekDays()[0])')});
await wait(30);
w7.history.back(); await wait(40);
chk('first back closes the dialog only', !$7('dlg').hasAttribute('open') &&
    $7('s-plan').classList.contains('on'));
w7.history.back(); await wait(40);
chk('second back leaves the screen', $7('s-home').classList.contains('on'));

/* ---------- the app still works with no history API ---------- */
const w8 = boot({noHistory:true, phone:true});
await wait(150);
chk('the app boots without a working history API',
    w8.document.getElementById('s-home').classList.contains('on'));
w8.eval("go('accounts')"); await wait(40);
chk('and still changes screens', w8.document.getElementById('s-accounts').classList.contains('on'));
w8.document.getElementById('back').click(); await wait(40);
chk('the header back button still gets you home',
    w8.document.getElementById('s-home').classList.contains('on'));

/* ---------- markup ---------- */
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
