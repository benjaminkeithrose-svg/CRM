import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

/* A stand-in GitHub. Holds one file with a sha, behaves the way the Contents API
   does: 404 before anything is written, 409 on a stale sha. */
function makeGitHub(opts) {
  opts = opts || {};
  const state = { file: null, sha: null, priv: opts.priv !== false, push: opts.push !== false,
                  puts: 0, gets: 0, bumpOnNextGet: null };
  const enc = s => Buffer.from(s, 'utf8').toString('base64');
  const dec = s => Buffer.from(s, 'base64').toString('utf8');
  const json = (o, status) => ({ ok: status < 400, status,
    json: async () => o, text: async () => JSON.stringify(o) });
  return { state, enc, dec, fetch: async (url, init) => {
    init = init || {};
    const auth = (init.headers || {}).Authorization || '';
    if (!/^Bearer .+/.test(auth)) return json({message:'Bad credentials'}, 401);
    if (opts.badToken) return json({message:'Bad credentials'}, 401);
    if (/\/user$/.test(url)) {
      return json({ login: opts.login || 'me' }, 200);
    }
    if (/\/user\/repos/.test(url)) {
      if (opts.granted === null) return json({message:'Forbidden'}, 403);
      return json((opts.granted || ['me/data']).map(n => ({full_name:n})), 200);
    }
    // repo metadata
    if (/\/repos\/[^/]+\/[^/]+$/.test(url)) {
      if (opts.missing) return json({message:'Not Found'}, 404);
      return json({ full_name:'me/data', private: state.priv,
                    permissions: { push: state.push } }, 200);
    }
    // contents
    if (init.method === 'PUT') {
      state.puts++;
      // simulate the real race: someone else wrote between our read and our write
      if (state.failNextPut) { state.failNextPut = false; return json({message:'conflict'}, 409); }
      const body = JSON.parse(init.body);
      if (state.sha && body.sha !== state.sha) return json({message:'conflict'}, 409);
      if (!state.sha && body.sha) return json({message:'conflict'}, 409);
      state.file = dec(body.content);
      state.sha = 'sha' + state.puts;
      return json({ content: { sha: state.sha } }, 200);
    }
    state.gets++;
    if (state.bumpOnNextGet) { state.bumpOnNextGet(); state.bumpOnNextGet = null; }
    if (state.file == null) return json({message:'Not Found'}, 404);
    return json({ sha: state.sha, content: enc(state.file) }, 200);
  }};
}

function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  Object.defineProperty(w.navigator, 'onLine', { value: opts.offline ? false : true, configurable: true });
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.console.error = () => {};   // expected refusals are asserted, not printed
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder;
  w.btoa = s => Buffer.from(s, 'binary').toString('base64');
  w.atob = s => Buffer.from(s, 'base64').toString('binary');
  if (opts.gh) w.fetch = opts.gh.fetch;
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    if (d) { d.showModal = function(){ this.setAttribute('open',''); };
             d.close = function(){ this.removeAttribute('open'); }; }
  }
  const stack = [null]; const h = {i:0};
  Object.defineProperty(w, 'history', { configurable:true, value:{
    get length(){ return h.i+1; }, get state(){ return stack[h.i]; },
    pushState(st){ stack.length = h.i+1; stack.push(st); h.i++; },
    replaceState(st){ stack[h.i] = st; },
    back(){ if(h.i===0) return; h.i--; const e = new w.Event('popstate'); e.state = stack[h.i]; w.dispatchEvent(e); }
  }});
  for (const f of ['zones.js','manuals.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
async function ready(w) {
  await wait(220);
  await w.eval('importCrm')(crmFile); await wait(120);
  await w.eval('renderHome')();
}
async function configure(w) {
  w.eval(`GH = {owner:'me', repo:'data', branch:'main', path:'exchange/appointments.json', token:'github_pat_x'};`);
  await w.eval('saveGh')();
}
async function makeAppt(w, acct, dateISO, extra) {
  const ap = Object.assign({
    id:'ap-'+acct.slice(0,5).replace(/\W/g,'')+'-'+dateISO, acct,
    type:'Intralox site visit', date:dateISO, start:'09:00', dur:60,
    agenda:'Walk the boning room', contacts:[0], touchedAt: Date.now()
  }, extra||{});
  w.eval('APPTS').push(ap);
  await w.eval('apptsPut')(ap);
  return ap;
}

/* ================= the account key ================= */
{
  const w = boot({}); await wait(220);
  const k = w.eval('acctKey');
  chk('a key is 16 hex characters', /^[0-9a-f]{16}$/.test(k('JBS AUSTRALIA - BROOKLYN')), k('JBS AUSTRALIA - BROOKLYN'));
  chk('the same name gives the same key', k('X - Y') === k('X - Y'));
  chk('case and padding do not matter', k('x - y') === k(' X - Y '));
  chk('different names give different keys', k('A - B') !== k('A - C'));
  chk('the key contains none of the name',
      !k('JBS AUSTRALIA - BROOKLYN').includes('jbs') && !/[g-z]/.test(k('JBS AUSTRALIA - BROOKLYN')));
  // no collisions across the whole book
  await w.eval('importCrm')(crmFile); await wait(120);
  const names = w.eval('ACCOUNTS').map(a => a.a);
  const keys = names.map(k);
  chk('no key collisions across the account book', new Set(keys).size === keys.length,
      `${new Set(keys).size} of ${keys.length}`);
  chk('every key resolves back to its account',
      names.every(n => w.eval('KEY_TO_ACCT').get(k(n)) === n));
}

/* ================= what actually goes up ================= */
const gh = makeGitHub();
const pc = boot({gh, phone:false});
await ready(pc);
await configure(pc);
const ACC = pc.eval('ACCOUNTS');
const acct = ACC.find(a => a.c.length > 0) || ACC[0];
const ap = await makeAppt(pc, acct.a, pc.eval('iso(weekDays()[1])'));

// give it everything a real appointment picks up over its life
ap.status = 'done'; ap.callId = 'c123';
ap.callSummary = { date:'08/09/2026', contacts:[{n:'Aaron Russell', r:'Plant Manager'}],
                   belts:[{asset:'CV-1 line 2'}], notes:[{topic:'Production', text:'Kill rate up'}] };
ap.exp = 'rev'; ap.expAt = Date.now(); ap.icsSeq = 2;
await pc.eval('apptsPut')(ap);

const doc = pc.eval('buildApptDoc')();
const raw = JSON.stringify(doc);
chk('the document is tagged', doc.kind === 'field-crm-appts' && doc.version === 1);
chk('it carries the appointment', doc.appts.length === 1);
const sl = doc.appts[0];
chk('the account travels as a key', sl.ak === pc.eval('acctKey')(acct.a), sl.ak);
chk('and the account name does not', !('acct' in sl) && !raw.includes(acct.a),
    Object.keys(sl).join(','));
chk('no contact name appears anywhere', !raw.includes('Aaron Russell'));
chk('no belt or note text appears', !raw.includes('CV-1 line 2') && !raw.includes('Kill rate up'));
chk('callSummary is not sent', !('callSummary' in sl) && !raw.includes('callSummary'));
chk('callId is not sent - it points at a record only this device has', !('callId' in sl));
chk('contacts travel as indices, not people', JSON.stringify(sl.contacts) === '[0]');
chk('the agenda does travel, as the one free-text field', sl.agenda === 'Walk the boning room');
chk('the status travels', sl.status === 'done');
chk('the Outlook export state travels', sl.exp === 'rev' && sl.icsSeq === 2);
chk('a slim record is small', JSON.stringify(sl).length < 260, String(JSON.stringify(sl).length));

// sweep the whole document against every name in the account book
const allNames = ACC.map(a => a.a);
const people = new Set();
ACC.forEach(a => a.c.forEach(c => people.add(c.n)));
chk('no account name from the book appears in the document',
    !allNames.some(n => raw.includes(n)));
chk('no contact name from the book appears in the document',
    ![...people].filter(p => p.length > 6).some(p => raw.includes(p)));

/* ================= push, pull, round trip ================= */
let msg = await pc.eval('ghPush')();
chk('the push reports what went', /Pushed 1 appointment/.test(msg), msg);
chk('something was written', gh.state.file !== null);
chk('the stored file is the document', JSON.parse(gh.state.file).kind === 'field-crm-appts');
chk('the stored file has no account name', !allNames.some(n => gh.state.file.includes(n)));

const ph = boot({gh, phone:true});
await ready(ph);
await configure(ph);
chk('the phone starts with nothing planned', ph.eval('APPTS').length === 0);
msg = await ph.eval('ghPull')();
chk('the phone pulls it', ph.eval('APPTS').length === 1, msg);
const got = ph.eval('APPTS')[0];
chk('the account name is resolved locally', got.acct === acct.a, got.acct);
chk('the date and time came across', got.date === ap.date && got.start === '09:00');
chk('the agenda came across', got.agenda === 'Walk the boning room');
chk('the contact index came across', JSON.stringify(got.contacts) === '[0]');
chk('it is marked acknowledged', got.acked === true);
chk('the phone did not receive the call notes', !got.callSummary);
chk('nor the call id', !got.callId);
chk('the pull is logged', ph.eval('LOAD_LOG')[0].kind === 'ghpull');

/* ================= an account the device does not know ================= */
{
  const fresh = boot({gh, phone:true}); await wait(220);
  await configure(fresh);
  msg = await fresh.eval('ghPull')();
  chk('an unresolvable key is skipped, not guessed',
      fresh.eval('APPTS').length === 0, String(fresh.eval('APPTS').length));
  chk('and is reported', /not in this device/.test(msg), msg);
}

/* ================= the phone does the visit and pushes back ================= */
ph.eval("go('today')"); await wait(50);
await ph.eval('startVisit')(got.id); await wait(90);
ph.document.getElementById('closeCall').click(); await wait(110);
chk('the phone marked the visit done', ph.eval('APPTS')[0].status === 'done');
chk('and wrote a summary locally', !!ph.eval('APPTS')[0].callSummary);
await ph.eval('ghPush')();
chk('the pushed file still has no notes in it',
    !gh.state.file.includes('callSummary') && !gh.state.file.includes('Nothing to report'),
    gh.state.file.slice(0, 120));

await pc.eval('ghPull')();
const back = pc.eval('APPTS')[0];
chk('the PC learns the visit was done', back.status === 'done');
chk('the PC keeps its own Outlook export state', back.exp === 'rev' && back.icsSeq === 2);
chk('and its own call link', back.callId === 'c123');
chk('and its own copy of the notes it already had', !!back.callSummary);

/* ================= the merge rules ================= */
// a newer local edit is not overwritten
const later = pc.eval('APPTS')[0];
later.start = '15:45'; later.touchedAt = Date.now() + 100000;
await pc.eval('apptsPut')(later);
const stale = JSON.parse(gh.state.file);
stale.made = Date.now() - 100000;
stale.appts[0].start = '08:00';
stale.appts[0].touchedAt = Date.now() - 100000;
msg = await pc.eval('mergeApptDoc')(stale);
chk('an older remote edit does not win', pc.eval('APPTS')[0].start === '15:45',
    pc.eval('APPTS')[0].start);
chk('and it is counted as kept', msg.kept >= 1, JSON.stringify(msg));

// an appointment made here and never pushed is not deleted by a document that lacks it
{
  const solo = boot({gh, phone:true}); await ready(solo); await configure(solo);
  await makeAppt(solo, solo.eval('ACCOUNTS')[0].a, solo.eval('iso(weekDays()[0])'),
                 {origin:'phone', acked:false});
  const empty = {kind:'field-crm-appts', version:1, made: Date.now()+60000, device:'desktop',
                 range:{from: solo.eval("iso(startOfWeek(new Date()))"), to:'9999-12-31'}, appts:[]};
  const r = await solo.eval('mergeApptDoc')(empty);
  chk('an unpushed local appointment survives a document without it',
      solo.eval('APPTS').length === 1, JSON.stringify(r));
  // once it has been round-tripped it can be deleted like anything else
  solo.eval('APPTS')[0].acked = true;
  await solo.eval('apptsPut')(solo.eval('APPTS')[0]);
  const empty2 = Object.assign({}, empty, {made: Date.now()+120000});
  await solo.eval('mergeApptDoc')(empty2);
  chk('once acknowledged, a deletion propagates', solo.eval('APPTS').length === 0);
}

/* ================= conflict on push ================= */
{
  const gh2 = makeGitHub();
  const a = boot({gh: gh2, phone:false}); await ready(a); await configure(a);
  await makeAppt(a, a.eval('ACCOUNTS')[0].a, a.eval('iso(weekDays()[0])'));
  await a.eval('ghPush')();
  const putsBefore = gh2.state.puts;
  const b = boot({gh: gh2, phone:true}); await ready(b); await configure(b);
  await b.eval('ghPull')();
  await makeAppt(b, b.eval('ACCOUNTS')[1].a, b.eval('iso(weekDays()[2])'), {origin:'phone', acked:false});
  await b.eval('ghPush')();
  await makeAppt(a, a.eval('ACCOUNTS')[2].a, a.eval('iso(weekDays()[3])'));
  // the next write loses the race, exactly as a real concurrent push would
  gh2.state.failNextPut = true;
  let threw = null;
  try { await a.eval('ghPush')(); } catch(e){ threw = e.message; }
  chk('a stale write is retried rather than failing', threw === null, String(threw));
  chk('the losing write is retried, not dropped', gh2.state.puts >= putsBefore + 3,
      `${gh2.state.puts} puts, started at ${putsBefore}`);
  const finalDoc = JSON.parse(gh2.state.file);
  chk('the other device\'s appointment survived the retry', finalDoc.appts.length >= 3,
      String(finalDoc.appts.length));
}

/* ================= the repository must be private ================= */
{
  const pub = makeGitHub({priv:false});
  const w = boot({gh: pub, phone:false}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghCheckRepo')(); } catch(e){ threw = e.message; }
  chk('a public repository is refused', /PUBLIC/.test(String(threw)), String(threw));
  w.document.getElementById('ghSync').click(); await wait(80);
  chk('and the sync button refuses to write to it', pub.state.file === null);
}
{
  const ro = makeGitHub({push:false});
  const w = boot({gh: ro, phone:false}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghCheckRepo')(); } catch(e){ threw = e.message; }
  chk('a read-only token is refused', /not write/.test(String(threw)), String(threw));
  chk('and says which setting to change', /Read and write/.test(String(threw)), String(threw));
}
{
  const bad = makeGitHub({badToken:true});
  const w = boot({gh: bad, phone:false}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghCheckRepo')(); } catch(e){ threw = e.message; }
  chk('a rejected token says so plainly', /expired|rejected/.test(String(threw)), String(threw));
  chk('and mentions being pasted short, which is the common cause on a phone',
      /truncate|short/.test(String(threw)), String(threw));
}
/* A fine-grained token gets 404 for a repository it has not been granted, the
   same answer as one that does not exist. The test has to say which. */
{
  // token valid, but no repositories granted at all
  const g = makeGitHub({missing:true, granted:[]});
  const w = boot({gh: g, phone:false}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghCheckRepo')(); } catch(e){ threw = e.message; }
  chk('a token with no repositories granted says exactly that',
      /has not been given ANY repository/.test(String(threw)), String(threw));
  chk('and names the repo to pick', /pick data/.test(String(threw)), String(threw));
  chk('and confirms the token itself works', /signed in as me/.test(String(threw)));
}
{
  // token granted other repositories, but not this one
  const g = makeGitHub({missing:true, granted:['me/something-else','me/datasync-old']});
  const w = boot({gh: g, phone:false}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghCheckRepo')(); } catch(e){ threw = e.message; }
  chk('it lists what the token can actually see',
      /me\/something-else/.test(String(threw)), String(threw));
  chk('and suggests the near miss', /Did you mean me\/datasync-old/.test(String(threw)),
      String(threw));
}
{
  // the repos list is refused too, which points at the metadata permission
  const g = makeGitHub({missing:true, granted:null});
  const w = boot({gh: g, phone:false}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghCheckRepo')(); } catch(e){ threw = e.message; }
  chk('it points at the Metadata permission when the repo list is refused',
      /Metadata is set to No access/.test(String(threw)), String(threw));
}

/* ================= offline and unconfigured ================= */
{
  const w = boot({gh: makeGitHub(), phone:true, offline:true}); await ready(w); await configure(w);
  let threw = null;
  try { await w.eval('ghSync')(); } catch(e){ threw = e.message; }
  chk('with no connection it says so rather than failing obscurely',
      /no connection/.test(String(threw)), String(threw));
}
{
  const w = boot({gh: makeGitHub(), phone:true}); await ready(w);
  let threw = null;
  try { await w.eval('ghSync')(); } catch(e){ threw = e.message; }
  chk('unconfigured, it asks to be set up', /repository and token/.test(String(threw)), String(threw));
  chk('and the sync button is disabled', w.document.getElementById('ghSync').disabled === true);
  chk('the panel says it is not set up',
      w.document.getElementById('ghStat').textContent.includes('Not set up'),
      w.document.getElementById('ghStat').textContent);
}

/* ================= non-ASCII survives the round trip ================= */
{
  const g = makeGitHub();
  const a = boot({gh:g, phone:false}); await ready(a); await configure(a);
  await makeAppt(a, a.eval('ACCOUNTS')[0].a, a.eval('iso(weekDays()[0])'),
                 {agenda:'Café \u2014 line 3 \u00b7 check 606\u2009mm'});
  await a.eval('ghPush')();
  const b = boot({gh:g, phone:true}); await ready(b); await configure(b);
  await b.eval('ghPull')();
  chk('an agenda with accents and dashes survives base64',
      b.eval('APPTS')[0].agenda === 'Café \u2014 line 3 \u00b7 check 606\u2009mm',
      b.eval('APPTS')[0].agenda);
}

/* ================= settings and markup ================= */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['ghStat','ghOwner','ghRepo','ghBranch','ghPath','ghToken','ghTest','ghSync'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('the token field is a password field', /id="ghToken"[^>]*type="password"|type="password"[^>]*id="ghToken"/.test(idx));
chk('the panel states what does not go up',
    idx.includes('no call notes') || idx.includes('call notes, photos'), 'disclosure line');
chk('the settings persist', (await pc.eval("kvGet('github')")).repo === 'data');
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
