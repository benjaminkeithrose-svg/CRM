import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
const fileOf = (name, text) => ({ name, text: async () => text });

function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  const stack = [null]; const h = {i:0};
  Object.defineProperty(w, 'history', { configurable:true, value:{
    get length(){ return h.i+1; }, get state(){ return stack[h.i]; },
    pushState(st){ stack.length = h.i+1; stack.push(st); h.i++; },
    replaceState(st){ stack[h.i] = st; },
    back(){ if(h.i===0) return; h.i--; const e = new w.Event('popstate'); e.state = stack[h.i]; w.dispatchEvent(e); }
  }});
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };`);
  return w;
}
async function ready(w) {
  await wait(180);
  await w.eval('importCrm')(crmFile); await wait(120);
  await w.eval('renderHome()');
}
// walk the unplanned-call flow the way the user does
async function unplannedCall(w, acctName, contactName) {
  const $ = id => w.document.getElementById(id);
  w.eval("go('today')"); await wait(40);
  $('tvUnplanned').click(); await wait(50);
  $('accQ').value = acctName.slice(0, 14);
  $('accQ').dispatchEvent(new w.Event('input')); await wait(40);
  const hit = [...$('accRes').querySelectorAll('button')].find(b => b.textContent.includes(acctName));
  if (hit) hit.click(); else w.eval('chooseAccount')(acctName);
  await wait(50);
  const box = $('ctList').querySelector('input[type=checkbox]');
  if (box) box.checked = true; else $('ncName').value = contactName || 'Someone';
  $('openCall').click(); await wait(90);
}

/* ================= the phone logs a call nobody planned ================= */
const ph = boot({phone:true});
await ready(ph);
const $ = id => ph.document.getElementById(id);
const ACC = ph.eval('ACCOUNTS');
const acct = ACC.find(a => a.c.length > 0) || ACC[0];

chk('the phone starts with nothing in the plan', ph.eval('APPTS').length === 0);
await unplannedCall(ph, acct.a);
chk('the call opened', $('s-dash').classList.contains('on'));
chk('an appointment was created for it', ph.eval('APPTS').length === 1,
    String(ph.eval('APPTS').length));

const ap = ph.eval('APPTS')[0];
chk('it is against the right account', ap.acct === acct.a);
chk('it is dated today, the day it is being done', ap.date === ph.eval('todayISOdate()'), ap.date);
chk('it is timed to now, not 09:00', /^\d{2}:\d{2}$/.test(ap.start), ap.start);
chk('it is marked unplanned', ap.unplanned === true);
chk('it is marked as made on the phone', ap.origin === 'phone', String(ap.origin));
chk('and not yet seen by the desktop', ap.acked === false);
chk('it is already in progress, not planned', ap.status === 'in progress');
chk('it points at the call', ap.callId === ph.eval('call').id);
chk('and the call points back', ph.eval('call').apptId === ap.id);
chk('the contacts carried across', ap.contacts.length >= 1, JSON.stringify(ap.contacts));
chk('it persisted', (await ph.eval('apptsAll()')).length === 1);
chk('the home tile counts it', $('planInfo').textContent.includes('1 planned'), $('planInfo').textContent);

// it shows on Today as a real visit
ph.eval("go('today')"); await wait(50);
chk('it appears on Today', $('tvBody').textContent.includes(acct.a));
chk('reading as in progress', $('tvBody').innerHTML.includes('>in progress<'));

/* ---------- a manually typed account gets no calendar entry ---------- */
const ph2 = boot({phone:true}); await ready(ph2);
const $2 = id => ph2.document.getElementById(id);
ph2.eval("go('today')"); await wait(40);
$2('tvUnplanned').click(); await wait(50);
$2('accManual').value = 'SOME NEW SITE - NOWHERE';
$2('accManualGo').click(); await wait(50);
$2('ncName').value = 'A Person';
$2('openCall').click(); await wait(90);
chk('a call against a typed-in account still opens', $2('s-dash').classList.contains('on'));
chk('but no appointment is created for it', ph2.eval('APPTS').length === 0,
    String(ph2.eval('APPTS').length));
chk('the call is still recorded', (await ph2.eval('callsAll()')).length === 1);
chk('and still flagged as not in the CRM', ph2.eval('call').manualAccount === true);

/* ---------- starting a planned visit does not double-book ---------- */
const ph3 = boot({phone:true}); await ready(ph3);
const a3 = ph3.eval('ACCOUNTS')[0];
const planned = {id:'ap-planned', acct:a3.a, type:'Intralox site visit',
  date: ph3.eval('todayISOdate()'), start:'09:00', dur:60, agenda:'', contacts:[]};
ph3.eval('APPTS').push(planned); await ph3.eval('apptsPut')(planned);
ph3.eval("go('today')"); await wait(40);
await ph3.eval('startVisit')('ap-planned'); await wait(90);
chk('starting a planned visit creates no second appointment',
    ph3.eval('APPTS').length === 1, String(ph3.eval('APPTS').length));
chk('and the existing one is used', ph3.eval('call').apptId === 'ap-planned');

/* ================= it travels back to the PC ================= */
const callFile = await ph.eval('buildCallFile')(false);
chk('the call file carries the new appointment',
    Array.isArray(callFile.newAppts) && callFile.newAppts.length === 1,
    JSON.stringify((callFile.newAppts||[]).length));
chk('sent whole, not as an update', callFile.newAppts[0].acct === acct.a &&
    callFile.newAppts[0].date === ap.date);
chk('the call itself is in there too', callFile.calls.length === 1);

const pc = boot({phone:false}); await ready(pc);
chk('the desktop has nothing planned', pc.eval('APPTS').length === 0);
let msg = await pc.eval('receiveExchange')(fileOf('c.json', JSON.stringify(callFile)));
await wait(80);
chk('the desktop picks up the unplanned visit', pc.eval('APPTS').length === 1,
    String(pc.eval('APPTS').length));
chk('and says so', /unplanned visit/.test(msg), msg);
const pcAp = pc.eval('APPTS')[0];
chk('on the right day', pcAp.date === ap.date);
chk('against the right account', pcAp.acct === acct.a);
chk('marked acknowledged, so it is no longer phone-only', pcAp.acked === true);
chk('the call came across as well', (await pc.eval('callsAll()')).length === 1);
chk('it shows on the desktop calendar',
    (pc.eval("go('plan')"), pc.eval("plan.anchor = startOfWeek(new Date()); renderCalendar()"),
     pc.document.getElementById('calBody').textContent.includes(acct.a)));
chk('and reads as unplanned there',
    pc.document.getElementById('calBody').innerHTML.includes('unplanned'),
    pc.document.getElementById('calBody').textContent.slice(0,140));

// merging the same call file twice must not duplicate it
await pc.eval('receiveExchange')(fileOf('c.json', JSON.stringify(callFile)));
await wait(60);
chk('merging twice does not duplicate the appointment', pc.eval('APPTS').length === 1);

/* ---------- an unplanned visit against an account the PC does not have ---------- */
const pc2 = boot({phone:false}); await wait(180);
await pc2.eval('receiveExchange')(fileOf('c.json', JSON.stringify(callFile)));
await wait(60);
chk('with no account book, the appointment is not hung on nothing',
    pc2.eval('APPTS').length === 0, String(pc2.eval('APPTS').length));
chk('but the call is still taken', (await pc2.eval('callsAll()')).length === 1);

/* ================= the plan file must not wipe it ================= */
/* This is the rule that had to change. A plan is authoritative for its date
   range, so before this an appointment the phone had just made - and the desktop
   had never been told about - was deleted the moment any plan arrived. */
const ph4 = boot({phone:true}); await ready(ph4);
const a4 = ph4.eval('ACCOUNTS')[0];
await unplannedCall(ph4, a4.a);
const mine = ph4.eval('APPTS')[0];
chk('the phone has an unacknowledged appointment',
    mine.origin === 'phone' && mine.acked === false);

// a plan made by the desktop that knows nothing about it
const stalePlan = {
  kind:'field-crm-plan', version:1, made: Date.now() + 60000, device:'desktop',
  range: {from: ph4.eval("iso(startOfWeek(new Date()))"), to:'9999-12-31'},
  appts: [], weeks:{}, mgrOf:{}, accounts:null, meta:null, overrides:null
};
msg = await ph4.eval('receiveExchange')(fileOf('p.json', JSON.stringify(stalePlan)));
await wait(60);
chk('a plan that has never seen it does not delete it',
    ph4.eval('APPTS').length === 1, msg);
chk('and it is reported as kept', /kept/.test(msg), msg);
chk('it is still unacknowledged', ph4.eval('APPTS')[0].acked === false);

// once the desktop has it and sends it back, it becomes ordinary
const knownPlan = JSON.parse(JSON.stringify(stalePlan));
knownPlan.made = Date.now() + 120000;
knownPlan.appts = [Object.assign({}, mine, {acked:true})];
await ph4.eval('receiveExchange')(fileOf('p.json', JSON.stringify(knownPlan)));
await wait(60);
chk('once the plan contains it, it is acknowledged',
    ph4.eval('APPTS')[0].acked === true);
chk('and that stuck', (await ph4.eval('apptsAll()'))[0].acked === true);

// now a plan that drops it really does delete it
const dropPlan = JSON.parse(JSON.stringify(stalePlan));
dropPlan.made = Date.now() + 180000;
msg = await ph4.eval('receiveExchange')(fileOf('p.json', JSON.stringify(dropPlan)));
await wait(60);
chk('deleting it on the desktop now propagates', ph4.eval('APPTS').length === 0, msg);
chk('and is reported as a removal', /removed/.test(msg), msg);

/* ---------- it stops being resent once acknowledged ---------- */
const ph5 = boot({phone:true}); await ready(ph5);
const a5 = ph5.eval('ACCOUNTS')[0];
await unplannedCall(ph5, a5.a);
chk('an unacknowledged appointment is queued to send',
    (await ph5.eval('buildCallFile')(false)).newAppts.length === 1);
ph5.eval('APPTS')[0].acked = true;
await ph5.eval('apptsPut')(ph5.eval('APPTS')[0]);
chk('once acknowledged it is not sent again',
    (await ph5.eval('buildCallFile')(false)).newAppts.length === 0);

/* ---------- it behaves like any other appointment afterwards ---------- */
const ph6 = boot({phone:true}); await ready(ph6);
const a6 = ph6.eval('ACCOUNTS')[0];
await unplannedCall(ph6, a6.a);
const $6 = id => ph6.document.getElementById(id);
ph6.eval("go('belt')");
$6('bAsset').value = 'UNPLANNED-1'; $6('bSave').click(); await wait(60);
$6('closeCall').click(); await wait(90);
chk('closing the call marks the visit done',
    ph6.eval('APPTS')[0].status === 'done', ph6.eval('APPTS')[0].status);
chk('and the notes attach to it', !!ph6.eval('APPTS')[0].callSummary);
chk('it counts towards cadence',
    ph6.eval('dueState')(a6).basis === 'visit' && ph6.eval('dueState')(a6).days === 0,
    JSON.stringify(ph6.eval('dueState')(a6)));
chk('it is exportable to Outlook like any other',
    ph6.eval('apState')(ph6.eval('APPTS')[0]) === 'new');
chk('and the account history shows it',
    (ph6.eval('openAccount')(a6.a), $6('avHistory').textContent.includes('1 belt')),
    $6('avHistory').textContent.slice(0,120));

/* ---------- backup carries it ---------- */
const bk = await ph6.eval('buildBackup')(false);
chk('a backup carries the unplanned appointment',
    bk.appts.length === 1 && bk.appts[0].unplanned === true);

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
