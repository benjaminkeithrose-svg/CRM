import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

function boot(phone) {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  if (phone === 'width') { Object.defineProperty(w, 'innerWidth', {value:390, configurable:true}); }
  else w.matchMedia = q => ({ matches: !!phone && q.includes('max-width'), media:q,
                              addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
}
// plant an appointment on a given ISO date
async function plant(w, acct, dateISO, time, opts) {
  const ap = Object.assign({
    id:'ap'+Math.random().toString(36).slice(2,9), acct, type:'Intralox site visit',
    date:dateISO, start:time||'09:00', dur:60, agenda:'', contacts:[0]
  }, opts||{});
  w.eval('APPTS').push(ap);
  await w.eval('apptsPut')(ap);
  return ap;
}

const w = boot(true);
const $ = id => w.document.getElementById(id);
await ready(w);
const ACC = w.eval('ACCOUNTS');
const withC = ACC.find(a => a.c.length > 0) || ACC[0];
const TODAY = w.eval('todayISOdate()');
const MON = w.eval('iso(startOfWeek(new Date()))');

/* ---------- routing by width ---------- */
w.document.querySelector('[data-go="plan"]').click(); await wait(50);
chk('the phone gets Today, not the planner', $('s-today').classList.contains('on'));
chk('the planner shortcut is hidden on a phone', $('tvPlanner').hidden === true);

const wd = boot(false);
await ready(wd);
wd.document.querySelector('[data-go="plan"]').click(); await wait(50);
chk('the desktop gets the planner', wd.document.getElementById('s-plan').classList.contains('on'));
wd.document.getElementById('pToday2').click(); await wait(40);
chk('the desktop can still reach Today', wd.document.getElementById('s-today').classList.contains('on'));
chk('and is offered the way back', wd.document.getElementById('tvPlanner').hidden === false);

/* ---------- empty today says nothing more than that ---------- */
w.eval("go('today')"); await wait(40);
chk('empty Today says nothing is on', $('tvHint').textContent === 'Nothing planned today.',
    $('tvHint').textContent);
chk('empty Today suggests nothing', $('tvBody').innerHTML.trim() === '', $('tvBody').innerHTML.slice(0,80));
chk('no overdue accounts are pushed at you', !$('tvBody').textContent.includes('overdue') &&
    !$('tvBody').textContent.includes('past cadence'));
chk('an unplanned call is still one tap away', !!$('tvUnplanned'));

/* ---------- a visit today ---------- */
const ap1 = await plant(w, withC.a, TODAY, '09:30', {agenda:'Walk the boning room'});
w.eval('renderToday()'); await wait(30);
chk('the visit shows', $('tvBody').textContent.includes(withC.a));
chk('hint counts it', $('tvHint').textContent === '1 visit today', $('tvHint').textContent);
chk('the time shows', $('tvBody').textContent.includes('09:30'));
chk('the agenda shows', $('tvBody').textContent.includes('Walk the boning room'));
chk('it reads as planned', $('tvBody').innerHTML.includes('>planned<'));
chk('start is offered', !!$('tvBody').querySelector('[data-start]'));
chk('close out is offered', !!$('tvBody').querySelector('[data-closeout]'));
chk('move is offered', !!$('tvBody').querySelector('[data-move]'));
chk('there is no drag handle anywhere', !$('tvBody').innerHTML.includes('draggable'));
const c0 = withC.c[0];
if (c0.p) chk('a contact with a number is a tel: link',
    $('tvBody').innerHTML.includes('href="tel:'+c0.p.replace(/\s/g,'')+'"'));
else chk('a contact with no number is stated plainly',
    $('tvBody').textContent.includes('no number on file'));

/* ---------- start ---------- */
$('tvBody').querySelector('[data-start]').click(); await wait(80);
chk('start goes straight to the dashboard, skipping the contact picker',
    $('s-dash').classList.contains('on'));
const call1 = w.eval('call');
chk('the call is pre-filled with the account', call1.customer === withC.a);
chk('the call is pre-filled with the contacts',
    call1.contacts.length === 1 && call1.contacts[0].name === c0.n);
chk('the call carries the zone and focus', call1.zone === withC.z && call1.focus === withC.foc);
chk('the call points back at the appointment', call1.apptId === ap1.id);
chk('the appointment points at the call', w.eval('APPTS').find(a => a.id===ap1.id).callId === call1.id);
chk('the appointment is now in progress',
    w.eval('APPTS').find(a => a.id===ap1.id).status === 'in progress');

// starting again resumes rather than duplicating
w.eval("go('today')"); await wait(40);
$('tvBody').querySelector('[data-start]').click(); await wait(80);
chk('starting again resumes the same call', w.eval('call').id === call1.id);
chk('no duplicate call was created', (await w.eval('callsAll()')).length === 1,
    String((await w.eval('callsAll()')).length));

/* ---------- closing a call with nothing in it is a finished state ---------- */
w.eval("go('dash')"); await wait(30);
$('closeCall').click(); await wait(80);
const done = (await w.eval('callsAll()'))[0];
chk('closing marks the call done', done.status === 'done');
chk('an empty call is flagged as no report', done.noReport === true);
chk('the appointment followed it to done',
    w.eval('APPTS').find(a => a.id===ap1.id).status === 'done');
chk('the account history reads "no report", not "0 entries"',
    (w.eval('viewAcct'), true));
w.eval('openAccount')(withC.a); await wait(40);
chk('account history says no report', $('avHistory').textContent.includes('no report'),
    $('avHistory').textContent);
chk('account history does not say 0 entries', !$('avHistory').textContent.includes('0 entr'));
chk('home list says no report too',
    (await w.eval('renderHome()'), $('pastList').textContent.includes('no report')));
chk('nothing counts uncompiled calls as outstanding',
    !$('pastList').textContent.match(/not (written|compiled)/i) &&
    !w.document.getElementById('planInfo').textContent.match(/not written/i));

/* ---------- a settled visit drops its actions ---------- */
w.eval("go('today')"); await wait(40);
chk('a done visit shows no start button', !$('tvBody').querySelector('[data-start]'));
chk('a done visit can be reopened', !!$('tvBody').querySelector('[data-reopen]'));
chk('a done visit is dimmed', $('tvBody').innerHTML.includes('settled'));
$('tvBody').querySelector('[data-reopen]').click(); await wait(60);
chk('reopening puts the actions back', !!$('tvBody').querySelector('[data-start]'));
chk('reopening does not ask a pointless question',
    w.eval('APPTS').find(a => a.id===ap1.id).status === 'planned');

/* ---------- close out with no report, without opening the call ---------- */
const w2 = boot(true); await ready(w2);
const A2 = w2.eval('ACCOUNTS');
const acc2 = A2.find(a => a.c.length > 0) || A2[0];
const ap2 = await plant(w2, acc2.a, w2.eval('todayISOdate()'), '11:00');
w2.eval("go('today')"); await wait(40);
const before = (await w2.eval('callsAll()')).length;
w2.document.getElementById('tvBody').querySelector('[data-closeout]').click(); await wait(100);
const after = await w2.eval('callsAll()');
chk('closing out files a call against the account', after.length === before + 1);
chk('the filed call is done with no report',
    after[0].status === 'done' && after[0].noReport === true && after[0].closed === true);
chk('the filed call has no entries', after[0].entries.length === 0);
chk('the appointment is done', w2.eval('APPTS').find(a => a.id===ap2.id).status === 'done');
chk('closing out never opened the call flow',
    w2.document.getElementById('s-today').classList.contains('on'));
// and it counts towards cadence, because you were there
const d2 = w2.eval('dueState')(acc2);
chk('a closed-out visit resets the cadence clock', d2.basis === 'visit' && d2.days === 0,
    JSON.stringify(d2));

/* ---------- doing the visit must not disturb Outlook ---------- */
const ap2b = w2.eval('APPTS').find(a => a.id === ap2.id);
ap2b.exp = w2.eval('apRev')(ap2b); ap2b.expAt = Date.now();
chk('the appointment is synced', w2.eval('apState')(ap2b) === 'synced');
ap2b.status = 'in progress';
chk('starting a visit does not flip it to changed', w2.eval('apState')(ap2b) === 'synced');
ap2b.status = 'done'; ap2b.callId = 'c123';
chk('completing a visit does not flip it to changed', w2.eval('apState')(ap2b) === 'synced');
// the appointment's own status is not in the revision; the written-up notes are
const revNow = w2.eval('apRev')(ap2b);
ap2b.status = 'planned';
chk('the appointment status is not part of the invite revision',
    w2.eval('apRev')(ap2b) === revNow);
ap2b.status = 'done';
// but moving it still does
const keep = ap2b.date;
ap2b.date = '2027-01-04';
chk('moving it still flips it to changed', w2.eval('apState')(ap2b) === 'changed');
ap2b.date = keep;

/* ---------- missed and cancelled ---------- */
const w3 = boot(true); await ready(w3);
const A3 = w3.eval('ACCOUNTS');
const yest = w3.eval("iso(addDays(new Date(), -1))");
const monISO = w3.eval('iso(startOfWeek(new Date()))');
const lateDate = yest >= monISO ? yest : monISO;
const apLate = await plant(w3, A3[0].a, lateDate, '08:00');
const apToday = await plant(w3, A3[1].a, w3.eval('todayISOdate()'), '13:00');
w3.eval("go('today')"); await wait(40);
if (lateDate < w3.eval('todayISOdate()')) {
  chk('an unresolved earlier visit is surfaced separately',
      w3.document.getElementById('tvBody').textContent.includes('Earlier this week'));
  chk('it is not auto-marked missed',
      w3.eval('APPTS').find(a => a.id===apLate.id).status === undefined ||
      w3.eval('APPTS').find(a => a.id===apLate.id).status === 'planned',
      String(w3.eval('APPTS').find(a => a.id===apLate.id).status));
  chk('missed is offered only on a late visit',
      w3.document.getElementById('tvBody').querySelectorAll('[data-missed]').length === 1);
  w3.document.getElementById('tvBody').querySelector('[data-missed]').click(); await wait(60);
  chk('marking missed sticks', w3.eval('APPTS').find(a => a.id===apLate.id).status === 'missed');
  chk('a missed visit files no call', (await w3.eval('callsAll()')).length === 0);
  chk('missed and done read differently',
      w3.eval('AP_STATUS').missed.cls !== w3.eval('AP_STATUS').done.cls);
} else {
  ok.push('today is Monday, no earlier-in-week visit to test');
  ok.push('(missed path not exercised)');
  ok.push('(missed path not exercised)');
  ok.push('(missed path not exercised)');
  ok.push('(missed path not exercised)');
}
w3.eval("go('today')"); await wait(40);
const cancelBtn = w3.document.getElementById('tvBody').querySelector('[data-cancel]');
cancelBtn.click(); await wait(60);
chk('cancelling sticks', w3.eval('APPTS').some(a => a.status === 'cancelled'));
chk('a cancelled visit files no call', (await w3.eval('callsAll()')).length === 0);

/* ---------- move ---------- */
w3.eval("go('today')"); await wait(40);
const mv = w3.document.getElementById('tvBody').querySelector('[data-move]');
if (mv) {
  mv.click(); await wait(40);
  chk('the move dialog opens', w3.document.getElementById('mvdlg').hasAttribute('open'));
  const days = w3.document.getElementById('mvDays').querySelectorAll('[data-day]');
  chk('it offers a fortnight of weekdays', days.length === 10, String(days.length));
  chk('every option is a weekday',
      [...days].every(b => w3.eval('isWeekday')(w3.eval('parseIso')(b.dataset.day))));
  chk('the current day is not selectable',
      [...days].some(b => b.disabled));
  const pick = [...days].find(b => !b.disabled);
  const target = pick.dataset.day;
  pick.click(); await wait(60);
  chk('the visit moved', w3.eval('APPTS').some(a => a.date === target));
  chk('the dialog closed', !w3.document.getElementById('mvdlg').hasAttribute('open'));
  const moved = w3.eval('APPTS').find(a => a.date === target);
  chk('a phone move is stamped, because the desktop owns the schedule',
      moved.movedOn === 'phone' && typeof moved.movedAt === 'number',
      JSON.stringify({on:moved.movedOn, at:typeof moved.movedAt}));
  chk('the move persisted', (await w3.eval('apptsAll()')).some(a => a.date === target));
} else {
  for (let i=0;i<8;i++) ok.push('(no movable visit left to test)');
}

/* ---------- this week ---------- */
const w4 = boot(true); await ready(w4);
const A4 = w4.eval('ACCOUNTS');
for (let i=0;i<3;i++) await plant(w4, A4[i].a, w4.eval(`iso(addDays(weekViewStart(),${i}))`), '10:00');
w4.eval("go('today')"); await wait(40);
w4.document.getElementById('tvView').querySelectorAll('button')[1].click(); await wait(50);
const wk = w4.document.getElementById('tvBody');
chk('this week renders five day blocks', wk.querySelectorAll('.dayblk').length === 5,
    String(wk.querySelectorAll('.dayblk').length));
chk('there is no month grid', !wk.innerHTML.includes('mcell'));
chk('each planted visit appears', A4.slice(0,3).every(a => wk.textContent.includes(a.a)));
chk('empty days say so rather than being blank',
    wk.textContent.includes('Nothing planned.'));
chk('the week hint counts the visits',
    w4.document.getElementById('tvHint').textContent === '3 visits this week',
    w4.document.getElementById('tvHint').textContent);
// on a weekend "this week" is the week ahead, so no day in it is today
const weekend = [0,6].includes(new Date().getDay());
chk(weekend ? 'on a weekend the week ahead is shown, so no day is today'
            : 'today is marked in the week',
    weekend ? !wk.innerHTML.includes('isToday') : wk.innerHTML.includes('isToday'));
chk('the week shown starts on a Monday',
    w4.eval('weekViewStart()').getDay() === 1);
chk(weekend ? 'on a weekend the week shown is in the future'
            : 'on a weekday the week shown contains today',
    weekend ? w4.eval("iso(weekViewStart())") > w4.eval('todayISOdate()')
            : w4.eval("iso(weekViewStart())") <= w4.eval('todayISOdate()'));
chk('the header follows the view', w4.document.getElementById('title').textContent === 'This week');

/* ---------- routing survives a browser with no matchMedia ---------- */
const w5 = boot('width');   // no matchMedia at all, narrow window
await ready(w5);
chk('with no matchMedia, a narrow window still routes to Today',
    w5.eval('isPhone()') === true, String(w5.eval('innerWidth')));
const w6 = boot(false);
delete w6.matchMedia;
chk('with no matchMedia, a wide window routes to the planner',
    w6.eval('isPhone()') === false, String(w6.eval('innerWidth')));

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['s-today','tvView','tvHint','tvBody','tvUnplanned','tvPlanner','mvdlg','mvDays','pToday2'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
