import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
const fileOf = (name, text) => ({ name, text: async () => text });

function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches:false, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };`);
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
  w.document.querySelector('[data-go="plan"]').click(); await wait(60);
}
const unfold = s => s.replace(/\r\n[ \t]/g, '');
const lines = s => unfold(s).split('\r\n').filter(Boolean);
const val = (s, k) => { const l = lines(s).find(x => x.startsWith(k)); return l ? l.slice(l.indexOf(':')+1) : null; };
const unesc = s => String(s).replace(/\\n/g,'\n').replace(/\\,/g,',').replace(/\\;/g,';').replace(/\\\\/g,'\\');
// a naive CSV row splitter, good enough to check quoting held
function csvRows(text){
  const out=[]; let row=[], f='', q=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(q){ if(c==='"'){ if(text[i+1]==='"'){f+='"';i++;} else q=false; } else f+=c; }
    else if(c==='"') q=true;
    else if(c===',') { row.push(f); f=''; }
    else if(c==='\n'){ row.push(f); out.push(row); row=[]; f=''; }
    else if(c!=='\r') f+=c;
  }
  if(f.length||row.length){ row.push(f); out.push(row); }
  return out.filter(r=>r.some(x=>x!==''));
}

const w = boot();
const $ = id => w.document.getElementById(id);
await ready(w);
const ACC = w.eval('ACCOUNTS');
const acct = ACC.find(a => a.c.length > 0) || ACC[0];

/* ---------- book a visit, do it, write it up ---------- */
await w.eval('openDialog')(null, {acct: acct.a, date: w.eval('iso(weekDays()[1])')});
$('dAgenda').value = 'Walk line 2';
$('dSave').click(); await wait(60);
const ap = w.eval('APPTS')[0];

// export it once so it is green, then do the visit
w.eval('window.__dl = []');
await w.eval('doExport')('pending'); await wait(60);
chk('the appointment starts in Outlook', w.eval('apState')(ap) === 'synced');
chk('with no notes on it yet', !ap.callSummary);
const icsBefore = w.eval('window.__dl')[0].text;
chk('the invite carries no call notes before the visit',
    !unesc(val(icsBefore,'DESCRIPTION:')).includes('CALL NOTES'));

w.eval("go('today')"); await wait(40);
await w.eval('startVisit')(ap.id); await wait(80);
w.eval("go('belt')");
$('bAsset').value = '61-156 boning line 2';
$('bDesc').value = 'S800 OHFT';
$('bWidth').value = '606';
$('bCvLen').value = '9.4';
$('bSprDesc').value = 'S40 8T';
$('bSave').click(); await wait(60);
w.eval("go('health')");
$('hAsset').value = 'CV-114 drive end';
$('hFault').value = 'Sprocket teeth worn; tracking right, needs attention';
w.document.querySelector('#hSev button[data-v="Plan"]').click();
$('hSave').click(); await wait(60);
w.eval("go('note')");
$('nText').value = 'Kill rate up to 180k/week';
$('nSave').click(); await wait(60);
w.eval("call.entries[0].photos = ['x','y']; call.loose = ['z'];");
await w.eval('saveCall()');
$('closeCall').click(); await wait(100);

/* ---------- the notes reach the appointment ---------- */
const ap2 = w.eval('APPTS')[0];
chk('the appointment picked up the notes', !!ap2.callSummary);
chk('the summary carries the belt', ap2.callSummary.belts.length === 1);
chk('the summary carries the health item', ap2.callSummary.health.length === 1);
chk('the summary carries the note', ap2.callSummary.notes.length === 1);
chk('the summary counts the photos', ap2.callSummary.photos === 3, String(ap2.callSummary.photos));
chk('the summary holds no image data', !JSON.stringify(ap2.callSummary).includes('data:'));

/* ---------- notes join the revision hash ---------- */
chk('writing the visit up flips the invite to changed',
    w.eval('apState')(ap2) === 'changed', w.eval('apState')(ap2));
chk('the revision string includes the notes',
    w.eval('apRev')(ap2).includes('61-156 boning line 2'));
const revBefore = w.eval('apRev')(ap2);
ap2.callSummary.notes[0].text = 'edited';
chk('editing the notes changes the revision', w.eval('apRev')(ap2) !== revBefore);
ap2.callSummary.notes[0].text = 'Kill rate up to 180k/week';
chk('putting it back restores it', w.eval('apRev')(ap2) === revBefore);

/* ---------- both bodies ---------- */
w.eval('window.__dl = []');
await w.eval('doExport')('pending'); await wait(60);
const ics = w.eval('window.__dl')[0].text;
const desc = unesc(val(ics,'DESCRIPTION:'));
const alt = unesc(val(ics,'X-ALT-DESC;FMTTYPE=text/html'));

chk('the plain body carries the notes', desc.includes('CALL NOTES'), desc.slice(0,80));
chk('the plain body has the belt', desc.includes('61-156 boning line 2'));
chk('the plain body has the belt detail', desc.includes('S800 OHFT') && desc.includes('606'));
chk('the plain body has the health item',
    desc.includes('CV-114 drive end') && desc.includes('Severity: Plan'));
chk('the plain body has the general note', desc.includes('Kill rate up to 180k/week'));
chk('the plain body is plain - no tags', !/<[a-z]/i.test(desc), desc.match(/<[a-z][^>]*>/i));
chk('empty fields read as an em dash, not N/A',
    desc.includes('\u2014') && !/: N\/A/.test(desc));

chk('the HTML body carries the notes too', alt.includes('Call notes'));
chk('the HTML body has the belt', alt.includes('61-156 boning line 2'));
chk('the HTML body uses Arial', alt.includes('font-family:Arial'));
chk('the HTML body has no style block', !alt.includes('<style'));
chk('the HTML body has no CSS classes', !/class=/.test(alt));
chk('the HTML body styles inline', alt.includes('style="'));
chk('the HTML body is not the full notes file', !alt.includes('<!DOCTYPE'));

/* ---------- photos are an index, not the record ---------- */
chk('no image data reaches the invite at all', !ics.includes('data:image'));
chk('the plain body says how many photos there are',
    desc.includes('3 photos taken'), desc.split('\n').find(l => l.includes('photo')));
chk('the HTML body says the same', alt.includes('3 photos taken'));
chk('and says images cannot travel in an invite',
    alt.includes('cannot travel in a calendar invite'));

/* ---------- do not type into Outlook ---------- */
chk('the plain body warns against editing in Outlook',
    desc.includes('Do not type into this invite'), desc.slice(-160));
chk('it says why', desc.includes('re-downloading replaces the body'));
chk('the HTML body carries the same warning', alt.includes('Do not type into this invite'));

/* ---------- still a valid ICS ---------- */
chk('no line exceeds 75 octets',
    ics.split('\r\n').every(l => Buffer.byteLength(l,'utf8') <= 75),
    String(Math.max(...ics.split('\r\n').map(l => Buffer.byteLength(l,'utf8')))));
chk('semicolons in the fault text survived escaping',
    val(ics,'DESCRIPTION:').includes('worn\\;'), 'escaped');
chk('UID is unchanged, so Outlook updates in place',
    val(ics,'UID:') === val(icsBefore,'UID:'));
chk('SEQUENCE rose because the notes changed it',
    Number(val(ics,'SEQUENCE:')) > Number(val(icsBefore,'SEQUENCE:')),
    `${val(icsBefore,'SEQUENCE:')} -> ${val(ics,'SEQUENCE:')}`);
chk('exporting settles it again', w.eval('apState')(w.eval('APPTS')[0]) === 'synced');

/* ---------- a visit with nothing to report ---------- */
const w2 = boot(); await ready(w2);
const A2 = w2.eval('ACCOUNTS');
const acct2 = A2[1];
await w2.eval('openDialog')(null, {acct: acct2.a, date: w2.eval('iso(weekDays()[0])')});
w2.document.getElementById('dSave').click(); await wait(60);
const apB = w2.eval('APPTS')[0];
w2.eval("go('today')"); await wait(40);
await w2.eval('closeOutVisit')(apB.id); await wait(100);
const sumB = w2.eval('APPTS')[0].callSummary;
chk('a closed-out visit still writes a summary', !!sumB);
chk('and it is flagged as nothing to report', sumB.noReport === true);
const tB = w2.eval('notesText')(sumB);
chk('the plain body says so plainly',
    tB.includes('Visit completed. Nothing to report.'), tB.slice(0,120));
chk('it does not read as an empty form',
    !tB.includes('BELT') && !tB.includes('HEALTH CHECK'), tB);
chk('the HTML body says the same', w2.eval('notesHtml')(sumB).includes('Nothing to report'));

/* ---------- call-notes.csv ---------- */
w.eval('window.__dl = []');
await w.eval('exportCallNotes')(); await wait(60);
const dl = w.eval('window.__dl')[0];
chk('the CSV downloads under the name the spec asks for', dl.name === 'call-notes.csv', dl.name);
chk('it is a csv', dl.mime.startsWith('text/csv'));
const rows = csvRows(dl.text);
chk('there is a header row', rows[0][0] === 'Account Name');
chk('the header names the account, the date and the notes',
    rows[0].includes('Call Date') && rows[0].includes('Notes') && rows[0].includes('Account Manager'),
    JSON.stringify(rows[0]));
chk('one row per completed call', rows.length === 2, String(rows.length - 1));
const row = rows[1];
chk('the row names the account', row[0] === acct.a, row[0]);
chk('the row carries the zone', row[1] === acct.z);
chk('the row carries the manager', row[3] === w.eval('effMgr')(acct));
chk('the row counts the belts', row[9] === '1', row[9]);
chk('the row counts the health items', row[11] === '1');
chk('the row counts the photos', row[12] === '3');
chk('the notes cell holds the whole plain-text body',
    row[14].includes('61-156 boning line 2') && row[14].includes('CV-114 drive end'),
    row[14].slice(0,60));
chk('newlines survive inside the quoted cell', row[14].includes('\n'));
chk('every field is quoted',
    dl.text.split('\r\n')[0].split(',').every(f => f.startsWith('"') && f.endsWith('"')));
chk('a quote inside a value would be doubled',
    w.eval('callNotesCsv').toString().includes('replace(/"/g'));

// an open call is not exported
w.eval("call = {id:'open1', customer:" + JSON.stringify(acct.a) +
       ", date:'01/09/2026', type:'Site call', mgr:'m', contacts:[], entries:[], loose:[], " +
       "status:'in progress', closed:false, updated:Date.now()};");
await w.eval('saveCall()');
const again = await w.eval('callNotesCsv')();
chk('a call still in progress is left out of the CSV', again.n === 1, String(again.n));

/* ---------- notes ride the exchange ---------- */
const cf = await w.eval('buildCallFile')(false);
chk('the call file carries the notes summary',
    cf.apptUpdates.some(u => u.callSummary && u.callSummary.belts.length === 1));
chk('the call file summary has no image data', !JSON.stringify(cf.apptUpdates).includes('data:'));
const pc = boot(); await ready(pc);
// give the desktop the same appointment first
await pc.eval('openDialog')(null, {acct: acct.a, date: pc.eval('iso(weekDays()[1])')});
pc.document.getElementById('dSave').click(); await wait(60);
// give the desktop the same appointment id the phone worked against
const pcOld = pc.eval('APPTS')[0];
await pc.eval('apptsDel')(pcOld.id);
const cloned = Object.assign({}, pcOld, {id: ap.id});
pc.__ap = cloned;
pc.eval('APPTS = [window.__ap]');
await pc.eval('apptsPut')(cloned);
await pc.eval('receiveExchange')(fileOf('c.json', JSON.stringify(cf))); await wait(80);
const pcAp = pc.eval('APPTS').find(a => a.id === ap.id);
chk('the desktop receives the written-up notes', !!pcAp && !!pcAp.callSummary);
chk('and can rebuild the invite body from them',
    pc.eval('notesText')(pcAp.callSummary).includes('61-156 boning line 2'));
chk('the outcome applies even when the desktop record is newer',
    pcAp.touchedAt >= cf.apptUpdates[0].touchedAt);
chk('the exchange screen reports how many are written up',
    (pc.eval('renderExchange()'), pc.document.getElementById('exStat').textContent.includes('written up')),
    pc.document.getElementById('exStat').textContent);

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
chk('index.html has #exCallNotes', idx.includes('id="exCallNotes"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
