import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const issues = [], notes = [], pass = [];
const chk = (n, c, x='') => c ? pass.push(n) : issues.push(n + (x ? ' :: ' + x : ''));
const note = m => notes.push(m);
const wait = ms => new Promise(r => setTimeout(r, ms));

const app = fs.readFileSync('app.js','utf8');
// manuals.js drives its own screen and viewer, so it counts as code that reaches the markup
const manuals = fs.existsSync('manuals.js') ? fs.readFileSync('manuals.js','utf8') : '';
const idx = fs.readFileSync('index.html','utf8');
const sw  = fs.readFileSync('sw.js','utf8');
const zones = fs.readFileSync('zones.js','utf8');
const mf  = JSON.parse(fs.readFileSync('manifest.webmanifest','utf8'));

console.log('=== STATIC ===');

/* ---- ids ---- */
const declaredIds = [...idx.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
const dupes = declaredIds.filter((v,i) => declaredIds.indexOf(v) !== i);
chk('no duplicate ids in index.html', dupes.length === 0, JSON.stringify([...new Set(dupes)]));

const reach = app + '\n' + manuals;
const used = new Set([...reach.matchAll(/\$\('([^']+)'\)/g)].map(m => m[1]));
[...reach.matchAll(/getElementById\(['"]([^'"]+)['"]\)/g)].forEach(m => used.add(m[1]));
[...app.matchAll(/'s-'\s*\+\s*name/g)].forEach(() => {});
const dynamicIds = [...app.matchAll(/id="([\w-]+)"/g)].map(m => m[1]);   // built into innerHTML
const missing = [...used].filter(id => !declaredIds.includes(id) && !dynamicIds.includes(id));
chk('every element the code reaches exists in the markup', missing.length === 0, JSON.stringify(missing));

// screens are reached dynamically via 's-'+name, so check TITLES against sections
const titleKeys = [...(app.match(/const TITLES = \{[\s\S]*?\n\};/) || [''])[0]
  .matchAll(/(\w+):\s*\[/g)].map(m => m[1]);
const sections = declaredIds.filter(i => i.startsWith('s-')).map(i => i.slice(2));
const noSection = titleKeys.filter(k => !sections.includes(k));
chk('every named screen has a section', noSection.length === 0, JSON.stringify(noSection));
const noTitle = sections.filter(s => !titleKeys.includes(s));
chk('every section has a title entry', noTitle.length === 0, JSON.stringify(noTitle));

// ids in the markup nothing ever touches
const inert = new Set(['back','title','subtitle','bar','toast']);
const unused = declaredIds.filter(id =>
  !used.has(id) && !id.startsWith('s-') && !inert.has(id) &&
  !new RegExp("[\"'#]" + id + "\\b").test(reach) &&
  !new RegExp('id="' + id + '"[^>]*(hidden|class="scr")').test(idx));
chk('no markup left behind that nothing drives', unused.length === 0, JSON.stringify(unused));

/* ---- data-go targets ---- */
const goTargets = [...idx.matchAll(/data-go="([^"]+)"/g)].map(m => m[1]);
const handled = (app.match(/t==='[a-z]+'/g) || []).map(s => s.slice(5,-1));
const unhandled = goTargets.filter(t => !handled.includes(t));
chk('every data-go button is handled', unhandled.length === 0, JSON.stringify(unhandled));

/* ---- functions ---- */
const defined = new Set([
  ...[...app.matchAll(/^(?:async )?function (\w+)/gm)].map(m => m[1]),
  ...[...app.matchAll(/\b(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(?[\w,\s]*\)?\s*=>/g)].map(m => m[1]),
  // several names can be declared on one line: const a = ..., b = ...;
  // several names can be declared on one line, with or without initialisers:
  //   const serSel = () => ..., stySel = () => ...;   let a, b, c;
  ...[...app.matchAll(/^(?:let|const|var)\s+(.+?);\s*$/gm)]
      .flatMap(m => m[1].split(',').map(x => x.trim().split(/[=\s]/)[0]))
      .filter(x => /^\w+$/.test(x))
]);
/* Regex string-stripping kept mis-splitting on concatenated literals, so the
   source is scanned properly: a small state machine that walks the file and
   blanks out strings, template literals, regexes and comments before looking
   for calls. Worth the twenty lines - the previous version reported prose from
   inside quoted strings as undefined functions. */
function stripLiterals(src){
  let out = '', i = 0, n = src.length;
  const prevMeaningful = () => { let j = out.length - 1;
    while(j >= 0 && /\s/.test(out[j])) j--; return j >= 0 ? out[j] : ''; };
  while(i < n){
    const c = src[i], d = src[i+1];
    if(c === '/' && d === '/'){ while(i < n && src[i] !== '\n') i++; continue; }
    if(c === '/' && d === '*'){ i += 2; while(i < n && !(src[i] === '*' && src[i+1] === '/')) i++; i += 2; continue; }
    if(c === '"' || c === "'" || c === '`'){
      const q = c; i++;
      while(i < n && src[i] !== q){ if(src[i] === '\\') i++; i++; }
      i++; out += '""'; continue;
    }
    if(c === '/' && !'})]\'"`'.includes(prevMeaningful()) && !/[\w$]/.test(prevMeaningful())){
      i++; let cls = false;
      while(i < n && (cls || src[i] !== '/')){
        if(src[i] === '\\') i++;
        else if(src[i] === '[') cls = true;
        else if(src[i] === ']') cls = false;
        i++;
      }
      i++; while(i < n && /[gimsuy]/.test(src[i])) i++;
      out += '/RE/'; continue;
    }
    out += c; i++;
  }
  return out;
}
const code = stripLiterals(app);
const called = new Set([...code.matchAll(/(?:^|[^.\w$])([a-z][A-Za-z0-9_]{3,})\s*\(/g)].map(m => m[1]));
const builtins = new Set(['function','if','for','while','switch','catch','return','typeof',
  'parseInt','parseFloat','isNaN','decodeURIComponent','encodeURIComponent','unescape','escape',
  'setTimeout','clearTimeout','setInterval','confirm','alert','atob','btoa','fetch','require',
  'addEventListener','removeEventListener','querySelector','querySelectorAll','getElementById',
  'createElement','appendChild','removeChild','dispatchEvent','matchMedia','structuredClone',
  'createObjectURL','revokeObjectURL','showDirectoryPicker','getFileHandle','createWritable',
  'getFile','queryPermission','requestPermission','readAsDataURL','drawImage','getContext',
  'toDataURL','toBlob','arrayBuffer','startsWith','endsWith','includes','indexOf','lastIndexOf',
  'toLowerCase','toUpperCase','localeCompare','padStart','replace','split','slice','filter',
  'forEach','reduce','sort','join','push','unshift','splice','concat','some','every','find',
  'findIndex','keys','values','entries','assign','stringify','parse','getTime','getDate',
  'getMonth','getFullYear','getDay','getHours','getMinutes','setDate','setHours','toISOString',
  'toLocaleDateString','toLocaleTimeString','toLocaleString','trim','match','test','exec',
  'then','resolve','reject','all','from','isArray','hasAttribute','setAttribute',
  'removeAttribute','getAttribute','classList','toggle','contains','showModal','close','click',
  'scrollTo','prepend','insertBefore','pushState','replaceState','back','forward','share',
  'canShare','persist','open','transaction','objectStore','getAll','delete','clear','put',
  'createObjectStore','deleteObjectStore','sheet_to_json','sheet_to_csv','readFile','warn',
  'error','log','charCodeAt','fromCharCode','max','min','round','floor','abs','hypot','encode',
  'text','json','blob','call','apply','bind','toFixed','repeat','substring','read','skipWaiting','async','await','else','const','new','delete','void','yield',
  'claim','waitUntil','respondWith','clone','databases','value']);
const reallyUndef = [...called].filter(f => !defined.has(f) && !builtins.has(f));
chk('no function called that is never defined', reallyUndef.length === 0, JSON.stringify(reallyUndef.slice(0,12)));

/* ---- storage names ---- */
const noComments = app.replace(/\/\*[\s\S]*?\*\//g,'').replace(/^\s*\/\/.*$/gm,'');
chk('no beltcall database name in code', !noComments.includes('beltcall'));
chk('every localStorage key goes through LS()',
    !/localStorage\.(get|set|remove)Item\(\s*['"]/.test(noComments),
    (noComments.match(/localStorage\.\w+\(\s*['"][^'"]+/g)||[]).join(', '));
chk('sw only clears its own caches', sw.includes("k.startsWith('fieldcrm-')"));

/* ---- assets agree ---- */
const repoFiles = ['index.html','app.js','zones.js','sw.js','manifest.webmanifest',
                   'icon-192.png','icon-512.png','icon-maskable-512.png'];
repoFiles.forEach(f => chk('repo file present: ' + f, fs.existsSync(f)));
// only the ASSETS array is a precache list; SHARE_KEY and the redirect target
// are runtime paths, not files on disk
const assetsBlock = (sw.match(/const ASSETS = \[[\s\S]*?\];/) || [''])[0];
const swAssets = [...assetsBlock.matchAll(/'\.\/([^']+)'/g)].map(m => m[1]).filter(Boolean);
swAssets.forEach(a => chk('sw caches a file that exists: ' + a, fs.existsSync(a)));
// index.html is cached as './' and a service worker never caches itself
const localCacheable = repoFiles.filter(f => f !== 'index.html' && f !== 'sw.js');
localCacheable.forEach(f => chk('sw caches ' + f, sw.includes("'./" + f + "'")));
mf.icons.forEach(i => chk('manifest icon exists: ' + i.src, fs.existsSync(i.src)));
mf.icons.forEach(i => chk('manifest icon is really a PNG: ' + i.src,
  fs.readFileSync(i.src).slice(0,8).toString('hex') === '89504e470d0a1a0a'));
chk('index.html references the manifest', idx.includes('manifest.webmanifest'));
chk('index.html loads zones before app', idx.indexOf('zones.js') < idx.indexOf('src="app.js"'));
chk('sw version was bumped past v1', /fieldcrm-v(?!1')\d+/.test(sw), (sw.match(/fieldcrm-v\d+/)||[])[0]);
chk('no reference to logo.png anywhere', !idx.includes('logo.png') && !app.includes('logo.png'));

/* ---- customer data ---- */
const planner = fs.readFileSync('/mnt/project/Zone_Call_Planner_v9.html','utf8');
const data = JSON.parse(planner.match(/<script[^>]*id="data"[^>]*>([\s\S]*?)<\/script>/)[1]);
const acctNames = data.accounts.map(a => a.a);
const people = new Set(); const emails = new Set();
data.accounts.forEach(a => a.c.forEach(c => { people.add(c.n); (c.e||[]).forEach(e => emails.add(e)); }));
for (const f of ['index.html','app.js','zones.js','sw.js','manifest.webmanifest']) {
  const T = fs.readFileSync(f,'utf8').toUpperCase();
  chk('no account names in ' + f, !acctNames.some(n => T.includes(n.toUpperCase())));
  chk('no contact emails in ' + f, ![...emails].filter(e => e.length > 6).some(e => T.includes(e.toUpperCase())));
  chk('no manager names in ' + f,
      ![...new Set(data.accounts.map(a => a.mgr).filter(Boolean))].some(m => T.includes(m.toUpperCase())));
}
chk('zone-overrides.json is NOT a repo file', !repoFiles.includes('zone-overrides.json'));

/* ---- browser-storage rules ---- */
chk('no sessionStorage anywhere', !app.includes('sessionStorage'));
chk('no eval in the app', !/\beval\s*\(/.test(noComments));
chk('no innerHTML built from an unescaped account name',
    !/innerHTML\s*=\s*[^;]*\+\s*a\.a\s*[+;]/.test(noComments), 'unescaped a.a into innerHTML');

console.log('static: ' + pass.length + ' ok, ' + issues.length + ' issues');

/* ================= RUNTIME ================= */
console.log('=== RUNTIME ===');
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

function boot(opts) {
  opts = opts || {};
  const errors = [];
  const dom = new JSDOM(idx, { runScripts:'dangerously', url:'https://x.github.io/f/',
    pretendToBeVisual:true, virtualConsole: new (require('jsdom').VirtualConsole)() });
  return { dom, errors };
}
// simpler: reuse the pattern from the other harnesses
function mk(opts) {
  opts = opts || {};
  const errors = [];
  const dom = new JSDOM(idx, { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.addEventListener('error', e => errors.push(String(e.error || e.message)));
  w.onerror = (m) => { errors.push(String(m)); };
  const realErr = console.error;
  w.console.error = (...a) => errors.push('console.error: ' + a.map(String).join(' '));
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  const stack = [null]; const h = {i:0};
  Object.defineProperty(w, 'history', { configurable:true, value:{
    get length(){ return h.i+1; }, get state(){ return stack[h.i]; },
    pushState(st){ stack.length = h.i+1; stack.push(st); h.i++; },
    replaceState(st){ stack[h.i] = st; },
    back(){ if(h.i===0) return; h.i--; const e = new w.Event('popstate'); e.state = stack[h.i]; w.dispatchEvent(e); }
  }});
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };`);
  return { w, errors };
}

/* ---- cold boot, nothing loaded ---- */
{
  const { w, errors } = mk({phone:true});
  await wait(200);
  const $ = id => w.document.getElementById(id);
  chk('cold boot throws nothing', errors.length === 0, errors.slice(0,3).join(' | '));
  chk('cold boot lands on home', $('s-home').classList.contains('on'));
  chk('cold boot reports no data', $('dbStat').textContent === 'No data loaded.');
  chk('cold boot warns there is no backup', $('bkStat').textContent.includes('No backup'));
  // every screen must render with an empty database
  for (const s of sections) {
    try { w.eval(`go(${JSON.stringify(s)})`); await wait(20); }
    catch(e){ issues.push('screen ' + s + ' throws when empty :: ' + e.message); }
  }
  chk('every screen renders with an empty database', errors.length === 0,
      errors.slice(0,3).join(' | '));
  w.eval("go('home')");
}

/* ---- full walkthrough ---- */
{
  const { w, errors } = mk({phone:false});
  await wait(180);
  const $ = id => w.document.getElementById(id);
  await w.eval('importCrm')(crmFile); await wait(120);
  await w.eval('renderHome()');
  chk('import throws nothing', errors.length === 0, errors.slice(0,3).join(' | '));

  const ACC = w.eval('ACCOUNTS');
  chk('accounts loaded', ACC.length > 0, String(ACC.length));

  // plan a visit, export it, do it, write it up, compile, export again
  w.document.querySelector('[data-go="plan"]').click(); await wait(60);
  const a = ACC.find(x => x.c.length > 0) || ACC[0];
  await w.eval('openDialog')(null, {acct:a.a, date: w.eval('iso(weekDays()[1])')});
  $('dAgenda').value = 'QA walkthrough';
  $('dSave').click(); await wait(60);
  await w.eval('doExport')('pending'); await wait(60);
  // territory marker
  const sel = $('terr').querySelector('select');
  sel.value = a.z; sel.onchange(); await wait(60);
  await w.eval('exportWeeks')('pending'); await wait(60);
  // do the visit
  w.eval("go('today')"); await wait(40);
  await w.eval('startVisit')(w.eval('APPTS')[0].id); await wait(80);
  w.eval("go('belt')");
  $('bAsset').value = 'QA-1'; $('bWidth').value = '600'; $('bSave').click(); await wait(60);
  w.eval("go('health')");
  $('hAsset').value = 'QA-2'; $('hFault').value = 'noted';
  // severity is required now, so the walkthrough has to answer it
  w.document.querySelector('#hSev button[data-v="Urgent"]').click();
  $('hSave').click(); await wait(60);
  w.eval("go('project')");
  $('pName').value = 'QA project'; $('pSave').click(); await wait(60);
  w.eval("go('note')");
  $('nText').value = 'QA note'; $('nSave').click(); await wait(60);
  w.eval("go('compile')"); await wait(40);
  const notesHtml = await w.eval('buildNotesHTML()');
  chk('the compiled notes build', notesHtml.length > 1000, String(notesHtml.length));
  chk('div tags balance', (notesHtml.match(/<div\b/g)||[]).length === (notesHtml.match(/<\/div>/g)||[]).length);
  chk('table tags balance', (notesHtml.match(/<table\b/g)||[]).length === (notesHtml.match(/<\/table>/g)||[]).length);
  await w.eval('markShared')('qa.html'); await wait(40);
  $('closeCall').click(); await wait(80);
  await w.eval('doExport')('all'); await wait(60);

  // reassign, exports, exchange, backup
  w.eval("go('plan')"); await wait(50);
  w.eval('openReassign')({account:a.a}); await wait(40);
  $('rTo').value = '__new__'; $('rTo').onchange(); $('rNew').value = 'QA Person'; $('rNew').oninput();
  $('rApply').click(); await wait(60);
  w.eval("go('home')"); await wait(40);
  w.eval('exportReassignments()');
  await w.eval('exportCallNotes')(); await wait(60);
  await w.eval('sendPlan()'); await wait(60);
  await w.eval('sendCalls()'); await wait(60);
  const bk = await w.eval('buildBackup')(false);
  const bkText = JSON.stringify(bk);
  chk('the whole walkthrough throws nothing', errors.length === 0, errors.slice(0,4).join(' | '));

  const dls = w.eval('window.__dl') || [];
  const kinds = dls.map(d => d.name);
  chk('every export produced a file', dls.length >= 6, JSON.stringify(kinds));
  chk('an appointment ICS was written', kinds.some(n => n.startsWith('field-calls-')));
  chk('a territory ICS was written', kinds.some(n => n.startsWith('territory-weeks-')));
  chk('the reassignment CSV was written', kinds.includes('manager-reassignments.csv'));
  chk('the call notes CSV was written', kinds.includes('call-notes.csv'));
  chk('a plan file was written', kinds.some(n => n.startsWith('field-crm-plan-')));
  chk('a call file was written', kinds.some(n => n.startsWith('field-crm-calls-')));
  chk('a backup builds', bkText.length > 500);
  dls.forEach(d => {
    if (d.name.endsWith('.ics')) {
      chk('ICS lines fit 75 octets: ' + d.name,
        d.text.split('\r\n').every(l => Buffer.byteLength(l,'utf8') <= 75));
      chk('ICS is closed: ' + d.name, d.text.trim().endsWith('END:VCALENDAR'));
    }
    if (d.name.endsWith('.json')) {
      try { JSON.parse(d.text); pass.push('valid JSON: ' + d.name); }
      catch(e){ issues.push('invalid JSON: ' + d.name); }
    }
    chk('no customer data leaked into a filename: ' + d.name,
      !acctNames.some(n => d.name.toUpperCase().includes(n.toUpperCase().slice(0,10))));
  });

  // restore the backup into a fresh install and compare
  const { w: fresh, errors: fe } = mk({phone:false});
  await wait(180);
  await fresh.eval('doRestore')({name:'b.json', text: async () => bkText});
  await wait(150);
  chk('a backup restores into a fresh install without error', fe.length === 0, fe.slice(0,3).join(' | '));
  chk('restored accounts match', fresh.eval('ACCOUNTS').length === ACC.length,
      `${fresh.eval('ACCOUNTS').length} vs ${ACC.length}`);
  chk('restored calls match', (await fresh.eval('callsAll()')).length === 1);
  chk('restored appointments match', fresh.eval('APPTS').length === w.eval('APPTS').length);
  chk('restored reassignments match', fresh.eval('MGR_OF')[a.a] === 'QA Person');
  chk('restored territory weeks match',
      JSON.stringify(fresh.eval('WEEKS')) === JSON.stringify(w.eval('WEEKS')));
}

/* ---- bad input ---- */
{
  const { w, errors } = mk({phone:false});
  await wait(180);
  const bad = [
    ['an empty file', {name:'x.csv', text: async () => '', arrayBuffer: async () => new ArrayBuffer(0)}],
    ['a csv with headers only', {name:'x.csv', text: async () => 'Account Name,Job Role\n'}],
    ['a csv with no account column', {name:'x.csv', text: async () => 'Foo,Bar\n1,2\n'}]
  ];
  for (const [what, f] of bad) {
    let threw = null;
    try { await w.eval('importCrm')(f); } catch(e){ threw = e.message; }
    chk('import refuses ' + what + ' with a message', !!threw, 'accepted silently');
  }
  let threw = null;
  try { await w.eval('receiveExchange')({name:'x.json', text: async () => 'not json'}); }
  catch(e){ threw = e.message; }
  chk('a non-JSON exchange file is refused', !!threw);
  threw = null;
  try { await w.eval('doRestore')({name:'x.json', text: async () => '{"format":"nope"}'}); }
  catch(e){ threw = e.message; }
  chk('a foreign backup file is refused', !!threw, String(threw));
  chk('bad input leaves the database empty', w.eval('ACCOUNTS').length === 0);
}

console.log('\n' + pass.length + ' checks passed');
if (notes.length) { console.log('\nNOTES'); notes.forEach(n => console.log('  - ' + n)); }
if (issues.length) { console.log('\nISSUES (' + issues.length + ')'); issues.forEach(i => console.log('  - ' + i)); process.exit(1); }
console.log('\nNo issues found.');
