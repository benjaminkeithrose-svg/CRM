import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const SRC = '/mnt/project/ANZ_Active_template.xlsx';
const DAY = 86400000;

function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
const buf = fs.readFileSync(SRC);
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

const w = boot();
const $ = id => w.document.getElementById(id);
await wait(150);

/* ---------- empty state ---------- */
chk('account tile reads empty before import', $('acctInfo').textContent === 'Nothing loaded');
chk('overdue tile reads empty before import', $('dueInfo').textContent === 'Nothing loaded');
w.eval("go('accounts')"); await wait(40);
chk('browse tells you to import first', $('abHint').textContent.includes('Import'), $('abHint').textContent);
chk('browse shows no accounts', $('abRes').textContent.includes('No accounts'));

await w.eval('importCrm')(crmFile);
await wait(100);
await w.eval('renderHome()');
const ACC = w.eval('ACCOUNTS');
const mgr = $('cMgr').value;

/* ---------- home tiles ---------- */
const mine = ACC.filter(a => a.mgr === mgr).length;
chk('account tile counts yours against the book',
    $('acctInfo').textContent === `${mine} yours of ${ACC.length}`, $('acctInfo').textContent);
chk('overdue tile reports a number', /to book|nothing due|booked/.test($('dueInfo').textContent),
    $('dueInfo').textContent);

/* ---------- cadence maps to a real interval ---------- */
const cadDays = w.eval('CAD_DAYS');
chk('P1 Monthly is 30 days', cadDays['P1 Monthly'] === 30);
chk('P4 Validate & rate is a year', cadDays['P4 Validate & rate'] === 365);
chk('every cadence the importer produces has an interval',
    ACC.every(a => cadDays[a.cad] != null),
    JSON.stringify([...new Set(ACC.map(a => a.cad))]));

/* ---------- due state falls back sensibly with no visits ---------- */
const target = ACC.find(a => a.idle != null) || ACC[0];
const d0 = w.eval('dueState')(target);
chk('with no visits, due is computed from CRM activity',
    d0.basis === (target.idle != null ? 'crm' : 'never'), d0.basis);
const never = ACC.find(a => a.idle == null);
if (never) chk('an account with no CRM date reads as never covered',
    w.eval('dueState')(never).basis === 'never');
else ok.push('no account without a CRM date in this file (nothing to check)');

/* ---------- log a visit and watch the clock change hands ---------- */
w.eval("go('accounts')"); await wait(40);
$('abQ').value = target.a.slice(0, 12);
w.eval('renderBrowse()');
chk('search finds the account', $('abRes').innerHTML.includes('data-acct='), $('abHint').textContent);

w.eval('openAccount')(target.a);
await wait(40);
chk('account view opened', $('s-acct').classList.contains('on'));
chk('account view names the account', $('avHead').textContent.includes(target.a));
chk('account view shows the zone', $('avHead').textContent.includes(w.eval('zoneName')(target.z)));
chk('account view shows focus and cadence',
    $('avHead').textContent.includes(target.foc) && $('avHead').textContent.includes(target.cad));
chk('account view lists the contacts',
    target.c.length ? $('avContacts').textContent.includes(target.c[0].n)
                    : $('avContacts').textContent.includes('No contacts'));
chk('missing email is called out',
    !target.c.some(c => !c.e.length) || $('avContacts').textContent.includes('no email'));
chk('history is empty to start', $('avHistory').textContent.includes('No calls logged'));

// start a call from the account view
$('avStart').click(); await wait(60);
chk('start a call lands on the contacts screen', $('s-contacts').classList.contains('on'));
chk('contacts screen carries the account subtitle', $('ctSub').textContent.includes(target.foc) ||
    $('ctSub').textContent.length > 0, $('ctSub').textContent);
$('ncName').value = 'Someone On Site';
$('openCall').click(); await wait(80);
chk('call opened from the account view', $('s-dash').classList.contains('on'));
chk('new call carries a status', w.eval('call').status === 'in progress', w.eval('call').status);
chk('new call carries a timestamp', typeof w.eval('call').when === 'number');
chk('back from the call flow returns to the account, not the search',
    w.eval('cameFromAcct') === true);

w.eval("go('belt')");
$('bAsset').value = 'CV-1 line 1'; $('bSave').click(); await wait(80);

w.eval('renderAccount()');
chk('the visit shows in the account history', !$('avHistory').textContent.includes('No calls logged'));
chk('history shows the entry count', $('avHistory').textContent.includes('1 entry'), $('avHistory').textContent);
chk('history shows the belt count', $('avHistory').textContent.includes('1 belt'));
chk('history marks the call open', $('avHistory').innerHTML.includes('>open<'));

const d1 = w.eval('dueState')(target);
chk('due now runs off your own visit, not the CRM date', d1.basis === 'visit', d1.basis);
chk('a call today means zero days since', d1.days === 0, String(d1.days));
chk('an account visited today is not overdue', d1.over === false);
chk('due label says which clock it used',
    w.eval('dueLabel')(d1).includes('since your last call'), w.eval('dueLabel')(d1));

/* ---------- status transitions ---------- */
w.eval("go('compile')"); await wait(40);
await w.eval('markShared')('x.html');
chk('sharing marks the call compiled', w.eval('call').status === 'compiled');
chk('status badge follows', w.eval('callStatus')(w.eval('call')).label === 'compiled');
w.eval("call.status='in progress'; call.closed=false;");
w.eval('call').closed = true;
w.eval("if(call.status==='in progress') call.status='done';");
chk('closing without compiling marks it done', w.eval('callStatus')(w.eval('call')).label === 'done');
chk('a cancelled visit reads as cancelled',
    w.eval('callStatus')({status:'cancelled'}).label === 'cancelled');
chk('a missed visit reads as missed',
    w.eval('callStatus')({status:'missed'}).label === 'missed');
chk('an old call with no status field still reads correctly',
    w.eval('callStatus')({closed:true}).label === 'done' &&
    w.eval('callStatus')({closed:false}).label === 'open' &&
    w.eval('callStatus')({closed:true, shared:1}).label === 'compiled');

/* ---------- overdue list ---------- */
const w2 = boot(); await wait(150);
await w2.eval('importCrm')(crmFile); await wait(100);
await w2.eval('renderHome()');
const A2 = w2.eval('ACCOUNTS');
const m2 = $('cMgr') && w2.document.getElementById('cMgr').value;
// plant a stale visit and a fresh one, and check which side of the line they land
const stale = A2.find(a => a.cad === 'P1 Monthly') || A2[0];
const fresh = A2.find(a => a !== stale && a.cad === stale.cad) || A2[1];
const mk = (a, ago) => ({id:'v'+a.a+ago, customer:a.a, date:'01/01/2026', type:'Site call',
  mgr:a.mgr, contacts:[], entries:[], loose:[], status:'done', closed:true,
  when: Date.now() - ago*DAY, updated: Date.now() - ago*DAY});
w2.eval('indexCalls')([mk(stale, 200), mk(fresh, 3)]);
const ds = w2.eval('dueState')(stale), df = w2.eval('dueState')(fresh);
chk('a visit 200 days ago on a monthly cadence is overdue', ds.over === true && ds.days === 200,
    JSON.stringify(ds));
chk('a visit 3 days ago is not overdue', df.over === false && df.days === 3, JSON.stringify(df));
const over = w2.eval('overdueAccounts')(stale.mgr).map(x => x.a.a);
chk('the stale account is in the overdue list', over.includes(stale.a));
chk('the fresh account is not', !over.includes(fresh.a));
const foci = w2.eval('overdueAccounts')(null).map(x => x.a.foc);
const rank = {'High':0,'Medium':1,'Low':2,'No Focus':3};
chk('overdue list is sorted by focus first',
    foci.every((f,i) => i===0 || rank[foci[i-1]] <= rank[f]), JSON.stringify([...new Set(foci)]));

/* ---------- search still reaches the whole book ---------- */
const other = A2.find(a => a.mgr && a.mgr !== m2);
if (other) {
  const doc2 = w2.document;
  doc2.getElementById('cMgr').value = m2;
  w2.eval("browseScope='mine'");
  doc2.getElementById('abQ').value = '';
  w2.eval('renderBrowse()');
  const scoped = doc2.getElementById('abRes').innerHTML;
  chk('scoped list excludes another manager\'s account', !scoped.includes('data-acct="'+other.a+'"'));
  doc2.getElementById('abQ').value = other.a.slice(0, 10);
  w2.eval('renderBrowse()');
  chk('typing suspends the scope and reaches the whole book',
      doc2.getElementById('abRes').innerHTML.includes(other.a));
  chk('out-of-scope hits are tagged with whose they are',
      doc2.getElementById('abRes').innerHTML.includes('class="tag"'));
} else {
  ok.push('only one manager in this file (scope suspension not exercised)');
}

/* ---------- markup ---------- */
const idx = fs.readFileSync('index.html','utf8');
for (const id of ['s-accounts','s-acct','abQ','abScope','abRes','avHead','avContacts','avHistory','avStart','acctInfo','dueInfo'])
  chk('index.html has #' + id, idx.includes('id="'+id+'"'));
chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
