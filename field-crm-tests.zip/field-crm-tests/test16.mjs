import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const DAY = 86400000;
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
const fileOf = (name, text) => ({ name, text: async () => text });

let answers = [];   // queued confirm() responses
function boot(opts) {
  opts = opts || {};
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.XLSX = XLSX;
  w.__prompts = [];
  w.confirm = msg => { w.__prompts.push(msg);
    return answers.length ? answers.shift() : (opts.confirm !== undefined ? opts.confirm : true); };
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches: !!opts.phone, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  const stack = [null]; const h = {i:0};
  Object.defineProperty(w, 'history', { configurable:true, value:{
    get length(){ return h.i+1; }, get state(){ return stack[h.i]; },
    pushState(st){ stack.length = h.i+1; stack.push(st); h.i++; },
    replaceState(st){ stack[h.i] = st; },
    back(){ if(h.i===0) return; h.i--; const e = new w.Event('popstate'); e.state = stack[h.i]; w.dispatchEvent(e); }
  }});
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  w.eval(`downloadFile = function(n,t,m){ window.__dl = window.__dl || []; window.__dl.push({name:n,text:t,mime:m}); };
          (function(){ const real = toast; toast = function(m){ window.__toasts = window.__toasts || []; window.__toasts.push(m); return real(m); }; })();`);
  return w;
}
async function ready(w) {
  await wait(180);
  await w.eval('importCrm')(crmFile); await wait(120);
  await w.eval('renderHome()');
}
const toasts = w => (w.eval('window.__toasts') || []);
const lastToast = w => toasts(w)[toasts(w).length - 1] || '';
async function unplanned(w, acctName) {
  const $ = id => w.document.getElementById(id);
  w.eval("go('today')"); await wait(40);
  $('tvUnplanned').click(); await wait(50);
  w.eval('chooseAccount')(acctName); await wait(50);
  const box = $('ctList').querySelector('input[type=checkbox]');
  if (box) box.checked = true; else $('ncName').value = 'Someone';
  $('openCall').click(); await wait(100);
}

/* ================= 1. book a visit from the phone ================= */
const ph = boot({phone:true});
await ready(ph);
const $ = id => ph.document.getElementById(id);
const ACC = ph.eval('ACCOUNTS');
const acct = ACC.find(a => a.c.length > 0) || ACC[0];

chk('the phone offers a way to book ahead', !!$('tvBook'));
ph.eval("go('today')"); await wait(40);
$('tvBook').click(); await wait(60);
chk('booking sends you to the account picker', $('s-account').classList.contains('on'));
chk('and says that is what it is for',
    $('accHint').textContent.includes('book a visit'), $('accHint').textContent);
ph.eval('chooseAccount')(acct.a); await wait(80);
chk('an appointment was created', ph.eval('APPTS').length === 1, String(ph.eval('APPTS').length));
const booked = ph.eval('APPTS')[0];
chk('it is planned, not in progress', booked.status === 'planned', booked.status);
chk('no call was started for it', (await ph.eval('callsAll()')).length === 0);
chk('it is marked as made on this device', booked.origin === 'phone');
chk('and not yet seen by the PC', booked.acked === false);
chk('the day picker opened straight away', $('mvdlg').hasAttribute('open'));
chk('titled for booking', $('mvTitle').textContent.startsWith('Book '), $('mvTitle').textContent);
chk('and it says where it goes', $('mvDlgSub').textContent.includes('travels to the PC'),
    $('mvDlgSub').textContent);
const day = [...$('mvDays').querySelectorAll('[data-day]')].find(b => !b.disabled).dataset.day;
await ph.eval('moveTo')(day); await wait(60);
chk('picking a day sets it', ph.eval('APPTS')[0].date === day);
chk('it shows in the week list',
    (ph.eval("todayView='week'; go('today')"), $('tvBody').textContent.includes(acct.a)));

// it survives a plan that has never seen it, and travels back
const cf = await ph.eval('buildCallFile')(false);
chk('a booked-ahead visit is queued to send',
    cf.newAppts.length === 1 && cf.newAppts[0].status === 'planned');
const stale = {kind:'field-crm-plan', version:1, made: Date.now() + 60000, device:'desktop',
  range:{from: ph.eval("iso(startOfWeek(new Date()))"), to:'9999-12-31'},
  appts:[], weeks:{}, mgrOf:{}, accounts:null, meta:null, overrides:null};
await ph.eval('receiveExchange')(fileOf('p.json', JSON.stringify(stale))); await wait(60);
chk('a plan that never saw it does not delete it', ph.eval('APPTS').length === 1);

const pc = boot({phone:false}); await ready(pc);
await pc.eval('receiveExchange')(fileOf('c.json', JSON.stringify(cf))); await wait(80);
chk('the PC picks up the booked visit', pc.eval('APPTS').length === 1);
chk('on the day the phone chose', pc.eval('APPTS')[0].date === day);
chk('and it is acknowledged there', pc.eval('APPTS')[0].acked === true);

// a typed-in account cannot be booked
ph.eval("go('today')"); await wait(30);
$('tvBook').click(); await wait(50);
$('accManual').value = 'NOT IN THE CRM - NOWHERE';
$('accManualGo').click(); await wait(50);
chk('a typed-in account is refused for booking',
    ph.eval('APPTS').length === 1, String(ph.eval('APPTS').length));
chk('and says why', /only accounts from the crm export/i.test(lastToast(ph)), lastToast(ph));

/* ================= 2. reuse a call from the same week ================= */
const w2 = boot({phone:true}); await ready(w2);
const $2 = id => w2.document.getElementById(id);
const a2 = w2.eval('ACCOUNTS').find(a => a.c.length > 0) || w2.eval('ACCOUNTS')[0];

await unplanned(w2, a2.a);
w2.eval("go('belt')");
$2('bAsset').value = 'FIRST-VISIT'; $2('bSave').click(); await wait(60);
const firstId = w2.eval('call').id;
$2('closeCall').click(); await wait(90);
chk('the first call is closed', (await w2.eval('callsAll()'))[0].closed === true);

// back to the same account, same week
answers = [true];
await unplanned(w2, a2.a);
chk('the user is asked about the existing call',
    w2.__prompts.some(p => p.includes('already a call at')),
    JSON.stringify(w2.__prompts.slice(-1)));
chk('the prompt describes what is on it',
    w2.__prompts.some(p => p.includes('1 entry') || p.includes('1 belt')),
    JSON.stringify(w2.__prompts.slice(-1)));
chk('saying yes continues the same record', w2.eval('call').id === firstId,
    w2.eval('call').id + ' vs ' + firstId);
chk('no second call was created', (await w2.eval('callsAll()')).length === 1,
    String((await w2.eval('callsAll()')).length));
chk('the earlier belt is still there',
    w2.eval('call').entries.some(e => e.asset === 'FIRST-VISIT'));
chk('a closed call is reopened to work on', w2.eval('call').closed === false);
chk('and it is in progress again', w2.eval('call').status === 'in progress');
chk('the user is told which call they are on',
    /continuing the call/i.test(lastToast(w2)), lastToast(w2));

// contacts picked the second time are merged, not replaced
const names = w2.eval('call').contacts.map(c => c.name);
chk('contacts are merged rather than overwritten', names.length >= 1, JSON.stringify(names));
chk('nobody is listed twice', new Set(names.map(n => n.toLowerCase())).size === names.length);

// declining starts a separate call
answers = [false];
await unplanned(w2, a2.a);
chk('declining starts a separate call', (await w2.eval('callsAll()')).length === 2,
    String((await w2.eval('callsAll()')).length));
chk('and it is a different record', w2.eval('call').id !== firstId);

// a different account in the same week is not offered
const other = w2.eval('ACCOUNTS').find(a => a.a !== a2.a);
const before = w2.__prompts.length;
await unplanned(w2, other.a);
chk('a different account is not offered the other call',
    !w2.__prompts.slice(before).some(p => p.includes(a2.a)),
    JSON.stringify(w2.__prompts.slice(before)));

// a call from a previous week is not offered
const w3 = boot({phone:true}); await ready(w3);
const a3 = w3.eval('ACCOUNTS')[0];
const old = {id:'oldcall', customer:a3.a, date:'01/01/2026', type:'Site call', mgr:'m',
  contacts:[], entries:[{type:'belt', asset:'LAST-MONTH', photos:[]}], loose:[],
  status:'compiled', closed:true, when: Date.now() - 30*DAY, updated: Date.now() - 30*DAY};
await w3.eval('callsPut')(old);
w3.eval('indexCalls')(await w3.eval('callsAll()'));
chk('a call from last month is out of the week', w3.eval('callsSameWeek')(a3.a, null).length === 0);
const p3 = w3.__prompts.length;
await unplanned(w3, a3.a);
chk('so it is not offered', !w3.__prompts.slice(p3).some(p => p.includes('already a call')),
    JSON.stringify(w3.__prompts.slice(p3)));
chk('and a new call is created', (await w3.eval('callsAll()')).length === 2);

// cancelled and missed calls are not offered
const w4 = boot({phone:true}); await ready(w4);
const a4 = w4.eval('ACCOUNTS')[0];
await w4.eval('callsPut')({id:'x1', customer:a4.a, date:'01/09/2026', type:'Site call', mgr:'m',
  contacts:[], entries:[], loose:[], status:'cancelled', closed:true,
  when: Date.now(), updated: Date.now()});
w4.eval('indexCalls')(await w4.eval('callsAll()'));
chk('a cancelled call is not offered for reuse',
    w4.eval('callsSameWeek')(a4.a, null).length === 0);

// starting a planned visit offers it too
const w5 = boot({phone:true}); await ready(w5);
const a5 = w5.eval('ACCOUNTS')[0];
await unplanned(w5, a5.a);
const openId = w5.eval('call').id;
const ap5 = {id:'ap-later', acct:a5.a, type:'Intralox site visit',
  date: w5.eval('todayISOdate()'), start:'14:00', dur:60, agenda:'', contacts:[]};
w5.eval('APPTS').push(ap5); await w5.eval('apptsPut')(ap5);
answers = [true];
await w5.eval('startVisit')('ap-later'); await wait(90);
chk('a second planned visit that week joins the same call',
    w5.eval('call').id === openId, w5.eval('call').id + ' vs ' + openId);
chk('so the week has one call, not two', (await w5.eval('callsAll()')).length === 1);
chk('and the appointment points at it', w5.eval('APPTS').find(a => a.id === 'ap-later').callId === openId);

/* ================= 3. every loaded file is confirmed ================= */
const w6 = boot({phone:false}); await wait(180);
const $6 = id => w6.document.getElementById(id);
chk('the log says nothing has been loaded yet',
    $6('loadLog').textContent.includes('No files loaded'), $6('loadLog').textContent);

await w6.eval('importCrm')(crmFile); await wait(120);
chk('the CRM import is logged', w6.eval('LOAD_LOG').length === 1);
chk('with the filename', w6.eval('LOAD_LOG')[0].file === 'ANZ_Active_template.xlsx',
    w6.eval('LOAD_LOG')[0].file);
chk('and a clear success line',
    $6('loadLog').textContent.includes('Loaded successfully'), $6('loadLog').textContent.slice(0,80));
chk('the filename is on screen', $6('loadLog').textContent.includes('ANZ_Active_template.xlsx'));
chk('and what it did', /accounts/.test(w6.eval('LOAD_LOG')[0].detail), w6.eval('LOAD_LOG')[0].detail);

const ovText = fs.readFileSync('zone-overrides.json','utf8');
await w6.eval('importOverrides')(fileOf('zone-overrides.json', ovText)); await wait(60);
chk('the overrides load is logged', w6.eval('LOAD_LOG')[0].kind === 'overrides');
chk('with its filename', w6.eval('LOAD_LOG')[0].file === 'zone-overrides.json');
chk('and the counts', /46 account pins/.test(w6.eval('LOAD_LOG')[0].detail),
    w6.eval('LOAD_LOG')[0].detail);
chk('the toast names the file too', /zone-overrides\.json/.test(lastToast(w6)), lastToast(w6));
chk('the overrides remember which file they came from',
    w6.eval('OVERRIDES').file === 'zone-overrides.json');
chk('newest first', w6.eval('LOAD_LOG')[0].kind === 'overrides' && w6.eval('LOAD_LOG')[1].kind === 'crm');

const planTxt = JSON.stringify(await pc.eval('buildPlanFile')(false));
await w6.eval('routeIncomingFile')(fileOf('field-crm-plan-2026-09-07.json', planTxt));
chk('a plan load is logged', w6.eval('LOAD_LOG')[0].kind === 'plan');
chk('with its filename', w6.eval('LOAD_LOG')[0].file === 'field-crm-plan-2026-09-07.json');

// a refusal is logged too, marked as failed
let threw = null;
try { await w6.eval('routeIncomingFile')(fileOf('rubbish.json', '{"nope":1}')); }
catch(e){ threw = e.message; }
chk('a refused file is still logged', w6.eval('LOAD_LOG')[0].file === 'rubbish.json');
chk('marked as failed', w6.eval('LOAD_LOG')[0].failed === true);
chk('and shown as a failure', $6('loadLog').innerHTML.includes('ldrow bad'));
chk('with the reason', !!w6.eval('LOAD_LOG')[0].detail, w6.eval('LOAD_LOG')[0].detail);
chk('the successful ones are still there', w6.eval('LOAD_LOG').length === 4,
    String(w6.eval('LOAD_LOG').length));

// it survives a restart
const persisted = await w6.eval("kvGet('loadLog')");
chk('the log is written to storage', Array.isArray(persisted) && persisted.length === 4);
chk('the log is capped', w6.eval('LOAD_LOG_MAX') === 12);

/* ================= 4. folders name their device and direction ================= */
const idx = fs.readFileSync('index.html','utf8');
chk('the outbound folder is labelled PC to Phone', idx.includes('PC &rarr; Phone'));
chk('the inbound folder is labelled Phone to PC', idx.includes('Phone &rarr; PC'));
chk('the outbound folder says who writes and who reads',
    idx.includes('<b>PC writes</b>') && idx.includes('<b>phone reads</b>'));
chk('the inbound folder says who writes and who reads',
    idx.includes('<b>phone writes</b>') && idx.includes('<b>PC reads</b>'));
chk('it warns against using one folder for both',
    idx.includes('reading back what it just wrote'));
chk('the buttons say which device to set them on',
    idx.includes('folder (on the PC)'));
chk('no vague folder wording is left',
    !/Choose the OneDrive folder/.test(idx));

chk('the two handles are separate', w6.eval('typeof DIR_OUT') !== 'undefined' &&
    w6.eval('typeof DIR_IN') !== 'undefined');
chk('the labels name the direction',
    w6.eval('DIR_LABEL.out').includes('PC') && w6.eval('DIR_LABEL.out').includes('Phone'),
    w6.eval('DIR_LABEL.out'));

// the PC writes plans out and reads calls in
const outFiles = {}, inFiles = {};
const mkHandle = (name, bag) => ({
  name,
  queryPermission: async () => 'granted', requestPermission: async () => 'granted',
  getFileHandle: async (n, o) => {
    if(!(n in bag) && !(o && o.create)) throw new Error('not found');
    return { createWritable: async () => ({ write: async t => { bag[n] = t; }, close: async () => {} }),
             getFile: async () => fileOf(n, bag[n]) };
  },
  entries: function*(){ for(const k of Object.keys(bag)) yield [k, null]; }
});
const pcw = boot({phone:false}); await ready(pcw);
pcw.__o = mkHandle('ToPhone', outFiles); pcw.__i = mkHandle('ToPC', inFiles);
pcw.eval('DIR_OUT = window.__o; DIR_IN = window.__i;');
await pcw.eval('openDialog')(null, {acct: pcw.eval('ACCOUNTS')[0].a, date: pcw.eval('iso(weekDays()[0])')});
pcw.document.getElementById('dSave').click(); await wait(60);
await pcw.eval('sendPlan')(); await wait(60);
chk('the plan goes into the PC -> Phone folder',
    Object.keys(outFiles).length === 1 && Object.keys(outFiles)[0].startsWith('field-crm-plan'),
    JSON.stringify(Object.keys(outFiles)));
chk('and not into the Phone -> PC folder', Object.keys(inFiles).length === 0);
chk('the message names the direction', /PC → Phone|PC \u2192 Phone/.test(lastToast(pcw)), lastToast(pcw));
chk('writing the plan is logged', pcw.eval('LOAD_LOG')[0].kind === 'sent');

// the phone writes calls into the inbound folder
const phw = boot({phone:true}); await ready(phw);
phw.__i = mkHandle('ToPC', inFiles);
phw.eval('DIR_IN = window.__i;');
await unplanned(phw, phw.eval('ACCOUNTS')[0].a);
await phw.eval('sendCalls')(); await wait(60);
chk('the calls go into the Phone -> PC folder',
    Object.keys(inFiles).some(n => n.startsWith('field-crm-calls')),
    JSON.stringify(Object.keys(inFiles)));
chk('and never into the PC -> Phone folder',
    !Object.keys(outFiles).some(n => n.startsWith('field-crm-calls')));

// the PC reads calls from the inbound folder only
const pcr = boot({phone:false}); await ready(pcr);
pcr.__o = mkHandle('ToPhone', outFiles); pcr.__i = mkHandle('ToPC', inFiles);
pcr.eval('DIR_OUT = window.__o; DIR_IN = window.__i;');
await pcr.eval('receiveFromFolder')(); await wait(100);
chk('checking the folders picks up the calls', (await pcr.eval('callsAll()')).length === 1,
    String((await pcr.eval('callsAll()')).length));
chk('each pull is logged with its filename',
    pcr.eval('LOAD_LOG').some(r => r.file.startsWith('field-crm-calls')),
    JSON.stringify(pcr.eval('LOAD_LOG').map(r => r.file)));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
