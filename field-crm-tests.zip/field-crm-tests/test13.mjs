import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';
import { createRequire } from 'module';
const XLSX = createRequire(import.meta.url)('xlsx');

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));
const DAY = 86400000;
const buf = fs.readFileSync('/mnt/project/ANZ_Active_template.xlsx');
const crmFile = { name:'ANZ_Active_template.xlsx',
  arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };

function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory(); w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {}; w.confirm = () => true; w.XLSX = XLSX;
  w.URL.createObjectURL = () => 'blob:x'; w.URL.revokeObjectURL = () => {};
  w.matchMedia = q => ({ matches:false, media:q, addListener(){}, removeListener(){} });
  for (const id of ['dlg','mvdlg','rdlg']) {
    const d = w.document.getElementById(id);
    d.showModal = function(){ this.setAttribute('open',''); };
    d.close = function(){ this.removeAttribute('open'); };
  }
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}
async function ready(w) {
  await wait(150);
  await w.eval('importCrm')(crmFile); await wait(100);
  await w.eval('renderHome()');
}
// a finished call at an account, n days ago
const past = (acct, n, entries, extra) => Object.assign({
  id: 'h' + acct.slice(0,4).replace(/\W/g,'') + n,
  customer: acct, date: '0' + (n % 9 + 1) + '/08/2026', type: 'Site call', mgr: 'm',
  contacts: [], entries: entries || [], loose: [], status: 'compiled', closed: true,
  sharedAs: 'Notes_' + n + '.html',
  when: Date.now() - n * DAY, updated: Date.now() - n * DAY
}, extra || {});

const w = boot();
const $ = id => w.document.getElementById(id);
await ready(w);
const ACC = w.eval('ACCOUNTS');
const acct = ACC.find(a => a.c.length > 0) || ACC[0];

/* ---------- no history, no block ---------- */
$('accManual').value = acct.a;
$('accManualGo').click(); await wait(50);
$('ncName').value = 'A Person';
$('openCall').click(); await wait(80);
w.eval("go('belt')");
$('bAsset').value = 'CV-1 line 1';
$('bWidth').value = '606';
$('bSave').click(); await wait(60);
let html = await w.eval('buildNotesHTML()');
chk('a first visit carries no history section',
    !html.includes('Previous calls at this account'), 'section present');
chk('the notes still have the belt', html.includes('CV-1 line 1'));

/* ---------- one previous visit ---------- */
const prev = past(acct.a, 40, [
  {type:'belt', asset:'61-156 boning line 2', beltdesc:'S800', photos:[]},
  {type:'health', asset:'CV-114', htype:'Sprocket wear', severity:'Plan', fault:'worn', photos:[]}
]);
await w.eval('callsPut')(prev);
w.eval('indexCalls')(await w.eval('callsAll()'));
html = await w.eval('buildNotesHTML()');
chk('the history section appears once there is history',
    html.includes('Previous calls at this account'));
chk('it names the earlier date', html.includes(prev.date));
chk('it names the belts logged then', html.includes('61-156 boning line 2'));
chk('it names the health item', html.includes('CV-114'));
chk('it says what the outcome was', html.includes('compiled'));
chk('it points at the notes file from that day', html.includes('Notes_40.html'));
// scope the check: the current call legitimately has a full field table
const histPart = html.split('Previous calls at this account')[1];
chk('the history section does not reproduce the field tables',
    !histPart.includes('Centre line') && !histPart.includes('Belt material'),
    'field table leaked into history');
chk('and it is one row per visit, not a block each',
    (histPart.match(/<table/g)||[]).length === 1,
    String((histPart.match(/<table/g)||[]).length));
chk('it carries no photos from the earlier call', (html.match(/<img/g)||[]).length <= 1,
    String((html.match(/<img/g)||[]).length));
chk('the current call is not listed as its own history',
    !html.includes('CV-1 line 1</td>'), 'current call in history table');

/* ---------- the cadence line ---------- */
chk('the block states the cadence', html.includes(acct.cad));
chk('and how long it has been',
    /since your last call|since CRM activity|never covered|booked/.test(
      html.split('Previous calls at this account')[1].slice(0, 400)),
    html.split('Previous calls at this account')[1].slice(0, 200));

/* ---------- ordering and the length limit ---------- */
const w2 = boot(); await ready(w2);
const A2 = w2.eval('ACCOUNTS');
const acct2 = A2[0];
for (let i = 1; i <= 10; i++) {
  await w2.eval('callsPut')(past(acct2.a, i * 20, [
    {type:'belt', asset:'ASSET-' + i, photos:[]}
  ]));
}
w2.eval('indexCalls')(await w2.eval('callsAll()'));
w2.eval("call = {id:'now', customer:" + JSON.stringify(acct2.a) +
  ", date:'01/09/2026', type:'Site call', mgr:'m', contacts:[], entries:[], loose:[], " +
  "status:'in progress', closed:false, updated:Date.now()};");
const h2 = await w2.eval('buildNotesHTML()');
const rows = (h2.split('Previous calls at this account')[1].match(/<tr>/g) || []).length - 1;
chk('the history is capped', rows === w2.eval('HISTORY_MAX'), `${rows} rows`);
chk('the cap is six', w2.eval('HISTORY_MAX') === 6);
chk('the newest visit is shown', h2.includes('ASSET-1'));
chk('the oldest is not', !h2.includes('ASSET-10'));
chk('newest first', h2.indexOf('ASSET-1') < h2.indexOf('ASSET-2'));
chk('it says how many were left out', h2.includes('4 older calls not shown'),
    (h2.match(/older calls? not shown/) || ['no line'])[0]);
chk('and that those notes went out at the time',
    h2.includes('Full notes for each were shared at the time'));

/* ---------- one row per visit, summarised not reproduced ---------- */
const w3 = boot(); await ready(w3);
const acct3 = w3.eval('ACCOUNTS')[0];
const big = past(acct3.a, 10, [
  {type:'belt', asset:'A1', photos:['x']}, {type:'belt', asset:'A2', photos:[]},
  {type:'belt', asset:'A3', photos:[]}, {type:'belt', asset:'A4', photos:[]},
  {type:'belt', asset:'A5', photos:[]},
  {type:'health', asset:'H1', severity:'Urgent', photos:[]},
  {type:'project', project:'Nitrogen tunnel', photos:[]},
  {type:'note', topic:'Production', text:'x', photos:[]},
  {type:'note', topic:'Plant', text:'y', photos:[]}
], {loose:['z','z2']});
await w3.eval('callsPut')(big);
w3.eval('indexCalls')(await w3.eval('callsAll()'));
const line = w3.eval('histLine')(big);
chk('the summary counts the belts', line.includes('5 belts'), line);
chk('a long asset list is trimmed', line.includes('+2 more'), line);
chk('it counts the health items', line.includes('1 health item'), line);
chk('it names the project', line.includes('Nitrogen tunnel'), line);
chk('it groups the notes by topic',
    line.includes('2 notes') && line.includes('Production'), line);
chk('the summary stays on one line', !line.includes('\n'));
chk('the photo count is separate from the summary',
    w3.eval('histPhotos')(big) === 3, String(w3.eval('histPhotos')(big)));
chk('detached photos are still counted',
    w3.eval('histPhotos')({entries:[{detached:{n:4}}], loose:[], looseDetached:{n:1}}) === 5);

/* ---------- outcomes read differently ---------- */
const w4 = boot(); await ready(w4);
const acct4 = w4.eval('ACCOUNTS')[0];
await w4.eval('callsPut')(past(acct4.a, 5, [], {id:'q1', noReport:true, status:'done', sharedAs:''}));
await w4.eval('callsPut')(past(acct4.a, 6, [{type:'belt', asset:'B1', photos:[]}], {id:'q2', status:'compiled'}));
w4.eval('indexCalls')(await w4.eval('callsAll()'));
chk('a visit with nothing to report says so, not "no entries"',
    w4.eval('histLine')({entries:[], noReport:true}) === 'Visited, nothing to report',
    w4.eval('histLine')({entries:[], noReport:true}));
chk('a call that logged nothing and was not closed out reads differently',
    w4.eval('histLine')({entries:[]}) === 'No entries logged');
w4.eval("call = {id:'now', customer:" + JSON.stringify(acct4.a) +
  ", date:'01/09/2026', type:'Site call', mgr:'m', contacts:[], entries:[], loose:[], " +
  "status:'in progress', closed:false, updated:Date.now()};");
const h4 = await w4.eval('buildNotesHTML()');
chk('both outcomes appear in the table',
    h4.includes('Visited, nothing to report') && h4.includes('B1'));
chk('done and compiled are distinguished',
    h4.includes('>done<') && h4.includes('>compiled<'), 'outcomes');
chk('a missing notes file reads as an em dash, not blank',
    h4.split('Previous calls')[1].includes('\u2014'));

/* ---------- only finished visits appear ---------- */
const w5 = boot(); await ready(w5);
const acct5 = w5.eval('ACCOUNTS')[0];
await w5.eval('callsPut')(past(acct5.a, 3, [{type:'belt', asset:'DONE', photos:[]}]));
await w5.eval('callsPut')(past(acct5.a, 2, [{type:'belt', asset:'OPEN', photos:[]}],
  {id:'open1', status:'in progress', closed:false}));
w5.eval('indexCalls')(await w5.eval('callsAll()'));
w5.eval("call = {id:'now', customer:" + JSON.stringify(acct5.a) +
  ", date:'01/09/2026', type:'Site call', mgr:'m', contacts:[], entries:[], loose:[], " +
  "status:'in progress', closed:false, updated:Date.now()};");
const h5 = await w5.eval('buildNotesHTML()');
chk('a finished visit appears', h5.includes('DONE'));
chk('a call still open does not', !h5.includes('OPEN'), 'open call leaked into history');

/* ---------- history is per account ---------- */
const w6 = boot(); await ready(w6);
const A6 = w6.eval('ACCOUNTS');
await w6.eval('callsPut')(past(A6[0].a, 4, [{type:'belt', asset:'MINE', photos:[]}]));
await w6.eval('callsPut')(past(A6[1].a, 4, [{type:'belt', asset:'THEIRS', photos:[]}]));
w6.eval('indexCalls')(await w6.eval('callsAll()'));
w6.eval("call = {id:'now', customer:" + JSON.stringify(A6[0].a) +
  ", date:'01/09/2026', type:'Site call', mgr:'m', contacts:[], entries:[], loose:[], " +
  "status:'in progress', closed:false, updated:Date.now()};");
const h6 = await w6.eval('buildNotesHTML()');
chk('this account\'s history appears', h6.includes('MINE'));
chk('another account\'s does not', !h6.includes('THEIRS'));

/* ---------- the output is still valid and printable ---------- */
const divO = (h6.match(/<div\b/g)||[]).length, divC = (h6.match(/<\/div>/g)||[]).length;
chk('div tags balanced with the history block in', divO === divC, `${divO}/${divC}`);
const tO = (h6.match(/<table\b/g)||[]).length, tC = (h6.match(/<\/table>/g)||[]).length;
chk('table tags balanced', tO === tC, `${tO}/${tC}`);
chk('the history sits before the footer',
    h6.indexOf('Previous calls at this account') < h6.indexOf('class="ft"'));
chk('the footer is still last', h6.trim().endsWith('</body></html>'));
chk('an account name with markup in it is escaped',
    w6.eval('esc')('<b>x</b>') === '&lt;b&gt;x&lt;/b&gt;');

/* ---------- the invite is unchanged ---------- */
chk('the history block is not added to the invite body',
    !w6.eval('inviteParts').toString().includes('historyBlock'));

chk('cache bumped', /fieldcrm-v\d+/.test(fs.readFileSync('sw.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
