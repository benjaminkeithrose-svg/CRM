import fs from 'fs';
import { JSDOM } from 'jsdom';
import FDBFactory from 'fake-indexeddb/lib/FDBFactory';
import FDBKeyRange from 'fake-indexeddb/lib/FDBKeyRange';

const fail = [], ok = [];
const chk = (n, c, x='') => (c ? ok : fail).push(n + (x ? ' :: ' + x : ''));
const wait = ms => new Promise(r => setTimeout(r, ms));

let urlsMade = 0, urlsRevoked = 0;
function boot() {
  const dom = new JSDOM(fs.readFileSync('index.html','utf8'),
    { runScripts:'dangerously', url:'https://x.github.io/f/', pretendToBeVisual:true });
  const w = dom.window;
  w.indexedDB = new FDBFactory();
  w.IDBKeyRange = FDBKeyRange;
  w.navigator.storage = { persist: async () => true };
  w.scrollTo = () => {};
  w.confirm = () => true;
  w.URL.createObjectURL = () => { urlsMade++; return 'blob:u' + urlsMade; };
  w.URL.revokeObjectURL = () => { urlsRevoked++; };
  for (const f of ['zones.js','app.js']) {
    const el = w.document.createElement('script');
    el.textContent = fs.readFileSync(f,'utf8');
    w.document.body.appendChild(el);
  }
  return w;
}

// A small but real JPEG, so byte counts and base64 round-trips are meaningful.
const JPEG = Buffer.from(
  '/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0a' +
  'HBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAA' +
  'AAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AKp//2Q==', 'base64');

const w = boot();
const $ = id => w.document.getElementById(id);
await wait(150);
const mkBlob = () => new w.Blob([JPEG], {type:'image/jpeg'});

/* ---------- primitives ---------- */
chk('a Blob is recognised as a photo', w.eval('isBlobPhoto')(mkBlob()) === true);
chk('a data URI is not', w.eval('isBlobPhoto')('data:image/jpeg;base64,AAAA') === false);
chk('Blob size is read directly', w.eval('photoBytes')(mkBlob()) === JPEG.length,
    `${w.eval('photoBytes')(mkBlob())} vs ${JPEG.length}`);
const b64 = 'data:image/jpeg;base64,' + JPEG.toString('base64');
const est = w.eval('photoBytes')(b64);
chk('base64 photo size is estimated close to the real bytes',
    Math.abs(est - JPEG.length) <= 3, `${est} vs ${JPEG.length}`);
chk('base64 inflates, so Blob storage is smaller',
    b64.length > JPEG.length * 1.3, `${b64.length} vs ${JPEG.length}`);
chk('humanSize reads in KB', w.eval('humanSize')(2048) === '2 KB', w.eval('humanSize')(2048));
chk('humanSize reads in MB', w.eval('humanSize')(26214400) === '25.0 MB', w.eval('humanSize')(26214400));

// data URI <-> Blob round trip
const back = w.eval('dataURLToBlob')(b64);
chk('dataURLToBlob returns the original bytes', back.size === JPEG.length, `${back.size}`);
const fwd = await w.eval('blobToDataURL')(mkBlob());
chk('blobToDataURL returns a jpeg data URI', /^data:image\/jpeg;base64,/.test(fwd), fwd.slice(0,40));
chk('round trip is lossless', fwd === b64);

/* ---------- object URLs are reused, not leaked ---------- */
const bl = mkBlob();
const before = urlsMade;
const u1 = w.eval('photoSrc')(bl), u2 = w.eval('photoSrc')(bl);
chk('one object URL per Blob however often it renders', u1 === u2 && urlsMade === before + 1,
    `made ${urlsMade - before}`);
const revBefore = urlsRevoked;
w.eval('releasePhoto')(bl);
chk('releasing a photo revokes its URL', urlsRevoked === revBefore + 1);

/* ---------- log a call with Blob photos ---------- */
$('accManual').value = 'Test Plant - Somewhere';
$('accManualGo').click(); await wait(60);
$('ncName').value = 'A Person';
$('openCall').click(); await wait(80);
w.eval("go('belt')");
$('bAsset').value = 'CV-99 line 1'; $('bWidth').value = '606';
$('bSave').click(); await wait(60);
w.eval("go('health')");
$('hAsset').value = 'CV-100'; $('hFault').value = 'tracking right';
// severity is required now, so the walkthrough has to answer it
w.document.querySelector('#hSev button[data-v="Plan"]').click();
$('hSave').click(); await wait(80);

w.call = null;
w.eval('call').entries[0].photos = [mkBlob(), mkBlob()];
w.eval('call').entries[1].photos = [mkBlob()];
w.eval('call').loose = [mkBlob()];
await w.eval('saveCall()');

chk('callBytes totals every Blob', w.eval('callBytes')(w.eval('call')) === JPEG.length * 4,
    String(w.eval('callBytes')(w.eval('call'))));

/* ---------- writing Blobs to IndexedDB ---------- */
/* fake-indexeddb's structured clone does not preserve Blob identity - it hands
   back a plain object. Real IndexedDB does store Blobs natively. So this checks
   that writing a call full of Blobs completes without error, and the Blob round
   trip through storage is called out as untested rather than asserted. */
let wroteOk = true;
try { await w.eval('saveCall()'); } catch(e){ wroteOk = false; }
chk('a call holding Blobs saves without error', wroteOk);
chk('the call is in the store', (await w.eval('callsAll()')).length === 1);

/* ---------- dashboard renders from object URLs, not base64 ---------- */
w.eval("go('dash')"); await wait(60);
const dashHtml = $('logList').innerHTML;
chk('thumbnails use blob: URLs', dashHtml.includes('src="blob:'));
chk('no base64 in the dashboard DOM', !dashHtml.includes('data:image'));

/* ---------- compile embeds base64, output unchanged in shape ---------- */
w.eval("go('compile')"); await wait(60);
const html = await w.eval('buildNotesHTML()');
chk('compiled notes embed base64 images', (html.match(/<img src="data:image\/jpeg;base64,/g)||[]).length === 4,
    String((html.match(/<img src="data:image\/jpeg;base64,/g)||[]).length));
chk('every photo made it into the notes', html.split(JPEG.toString('base64')).length - 1 === 4);
chk('notes still carry the belt', html.includes('CV-99 line 1'));
chk('notes still carry the additional photos section', html.includes('Additional photos'));
const divOpen = (html.match(/<div\b/g)||[]).length, divClose = (html.match(/<\/div>/g)||[]).length;
chk('div tags balanced after the loop rewrite', divOpen === divClose, `${divOpen}/${divClose}`);

/* ---------- detach is offered only after a confirmed share ---------- */
w.eval('renderCompileStat()');
chk('no detach offer before a share', $('detachWrap').innerHTML === '');
chk('compile stat reports what is held on the phone',
    $('compStat').textContent.includes('held on this phone'), $('compStat').textContent);

await w.eval('markShared')('Test_Plant_call_notes_01-01-2026.html');
chk('detach offered once shared', $('detachWrap').innerHTML.includes('detachBtn'));
chk('detach offer names the size', $('detachWrap').textContent.includes('holding a second copy'));

const heldBefore = w.eval('callBytes')(w.eval('call'));
await w.eval('detachPhotos()');
chk('detach freed everything', w.eval('callBytes')(w.eval('call')) === 0, String(heldBefore));
chk('detach kept the count on the belt', w.eval('call').entries[0].detached.n === 2);
chk('detach kept the count on the health item', w.eval('call').entries[1].detached.n === 1);
chk('detach kept the loose count', w.eval('call').looseDetached.n === 1);
chk('detach recorded the file it went out in',
    w.eval('call').entries[0].detached.file === 'Test_Plant_call_notes_01-01-2026.html');
chk('detach offer disappears once there is nothing left', $('detachWrap').innerHTML === '');

const detachedCall = (await w.eval('callsAll()'))[0];
chk('detached call persisted with no image data',
    detachedCall.entries.every(e => e.photos.length === 0) && detachedCall.loose.length === 0);
chk('a detached call is tiny', JSON.stringify(detachedCall).length < 2000,
    String(JSON.stringify(detachedCall).length));

/* ---------- recompiling a detached call says where the photos went ---------- */
const html2 = await w.eval('buildNotesHTML()');
chk('recompiled notes contain no images', !html2.includes('data:image/jpeg'));
chk('recompiled notes say the photos were sent',
    (html2.match(/no longer held on the device/g)||[]).length === 3,
    String((html2.match(/no longer held on the device/g)||[]).length));
chk('recompiled notes still list the belt', html2.includes('CV-99 line 1'));

/* ---------- backups ---------- */
const w2 = boot(); await wait(150);
w2.eval("call = {id:'c1', date:'01/01/2026', type:'Site call', mgr:'m', customer:'X', site:'', contacts:[], entries:[{type:'belt', asset:'A1', photos:[]}], loose:[], closed:false, updated:Date.now()};");
w2.eval('call').entries[0].photos = [new w2.Blob([JPEG], {type:'image/jpeg'})];
w2.eval('call').loose = [new w2.Blob([JPEG], {type:'image/jpeg'})];
// stand in for the store, which cannot hand Blobs back in this environment
const liveCall = w2.eval('call');
w2.callsAll = async () => [liveCall];

const light = await w2.eval('buildBackup')(false);
const lightStr = JSON.stringify(light);
chk('structured backup carries no image data', !lightStr.includes('data:image'));
chk('structured backup does not leave an empty object where a Blob was',
    !/"photos":\[\{\}\]/.test(lightStr), lightStr.slice(0,400));
chk('structured backup records the photo count', light.calls[0].entries[0].photoCount === 1);
chk('structured backup records the loose count', light.calls[0].looseCount === 1);
chk('structured backup keeps the entry fields', light.calls[0].entries[0].asset === 'A1');

const full = await w2.eval('buildBackup')(true);
const fullStr = JSON.stringify(full);
chk('full backup inlines the photos as base64', (fullStr.match(/data:image\/jpeg/g)||[]).length === 2);
chk('full backup is bigger than the structured one, by the size of the images',
    fullStr.length > lightStr.length, `${fullStr.length} vs ${lightStr.length}`);
chk('the two backups differ by roughly the base64 of both photos',
    Math.abs((fullStr.length - lightStr.length) - 2 * b64.length) < 200,
    `${fullStr.length - lightStr.length} vs ${2 * b64.length}`);

/* ---------- restore a full backup: base64 goes back to Blobs ---------- */
const w3 = boot(); await wait(150);
// capture what restore actually hands to the store, so the base64 -> Blob
// conversion is checked directly rather than through the fake store
const written = [];
w3.callsPut = async c => { written.push(c); };
w3.callsAll = async () => written;
await w3.eval('doRestore')({ name:'b.json', text: async () => fullStr });
await wait(100);
const rc = written[0];
chk('restore converts base64 back to a Blob',
    rc.entries[0].photos.length === 1 && rc.entries[0].photos[0] instanceof w3.Blob,
    typeof rc.entries[0].photos[0]);
chk('restored Blob has the right bytes', rc.entries[0].photos[0].size === JPEG.length,
    String(rc.entries[0].photos[0].size));
chk('restored loose photo is a Blob too', rc.loose[0] instanceof w3.Blob);
chk('nothing is left as a data URI after restore',
    !JSON.stringify(rc.entries[0].photos.map(p => typeof p)).includes('string'));

// and a structured backup restores cleanly with no photos
const w4 = boot(); await wait(150);
const written2 = [];
w4.callsPut = async c => { written2.push(c); };
w4.callsAll = async () => written2;
await w4.eval('doRestore')({ name:'b.json', text: async () => lightStr });
await wait(100);
const rc2 = written2[0];
chk('structured restore brings the call back', rc2 && rc2.id === 'c1');
chk('structured restore leaves photos empty rather than broken',
    Array.isArray(rc2.entries[0].photos) && rc2.entries[0].photos.length === 0);
chk('structured restore keeps the photo count so the loss is visible',
    rc2.entries[0].photoCount === 1);

/* ---------- files ---------- */
const idx = fs.readFileSync('index.html','utf8'), sw = fs.readFileSync('sw.js','utf8');
chk('index.html has the detach slot', idx.includes('id="detachWrap"'));
chk('sw cache bumped', /fieldcrm-v\d+/.test(sw));
chk('app.js no longer stores photos as data URIs from the camera',
    !/res\(cv\.toDataURL\('image\/jpeg', q\)\);/.test(fs.readFileSync('app.js','utf8')));

console.log('PASS ' + ok.length);
if (fail.length) { console.log('\nFAIL ' + fail.length); fail.forEach(f => console.log('  - ' + f)); process.exit(1); }
